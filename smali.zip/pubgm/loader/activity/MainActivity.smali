# classes2.dex

.class public Lpubgm/loader/activity/MainActivity;
.super Lpubgm/loader/utils/ActivityCompat;


# static fields
.field private static final BUFFER_SIZE:I = 0x0

.field public static Ischeck:Z = false

.field private static final REQUEST_PERMISSIONS:I = 0x1

.field public static bitversi:I

.field public static check:Z

.field public static checkesp:I

.field public static daemonPath:Ljava/lang/String;

.field public static device:I

.field public static fixinstallint:Z

.field public static game:Ljava/lang/String;

.field public static gameint:I

.field public static hiderecord:I

.field static instance:Lpubgm/loader/activity/MainActivity;

.field public static kernel:Z

.field public static modeselect:Ljava/lang/String;

.field public static noroot:Z

.field public static skin:I

.field public static socket:Ljava/lang/String;


# instance fields
.field public CURRENT_PACKAGE:Ljava/lang/String;

.field public container:Landroid/widget/LinearLayout;

.field ctx:Landroid/content/Context;

.field public disable:Landroidx/cardview/widget/CardView;

.field public enable:Landroidx/cardview/widget/CardView;

.field handler2:Landroid/os/Handler;

.field private installKernelButton:Lcom/google/android/material/button/MaterialButton;

.field public nameGame:Ljava/lang/String;

.field packageapp:[Ljava/lang/String;

.field private powerSpinnerView:Lcom/skydoves/powerspinner/PowerSpinnerView;

.field public progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

.field root:Landroid/widget/TextView;

.field private runnable:Ljava/lang/Runnable;

.field private spinnerLanguage:Landroidx/appcompat/widget/AppCompatSpinner;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    sput-boolean v2, Lpubgm/loader/activity/MainActivity;->fixinstallint:Z

    sput-boolean v2, Lpubgm/loader/activity/MainActivity;->check:Z

    sput v2, Lpubgm/loader/activity/MainActivity;->hiderecord:I

    sput v2, Lpubgm/loader/activity/MainActivity;->skin:I

    const-wide v0, -0xd32ad693c3a53bdL

    :try_start_f
    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_16
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_f .. :try_end_16} :catch_30

    :goto_16
    sput v3, Lpubgm/loader/activity/MainActivity;->gameint:I

    const/16 v0, 0x40

    sput v0, Lpubgm/loader/activity/MainActivity;->bitversi:I

    sput-boolean v2, Lpubgm/loader/activity/MainActivity;->noroot:Z

    sput v3, Lpubgm/loader/activity/MainActivity;->device:I

    const-wide v0, -0xd32ad523c3a53bdL  # -1.001092847426494E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    sput-boolean v2, Lpubgm/loader/activity/MainActivity;->kernel:Z

    sput-boolean v2, Lpubgm/loader/activity/MainActivity;->Ischeck:Z

    return-void

    :catch_30
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/UnsatisfiedLinkError;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lpubgm/loader/utils/FLog;->error(Ljava/lang/String;)V

    goto :goto_16
.end method

.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lpubgm/loader/utils/ActivityCompat;-><init>()V

    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-wide v2, -0xd32a0e73c3a53bdL  # -1.002748911323535E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-wide v2, -0xd32a0d03c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-wide v2, -0xd32a0c63c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-wide v2, -0xd32a0bb3c3a53bdL  # -1.002771832623148E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-wide v2, -0xd32a0ab3c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    iput-object v0, p0, Lpubgm/loader/activity/MainActivity;->packageapp:[Ljava/lang/String;

    const-wide v0, -0xd32a09a3c3a53bdL

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lpubgm/loader/activity/MainActivity;->nameGame:Ljava/lang/String;

    const-wide v0, -0xd32a0883c3a53bdL  # -1.002798400493154E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lpubgm/loader/activity/MainActivity;->CURRENT_PACKAGE:Ljava/lang/String;

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lpubgm/loader/activity/MainActivity;->handler2:Landroid/os/Handler;

    return-void
.end method

.method private CountTimerAccout()V
    .registers 7

    const/4 v2, 0x0

    const-string v0, "ۚۛۢۚۧۡۘ۟ۦۨۘ۬۬ۖۘۥۢۜۘ۟ۥۥۙۥۤ۬ۤۥۥۢۥ۫ۡ۬"

    move-object v1, v2

    move-object v3, v2

    :goto_5
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v4, 0x1d7

    xor-int/2addr v2, v4

    xor-int/lit16 v2, v2, 0x3ac

    const/16 v4, 0x2fe

    const v5, 0x344b27da

    xor-int/2addr v2, v4

    xor-int/2addr v2, v5

    sparse-switch v2, :sswitch_data_b4

    goto :goto_5

    :sswitch_19
    const-string v0, "ۨ۟۠ۧ۬ۢۗۦۖۘۥۚ۠ۙۚۘۡۨۛۧۥۨۘۥۡۜۘ۟۟۠ۗۨۖ"

    goto :goto_5

    :sswitch_1c
    const v2, 0x1116d974  # 1.1899921E-28f

    const-string v0, "ۜۨۥۘۡۗۛۜۦۚۤۚۥۤۥۘۘۜۘۡۢۥۘۨۛۗ۟ۗۥۙۦۙ۠ۚۖۨۥۨ"

    :goto_21
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v2

    sparse-switch v4, :sswitch_data_da

    goto :goto_21

    :sswitch_2a
    const-string v0, "ۢۧۜۜۜ۟ۙ۟ۨۥۖۜ۠۬ۨۘۡۘۛۧۥۢ۠ۤۡۢۗۦ۬ۧۨۘۛ۠ۜۦ۠ۥۨۛۡۘۗۢ۬ۡۖۢۥ۟۫"

    goto :goto_5

    :sswitch_2d
    const-string v0, "ۜۗ۟ۦۤۥۘۙۚۥۚۘۚ۟ۙۥۗۥۘۦۚ۟۠ۦۛۦۖۘۘۖۘۘۘ۬ۨۖۘ۫ۥۘۤ۬ۚۚۗۚۗۚۖۘۢۥ۫ۗۙۡۘۜۨ۟"

    goto :goto_21

    :sswitch_30
    const v4, 0x1a63d4a0

    const-string v0, "۟ۦۚۚۜ۟۫۬ۦۘۘۢۢۖ۬ۦۘ۫ۚۤۜۢۚۧۤ۫ۗۗۥۢۖۡۤۤۚ۬ۦۤۙۗۢۜۢۘۘۘۨۤۛ۟ۨ"

    :goto_35
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_ec

    goto :goto_35

    :sswitch_3e
    invoke-static {}, Lpubgm/loader/server/ApiServer;->EXP()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_4b

    const-string v0, "ۡۛۙۛۧ۠۬ۤ۫ۨۢۜۙ۫ۡۘ۠۫ۤۖ۠ۥۤۨۦۘ۬ۢۗۦۙ۠ۤۙۡۘ۬ۥۦۘ۟ۦ۟ۡۥ۬ۡۤۤ۠ۗۘۘ"

    goto :goto_35

    :cond_4b
    const-string v0, "ۜۖۨۘۜۢۜۥۢۡۘۥ۬ۦۘ۫ۜۨۘۢ۠ۚۢۘۦ۬ۦۦۢۦۚۧۚۡۘ۫ۙۖۙ۫ۥ۫ۤۥۘۜۨۖۗۜۗ۠ۛۨ"

    goto :goto_35

    :sswitch_4e
    const-string v0, "ۛۥۚۙۗۘۘۜۨۜۘۧۜ۬ۜۜۢۧ۠ۧۜ۟ۘۡۜۦۘۜۚۘۦۖۘۙ۠ۤ۬ۜۖۘۨ۫۠ۡۢ۟ۜ۠۟۟۫"

    goto :goto_35

    :sswitch_51
    const-string v0, "۬ۢ۠۟ۨOۡۦۜۘۜۧ۬ۡۜۢۦۢۨۛ۫ۤۜۧۧۥ۠ۥۧۙۛۤۤ۟ۥۚ۠ۙۥۨۘ"

    goto :goto_21

    :sswitch_54
    const-string v0, "ۚ۫ۜۘۚۤۨۘۜۘۘۙۥۛۛۚۚ۬ۧۦۧ۬ۘۛ۫۫ۛۘۖۘۜۘۚۤۘۘۧۦ۫ۚۚۘۘ۬ۜۚ"

    goto :goto_21

    :sswitch_57
    const-string v0, "ۦۡۡۘۜۘۥۨۡۗۜۢۖۥۡ۬ۢۜ۫ۦۖۖۘ۠ۙۚ۟ۜۘۙۢ۬ۚۥۨۘۦۧۨۘ"

    goto :goto_5

    :sswitch_5a
    sget-object v2, Lpubgm/loader/activity/MainActivity;->instance:Lpubgm/loader/activity/MainActivity;

    const-string v0, "۠ۥۡۘۨۥۨۦۗۚ۬ۚ۫۬ۜ۠ۗۡۥۛۖۘۙۘۨۦ۬ۜۘۧ۬ۦ"

    move-object v3, v2

    goto :goto_5

    :sswitch_60
    const v2, 0x41ce9e26

    const-string v0, "ۛۢ۬ۛۤۜۘۗۧ۟ۨۧۢۘۨۢۦۡ۬ۡۧۦۘۧۡۡ۠ۨۧۛۚۡۙۧۗۗۘۥ"

    :goto_65
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v2

    sparse-switch v4, :sswitch_data_fe

    goto :goto_65

    :sswitch_6e
    const-string v0, "ۥۚۜۘۥۗۚۢۗۡۢۥۛۜۗۥۥۗۘۘۚۘۗۚۦ۠ۨۦ۟ۛۘۜۘ۠۟ۛۧۘۥۘۦ۟ۥۤ۫۠ۡۡ۟ۦۢۥۘۖۦۘ۠ۧۗ"

    goto :goto_5

    :sswitch_71
    const-string v0, "ۗۜۥۘۙۡ۟ۦۘۘۡۗۛۗۜۘۤ۠ۜۘۤ۟ۥۘ۟ۜ۠ۘۤ۬ۨۚ۟ۦۥۛۚۖۘۙۚۚ۬ۛۘ"

    goto :goto_65

    :sswitch_74
    const v4, -0x4278aa40

    const-string v0, "۫ۡۨۡۧۤۚ۟ۨ۫ۤۦۛۚۚ۠ۧۨ۬ۡۖۤ۫۫ۢ۟ۥۘ۬ۘۢ"

    :goto_79
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_110

    goto :goto_79

    :sswitch_82
    if-eqz v3, :cond_87

    const-string v0, "۬ۨۘ۟ۛ۫ۖۘۢۖۘۥۥۥۘۘ۫ۘۘۦۛۡۤۢۖۘۖ۫ۙۢۡۧۘ۬۠۟ۦۦۛۧۢۦۘ۠ۥۛ۫ۘۚۡۨۘ"

    goto :goto_79

    :cond_87
    const-string v0, "ۖۘۛۛۤۥۘۛۦۦۢ۠ۦۘۢۚۛ۫ۢۥۘۧۡۘۘۡۧۧ۠ۨ۬ۥۧۙ"

    goto :goto_79

    :sswitch_8a
    const-string v0, "۠۠۬ۤ۫ۖۘۘۗۚۛۨۧۘۡۡۚ۬ۚۘۗۙ۟ۥۧۡۡۡۦۘ۠ۢۜ۫ۤۨۘ۫ۨۨۘ"

    goto :goto_79

    :sswitch_8d
    const-string v0, "ۚ۠۫ۤۧۦۘۤۛۘ۟ۡۥۘۛۦۡۘۢۜۥۘ۟ۖۡۘۛۜۘۘۘ۠ۦۘۧ۟ۖۘ۫ۡۦۘۡۨۦۖۖۙۧۡۛۙۦۙ۬۫ۤ"

    goto :goto_65

    :sswitch_90
    const-string v0, "ۦ۟ۢۧۙۥۘۘ۬۫ۡۙۡۜ۬ۚۥۜۥۘ۟ۘۖۘۤ۬ۥۘ۠ۡۗ۫ۨۘۛۙۛ۫۬۫ۦۖۚ۫۫۠"

    goto :goto_65

    :sswitch_93
    const-string v0, "ۙۧۘۤۙۦۘ۟ۛۘۘۡۤۡۘۡۖۘۧۜۧۘۖۖۚ۠ۤۜۘۛۛۚۡۛ۫ۚۦۥۘۙۤۚۨۜۦۥۡۗۚۥۘۨ۬ۜۘ۟ۥ۟۟ۗۢ"

    goto/16 :goto_5

    :sswitch_97
    invoke-virtual {v3}, Lpubgm/loader/activity/MainActivity;->finishAffinity()V

    const-string v0, "ۥۚۜۘۥۗۚۢۗۡۢۥۛۜۗۥۥۗۘۘۚۘۗۚۦ۠ۨۦ۟ۛۘۜۘ۠۟ۛۧۘۥۘۦ۟ۥۤ۫۠ۡۡ۟ۦۢۥۘۖۦۘ۠ۧۗ"

    goto/16 :goto_5

    :sswitch_9e
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    const-string v0, "ۧۖۖ۫ۨۖۘ۬ۥۧۘۙۖۜۦۦ۠ۥۨۛۜ۠ۨ۠ۡۘ۠ۖۘۘ۬ۛۙ۬ۛۡۘۦ۬ۚۤۧ۫۟ۚۘۘ"

    goto/16 :goto_5

    :sswitch_a7
    new-instance v0, Lpubgm/loader/activity/MainActivity$8;

    invoke-direct {v0, p0, v1}, Lpubgm/loader/activity/MainActivity$8;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/os/Handler;)V

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const-string v0, "۫ۧۜۡۤۜ۠ۜۘۦ۫ۜۨۦۨۥۛۨۘۛۦۧۙۘۘۚۤۥۘ۠ۖۖ"

    goto/16 :goto_5

    :sswitch_b3
    return-void

    :sswitch_data_b4
    .sparse-switch
        -0x73979f30 -> :sswitch_a7
        -0x515c6c6b -> :sswitch_b3
        -0x4890cb75 -> :sswitch_97
        -0x1a31528c -> :sswitch_19
        0xbd49046 -> :sswitch_5a
        0x1ed08f3a -> :sswitch_60
        0x2caffb30 -> :sswitch_b3
        0x60bfb871 -> :sswitch_1c
        0x6fa5d3c4 -> :sswitch_9e
    .end sparse-switch

    :sswitch_data_da
    .sparse-switch
        -0x60738778 -> :sswitch_30
        -0x4cc405df -> :sswitch_57
        0x311c54c -> :sswitch_54
        0x29d9c98e -> :sswitch_2a
    .end sparse-switch

    :sswitch_data_ec
    .sparse-switch
        -0x36f8cf20 -> :sswitch_4e
        -0x955ff2a -> :sswitch_3e
        0x20cdbbcc -> :sswitch_2d
        0x254c5c5a -> :sswitch_51
    .end sparse-switch

    :sswitch_data_fe
    .sparse-switch
        -0xd67cdd4 -> :sswitch_90
        0x2172ae23 -> :sswitch_6e
        0x4f988154 -> :sswitch_93
        0x78e5f5f6 -> :sswitch_74
    .end sparse-switch

    :sswitch_data_110
    .sparse-switch
        -0x5aadfc1d -> :sswitch_71
        -0x54c2dca0 -> :sswitch_8a
        -0x1c405159 -> :sswitch_82
        0x4ebbe5a8 -> :sswitch_8d
    .end sparse-switch
.end method

.method private ExecuteElf(Ljava/lang/String;)V
    .registers 5

    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v1, v2}, Ljava/lang/Runtime;->exec(Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_9} :catch_a

    :goto_9
    return-void

    :catch_a
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_9
.end method

.method private Loadssets()V
    .registers 5

    const-string v0, "ۛۧۢۢ۫ۘۘۙۦۜۘۗۡۗ۟ۘۖۘۦۘۨۘۘۥۜۘ۟ۥۙۘ۠ۘۘۜ۟ۜ۫ۧۢۨ۬۬ۧۛۘۘۚ۬ۜۦۖۤ۬۠ۚۗۧۙۡۡۚ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x11

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x189

    const/16 v2, 0x24

    const v3, -0x2c287230

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_a2

    goto :goto_2

    :sswitch_16
    const-string v0, "ۥۡ۫ۗۘۡۗۧۡۤۦۨۜۗۨ۟ۦۘۢۥ۠ۜۖۧۘ۠ۜۦۘۘ۫ۧ"

    goto :goto_2

    :sswitch_19
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-wide v2, -0xd32a1613c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-wide v2, -0xd32a1673c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lpubgm/loader/activity/MainActivity;->MoveAssets(Ljava/lang/String;Ljava/lang/String;)Z

    const-string v0, "ۤ۟ۜۧۖ۬ۨۙۦ۫ۡۜۗۘۜۖۡۜ۟ۙۗۚۡ۫ۤۛۙۤۧ۫ۢۦۨۘۙۜۛ"

    goto :goto_2

    :sswitch_46
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-wide v2, -0xd32a1683c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-wide v2, -0xd32a16e3c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lpubgm/loader/activity/MainActivity;->MoveAssets(Ljava/lang/String;Ljava/lang/String;)Z

    const-string v0, "۟۬ۤۚۤ۠ۗ۟ۖۘ۬ۤۦۢۜۘۘۢۧۢۡۙۨۘۙۨۡۘۤ۬۫۫ۡۧۘ"

    goto :goto_2

    :sswitch_73
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-wide v2, -0xd32a1503c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-wide v2, -0xd32a1563c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lpubgm/loader/activity/MainActivity;->MoveAssets(Ljava/lang/String;Ljava/lang/String;)Z

    const-string v0, "ۜۧۢ۫ۥۘۨ۠ۛۘ۟ۡ۬ۤۡۘۚۤۖۘۗۨۘۙ۬ۥۘۤۤۡۘ۫۟ۥۘۗ۠۫ۛۙۤۜۥۘۘۡۥۜۘ"

    goto/16 :goto_2

    :sswitch_a1
    return-void

    :sswitch_data_a2
    .sparse-switch
        -0x49c49bbe -> :sswitch_16
        0x23b6baf2 -> :sswitch_73
        0x305674c4 -> :sswitch_19
        0x65cea038 -> :sswitch_46
        0x74676153 -> :sswitch_a1
    .end sparse-switch
.end method

.method private MoveAssets(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 12

    const/4 v1, 0x0

    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const v3, -0x17790ec5

    const-string v0, "ۡۗۜ۠ۡ۠ۜۖۘۧ۠ۘۗۗۥۥۜ۠ۗۜۗۦ۫ۥۧۙۨ۟"

    :goto_b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_e6

    goto :goto_b

    :sswitch_14
    const v4, 0xe2e9d9f

    const-string v0, "ۡۦۤۘ۟ۛۚۨ۬ۚۡۜۘ۫ۢۢۨ۠ۥۘۗ۫ۚۦۨۥ۠ۛۤۦ۫ۙۗۗۥۦۛ۬ۨۨۡۡ۟ۖ۫ۜۨۘ۫۫ۚ"

    :goto_19
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_f8

    goto :goto_19

    :sswitch_22
    const-string v0, "ۧۙۜۜۦۥۘۨۨۡۘۤۧ۟ۖۥۜۜ۬ۜۘۛۘ۬ۜ۫ۙۤ۫ۜۖۧۘۛۘۦۘۖ۫ۨۥۡۨۗۨۘۦۗۢ۟ۦ۬۫ۦۥۘۚۚۤ"

    goto :goto_b

    :cond_25
    const-string v0, "ۧۦۥۘۨۤۖۘۛۜۥۘۢۡ۫ۖۘۗۢۤۨۘۜۘۤۤۥۨۘۚۛۦۥۙۨۘۗۦۨۦۜۚۧۦۘۤۘۦ"

    goto :goto_19

    :sswitch_28
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_25

    const-string v0, "ۡۛۡۜ۫ۧۜۗۘۙۨۙۙۘۚۦ۟ۗۜۥۜۘۧۧۢۛۚۖۘۗۜۜ۟۫ۥۘۙ۬ۖۦۖ۠ۚۥۜ۫ۙۥۤۙۦۘۨ۬۬۟ۦۥ"

    goto :goto_19

    :sswitch_31
    const-string v0, "ۨۙۦۘ۫۬ۛۡۖۧۧۤۦ۫ۛۜۘۚۗۜۖ۫ۥ۫ۘۘۦۦۨۦۘۘۙۨۤۧ۠ۖۘۡۡۘ۟۟ۧ"

    goto :goto_19

    :sswitch_34
    const-string v0, "ۤ۟ۥۜۥۜۘ۫ۙ۟۠۟ۨۘۚۡۙۚۢۜ۬۫۫ۙۗۥۘ۬ۤ۫ۤۜۖۚۧۛۧۧۘۘۜۧۘ۠ۜ۠"

    goto :goto_b

    :sswitch_37
    const-string v0, "ۖۤۖۘۢ۟۫۫۠ۜۙۨ۫۬ۨۚۚ۟ۚ۬ۤۜۘۦۢۥۚۗۧ۫ۜۧۖۛۥۘ۟ۥ۬"

    goto :goto_b

    :sswitch_3a
    const v3, 0x23d21999

    const-string v0, "۫۬ۧۨۢۤۙۢۗۨۧۥۘۛۨ۬ۖۖۦۧ۟ۡۘۖۛۘۗۨۢ۫ۡۧۘ۬۟ۥۘۢۗۢ"

    :goto_3f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_10a

    goto :goto_3f

    :sswitch_48
    const-string v0, "ۤۘ۟ۗۙ۟ۥۖۦۘۥ۠ۖۜۡۘ۟ۙۡۙۤۨ۬ۦۘۜۘۨۗۘۦۧۥۦۘۛۧ۫"

    goto :goto_3f

    :sswitch_4b
    const-string v0, "ۡۡۛ۫ۙۘۘۚۛ۫ۨۥۘۙۦۥ۟۬ۘۘۨۨۡۘۧۡۗۚۦۘۘۧ۫ۚۚۘ۠ۢۘۘۘ"

    goto :goto_3f

    :sswitch_4e
    const v4, -0x3f3ca0c6

    const-string v0, "۟۠ۖۘۜۖۧۤ۟ۥۡۢۘۘۧۡۜۘۥۧۙۨۛۛۛۗ۟ۙۦۜۙۛۗۢۨۡۥ۟ۨۘۛۛۜ۬۟ۗ"

    :goto_53
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_11c

    goto :goto_53

    :sswitch_5c
    const-string v0, "۟ۜۧۘ۫ۛ۠۫ۡۢۦ۬ۙۢۗ۟ۦۙۜۢۢۦۘۥۖۜۘ۠ۦۥۘۜۘۘ"

    goto :goto_3f

    :cond_5f
    const-string v0, "ۘۚۙۡۗۥۘ۫۠۟۟ۡۤۙۨۥۘۖۙۡۥۜۖۥۦۢۨۘۨ۠ۘۘۛۨۖۜۜ۫ۚ۬ۦۨۗ۫ۦۤۙۧۖۙۛۘ۠ۗ۠ۦ"

    goto :goto_53

    :sswitch_62
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-nez v0, :cond_5f

    const-string v0, "ۡۦۦۘۖۘ۫۟ۨۨۢۖۤۢۢۤ۟ۛۡۨۚۚۧۦۖۘۨۘۤۚۥۘ"

    goto :goto_53

    :sswitch_6b
    const-string v0, "ۚۙۨۘۡۚۖۚ۠ۜۘۨ۠ۗۦۡۙۤۥۗۙۢۗۗۜ۠ۤۢۨ۬۬۠۠ۡۜۚۘۘ"

    goto :goto_53

    :sswitch_6e
    const-wide v2, -0xd32a15c3c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const-wide v2, -0xd32a1493c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move v0, v1

    :goto_84
    return v0

    :sswitch_85
    :try_start_85
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v3

    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v2, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/16 v0, 0x400

    new-array v4, v0, [B

    :goto_9b
    invoke-virtual {v3, v4}, Ljava/io/InputStream;->read([B)I

    move-result v5

    const v6, 0x53726d31

    const-string v0, "ۥۚۜۜ۫ۨۘۖۙۨۢ۫ۡۘۤۧ۟ۖۨۢ۬ۦۧۘۘۢۦ۠ۨۢۨۘۖۘۖۥۥۘۥۧۘۜ۟ۨۗۡۜۘۥۜۚۚۧۢۚۛۖۡۗ"

    :goto_a4
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v6

    sparse-switch v7, :sswitch_data_12e

    goto :goto_a4

    :sswitch_ad
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    invoke-virtual {v2}, Ljava/io/FileOutputStream;->flush()V

    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V

    const/4 v0, 0x1

    goto :goto_84

    :sswitch_b8
    const-string v0, "ۧۤۚۘۧۘۘۗۗ۟۫ۗۜۘۗۢۦۘۙۖۧۗۖۦۙۤۛۚ۠۟۟ۗۙۥۗ۟ۛۥ"

    goto :goto_a4

    :sswitch_bb
    const v7, -0x63d53096

    const-string v0, "ۖۨۤ۟۟ۡۘۧۨۨۘۦۙۚۤۛۧۜۘۥۘۜۚۡۧۘۗۙۙ۠۟ۨۧۘۡ۬۟ۨۢ۠۟ۥۤۤۗۤۨۘۤۘۥ"

    :goto_c0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_140

    goto :goto_c0

    :sswitch_c9
    const-string v0, "ۢ۠ۘۘۧۦۡۦ۟ۘۘۖ۠ۦۘۧ۟ۜۘۦۧۤۢۖۙۧۖ۠ۛۢۘۘۛ۫ۤۥ۬ۨۘ۠ۘۜۘ"

    goto :goto_a4

    :cond_cc
    const-string v0, "ۗۤ۫ۖۗۤۥۢ۟ۗۖۚۜۙۢ۟ۙۘۧۥۡۘۛۛۥۥۤۘۚۜۖۘ۫ۦۚۘۡۥۙ۠ۚۚۖ"

    goto :goto_c0

    :sswitch_cf
    const/4 v0, -0x1

    if-eq v0, v5, :cond_cc

    const-string v0, "۬ۦۜۨۘۜۡۤۦ۬ۦۥۗۦۡۥۤۜۘ۟۬ۥ۬ۡۤۚۘۧ۬ۤۛۗۘۡۙۡۘۖۖۖۘۘ۠ۤۖۖۘۚۥۡۙۥۦۘۥۥ۬"

    goto :goto_c0

    :sswitch_d5
    const-string v0, "ۥۡ۫ۤۢۦۚ۟۫ۧۘ۫۠ۚۜ۬ۘۨۜۧۜۥۜۤۗۥۨۘۨۜۦۘۘۥۙۨ۠۬ۨ۠ۢۗۨۧۗۦۢۖۘۖۘۙۘۛۖۨۙ"
    :try_end_d7
    .catch Ljava/io/IOException; {:try_start_85 .. :try_end_d7} :catch_e0

    goto :goto_c0

    :sswitch_d8
    const-string v0, "ۘۙۧ۫ۖۥۘۙۡۥۦ۬ۖۘۦۢۢۢۨۡۘۡۙۘۥۙۧ۫ۦۢۥۥ"

    goto :goto_a4

    :sswitch_db
    const/4 v0, 0x0

    :try_start_dc
    invoke-virtual {v2, v4, v0, v5}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_df
    .catch Ljava/io/IOException; {:try_start_dc .. :try_end_df} :catch_e0

    goto :goto_9b

    :catch_e0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    move v0, v1

    goto :goto_84

    :sswitch_data_e6
    .sparse-switch
        -0x460cdd90 -> :sswitch_85
        -0x42c306d4 -> :sswitch_3a
        0xfc0d6ce -> :sswitch_14
        0x6113e46b -> :sswitch_37
    .end sparse-switch

    :sswitch_data_f8
    .sparse-switch
        -0x7cc1b874 -> :sswitch_22
        -0x6c9f9eea -> :sswitch_31
        -0x6bf9f0bf -> :sswitch_28
        -0x41fec02 -> :sswitch_34
    .end sparse-switch

    :sswitch_data_10a
    .sparse-switch
        -0x25a33f30 -> :sswitch_85
        0x16e65e82 -> :sswitch_6e
        0x1ba657c5 -> :sswitch_48
        0x58f0e7c9 -> :sswitch_4e
    .end sparse-switch

    :sswitch_data_11c
    .sparse-switch
        -0x7f15f8bc -> :sswitch_6b
        -0x40e18005 -> :sswitch_4b
        -0x1512818d -> :sswitch_5c
        -0x63091ca -> :sswitch_62
    .end sparse-switch

    :sswitch_data_12e
    .sparse-switch
        -0x7826c6db -> :sswitch_bb
        -0x49696a5d -> :sswitch_db
        0x25641ee5 -> :sswitch_ad
        0x381dace7 -> :sswitch_d8
    .end sparse-switch

    :sswitch_data_140
    .sparse-switch
        -0x6d501e53 -> :sswitch_c9
        -0x4d7fbaa3 -> :sswitch_cf
        0x43dc76f8 -> :sswitch_d5
        0x7a63d3e4 -> :sswitch_b8
    .end sparse-switch
.end method

.method static synthetic access$000(Lpubgm/loader/activity/MainActivity;)Ljava/lang/Runnable;
    .registers 5

    const-string v0, "ۖ۫ۢۗۦۚۜ۫۟ۦۙۖۚۗۡۘ۟ۤۚ۬ۨۚۨۗ۬ۢۧۗۗۧۖ۫ۦۘۧۥۦۘۛ۫ۙ۬ۚۢۚۨۚۢۡۜۖ۫۬ۚ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x360

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x354

    const/16 v2, 0x286

    const v3, -0x41974cc6

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_1c

    goto :goto_2

    :sswitch_16
    const-string v0, "ۛۧ۬ۖ۫ۖۘۘۗ۫ۥ۟ۥۘۘۜۘۘۨۥۧۘ۟۟ۡ۠۠ۥۨۜۘۘۛۗۦ۬ۖۛۤۙۗۘۧۘۘۖۧۧۘ۬ۛۧۛ"

    goto :goto_2

    :sswitch_19
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->runnable:Ljava/lang/Runnable;

    return-object v0

    :sswitch_data_1c
    .sparse-switch
        -0x517c5d5f -> :sswitch_16
        -0x37ccea15 -> :sswitch_19
    .end sparse-switch
.end method

.method static synthetic access$100(Lpubgm/loader/activity/MainActivity;JJJJ)V
    .registers 14

    const-string v0, "۬ۙ۫ۢۢۥۥۚۘۜ۠ۛۙۙۗۛۖۤۘۚۢۥ۫۬۟ۜۖۤۢۜ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x247

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x38b

    const/16 v2, 0x2f8

    const v3, -0x3ae1d3df

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_2c

    goto :goto_2

    :sswitch_16
    const-string v0, "۠۟ۗۨۖۘ۫ۘۜۢۡۘۜۤۘۘۜ۟ۖۗۗۙۙۙۚۙۤۦۢۛۘۘ"

    goto :goto_2

    :sswitch_19
    const-string v0, "۠ۥۢۢۙۖۧۖۖۙ۠ۦۡۘۧۡۙۛۙۦۘۧۖۛۨۘۜۢۢۜۘۧۦ۟۠ۥۘۛۨۗۥ۫"

    goto :goto_2

    :sswitch_1c
    const-string v0, "ۧ۫ۘۗۨۖ۟ۚۖۦ۠ۦۗۙۥۘ۫ۤ۟ۛۡۜۘۢۨۤ۫ۖ۫ۛۛۡۖۙۗۤۚۥۢۜۘۘۦۜۘۤ۫ۦۘ۬ۨ۬ۖۧۨ۬ۡۨۘ"

    goto :goto_2

    :sswitch_1f
    const-string v0, "ۛۗۖۛۚۖۙۘۢۜۦ۠ۛۧۤ۬ۚۥۢۥ۬۫ۤۢۘۨۚۗۖۨۘ۬ۛۗۜۧۦۦۢ۫ۡۥۘۗ۫ۜۘۥۜۗۗ۟ۡۘۙۤ۫"

    goto :goto_2

    :sswitch_22
    const-string v0, "ۨ۠ۜۘ۬ۖ۠ۡۚۧۚۧۦۨۛۖۘۦۤۡ۠ۧۗۙ۬ۜۡۚۤۦۘۥ۫ۘ۠۠ۙ۠ۚ۟ۜۘۦ۟ۗۜۖۥۘ۟ۡۧۘ"

    goto :goto_2

    :sswitch_25
    invoke-direct/range {p0 .. p8}, Lpubgm/loader/activity/MainActivity;->updateCountdownUI(JJJJ)V

    const-string v0, "ۡۙۘۜۜۗۧۦۚۚۛۥۧۖۚۧۨۘ۟۠ۘۘ۫ۖۛۜۤ۟ۙۖۘۛ۟ۘ۠ۛۡ۟ۧۦۘۘۨۖ"

    goto :goto_2

    :sswitch_2b
    return-void

    :sswitch_data_2c
    .sparse-switch
        -0x4fd0dcba -> :sswitch_2b
        -0x4d76378f -> :sswitch_19
        -0x4880d99a -> :sswitch_22
        -0x454d6413 -> :sswitch_16
        -0x9bf6d4a -> :sswitch_1c
        0x7f3aa12 -> :sswitch_25
        0x57c08331 -> :sswitch_1f
    .end sparse-switch
.end method

.method private animateNavItem(Landroid/view/View;)V
    .registers 13

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const-string v0, "ۛۨ۬ۜۛ۬۟ۜۜ۫ۧۘۘۡۥ۬ۖۜۘۥۧۡ۬۬ۥۘۘۥۘۦۧۦۥ۠ۢ۟ۙۥۘۢۨۖۘۨۙۘۘ"

    :goto_9
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    const/16 v9, 0x1c5

    xor-int/2addr v8, v9

    xor-int/lit8 v8, v8, 0x63

    const/16 v9, 0x2be

    const v10, 0x3892e905

    xor-int/2addr v8, v9

    xor-int/2addr v8, v10

    sparse-switch v8, :sswitch_data_e2

    goto :goto_9

    :sswitch_1d
    const-string v0, "۫ۖۨۘۤ۟ۙ۬ۖۘۧۤۚۚۥۛ۬ۤۧۛۡۜۘۖۗۡۘۦۢ۫ۖ۠ۚۗۖۨۘۘۨۖۘۜۛۚ۠ۥۘ۟ۘۥۘۙۥۛ"

    goto :goto_9

    :sswitch_20
    const-string v0, "ۡۖۡۘۧۖۜ۫ۛۡۡۜۘۜۨۖۢۘ۠ۙۛ۬ۛ۠ۘۜ۫ۨۜ۟ۜۥۤۡ۟ۚ۫ۘۦ۟۟ۤۜۙۧۜۘۦۢۛ"

    goto :goto_9

    :sswitch_23
    const-wide v8, -0xd32a1d23c3a53bdL

    invoke-static {v8, v9}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    new-array v7, v7, [F

    fill-array-data v7, :array_12c

    invoke-static {p1, v0, v7}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v7

    const-string v0, "ۛۢۘۘۤۖۡۘۚۜۡۖۘۡۘۦۨۜۜۛۧۢ۠۫۠۬ۤۘۘۘۘۦۡ۫ۜۖۙۚۖۘۨۘۡۨۨۘۢۥۖ۠۠ۤۛۡۘۨ۠ۡ"

    goto :goto_9

    :sswitch_39
    const-wide v8, -0xd32a1db3c3a53bdL

    invoke-static {v8, v9}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    new-array v6, v6, [F

    fill-array-data v6, :array_134

    invoke-static {p1, v0, v6}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v6

    const-string v0, "۬ۜ۫ۢۨۖۘۡۗۖۘۨ۬ۨۘۤ۬ۖۘۙ۠۫ۤ۠ۡ۫ۤۨۘۚۥۜۘۡۘۨۦۖۨ۟ۥۜۘۧۢ۠ۖ۠ۖ۬ۚ۠ۧۙۛ۬ۗۡۘۗ۬ۖۘ"

    goto :goto_9

    :sswitch_4f
    const-wide v8, -0xd32a1dc3c3a53bdL

    invoke-static {v8, v9}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    new-array v5, v5, [F

    fill-array-data v5, :array_13c

    invoke-static {p1, v0, v5}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v5

    const-string v0, "۟۟ۚۡ۬ۨۘۘ۟ۙ۫۟ۘۘۙۥۖۘۘۡۗ۬ۦۤۘۚۥۘۤۗۢ۬ۗۤ۠ۤۚ۫ۖ۫ۧۛۘۘۘۚۗ"

    goto :goto_9

    :sswitch_65
    const-wide v8, -0xd32a1c53c3a53bdL

    invoke-static {v8, v9}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    new-array v4, v4, [F

    fill-array-data v4, :array_144

    invoke-static {p1, v0, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v4

    const-string v0, "ۘۙۖۘ۟ۦۢ۫ۧۥۘۡ۬ۜۘۚۡ۬ۧۗۘ۬ۥۛۜۜۨۘۛۚۥۘۜۛۡ"

    goto :goto_9

    :sswitch_7b
    const-wide/16 v8, 0x64

    invoke-virtual {v7, v8, v9}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const-string v0, "ۛ۬ۘ۬۠۫ۗۡۡۘۡۦۖۗۦۘۡۜ۠ۖۗۧۙۤۡۘۤۘۦۙۡۨۘۖ۫ۥۤۜ۟ۡ۫ۙۜۦۦۘۜۖۖۢۚۙ"

    goto :goto_9

    :sswitch_83
    const-wide/16 v8, 0x64

    invoke-virtual {v6, v8, v9}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const-string v0, "ۘۛۖۛ۠ۜۘۢۖۘۖۡۦۘ۫۠ۢۥۘ۬ۚۧۧۢۡ۬ۤۙۡ۬۫"

    goto/16 :goto_9

    :sswitch_8c
    const-wide/16 v8, 0x64

    invoke-virtual {v5, v8, v9}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const-string v0, "ۛۦۘۛ۟ۡۘۡۛۡۧ۫ۦۘۧۘۡۘۨۘۜ۟۫ۧۙ۟ۦۙ۠ۨ۬ۜۧۘ۟ۗۡۚۗۛۦۘۡۘۗۖۙۨۥۡۙۚۡ۫ۦۘۗۡۨۘ"

    goto/16 :goto_9

    :sswitch_95
    const-wide/16 v8, 0x64

    invoke-virtual {v4, v8, v9}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const-string v0, "ۢۙۨ۬۫ۧۢۥۛ۟ۢۦۡ۬ۤۗۗۖۨۛۢۗۖ۠ۚۖۘ۠۠ۚ"

    goto/16 :goto_9

    :sswitch_9e
    new-instance v3, Landroid/animation/AnimatorSet;

    invoke-direct {v3}, Landroid/animation/AnimatorSet;-><init>()V

    const-string v0, "۬ۨۥۖۙۡۖۥۖۡۛۡۘۗ۫ۡۘۘ۬ۜۘۛ۫ۡۜۚۦۧ۫ۨۥۖۘۧۗۡۙۧ۬ۨۤۙۗ۠ۙۨۘۖۗۥۘۦۢۘ۟ۧۡۘ"

    goto/16 :goto_9

    :sswitch_a7
    invoke-virtual {v3, v7}, Landroid/animation/AnimatorSet;->play(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    move-result-object v0

    invoke-virtual {v0, v6}, Landroid/animation/AnimatorSet$Builder;->with(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    const-string v0, "ۜۤ۫ۛۙ۠ۛۤۚۦۤ۫ۥۘۗۤۢۡۜ۬ۖۘۤۙ۬۠۟ۥۢۡۧۡ۟ۧۚ۠ۡ۠۟ۘۘۙ۟ۛ"

    goto/16 :goto_9

    :sswitch_b2
    new-instance v2, Landroid/animation/AnimatorSet;

    invoke-direct {v2}, Landroid/animation/AnimatorSet;-><init>()V

    const-string v0, "ۦۧۢ۠۬ۜۘۗۡۤ۟ۜۦۘۨۢۦۘ۟ۧ۬۟ۥۘۘۚۖۜۘۖۛۖۢۗۖۛۦۘ۬۟ۥۘ"

    goto/16 :goto_9

    :sswitch_bb
    invoke-virtual {v2, v5}, Landroid/animation/AnimatorSet;->play(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/animation/AnimatorSet$Builder;->with(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    const-string v0, "ۥۤۦۢۢ۠ۥۢۤۢ۬ۦۡۚۥۨۗۧۤۘۘۘۨۥۨۘ۫۠ۜ۬ۤ"

    goto/16 :goto_9

    :sswitch_c6
    new-instance v1, Landroid/animation/AnimatorSet;

    invoke-direct {v1}, Landroid/animation/AnimatorSet;-><init>()V

    const-string v0, "۠ۡ۬۫ۥۛۨۧۜۜۜۥۘ۠ۤۧۤۚ۬ۤ۬ۡۘ۫ۛۥ۬ۡ۬ۗۖۥۚۤ۬ۤ۠ۜۡۘۤۚۥۤۨۧۢۙۡۘۥۥۡۘ۟"

    goto/16 :goto_9

    :sswitch_cf
    invoke-virtual {v1, v3}, Landroid/animation/AnimatorSet;->play(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/animation/AnimatorSet$Builder;->before(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    const-string v0, "ۚۥۦۥۥۖۜۗۡ۟۠ۙ۬ۢۦۤۚۘۘ۠ۜ۠۫ۤۦۘۥۦۘۘۜۥۡۘۖ۫ۥۖۜۖ"

    goto/16 :goto_9

    :sswitch_da
    invoke-virtual {v1}, Landroid/animation/AnimatorSet;->start()V

    const-string v0, "ۡۜۜۤۖۘۗۢۥۥۖ۟ۚۙ۠ۚ۟ۙۖۧۥۥۙۥۘۡۙۤۖ۠ۖۧۨۘۡۥۘ"

    goto/16 :goto_9

    :sswitch_e1
    return-void

    :sswitch_data_e2
    .sparse-switch
        -0x7165c056 -> :sswitch_b2
        -0x64bc4cc0 -> :sswitch_65
        -0x5ab9bb6e -> :sswitch_7b
        -0x40de0c8e -> :sswitch_9e
        -0x3bf25d9b -> :sswitch_1d
        -0x25f224b0 -> :sswitch_95
        -0x1829122f -> :sswitch_e1
        -0x1739f1c -> :sswitch_cf
        0x78e6583 -> :sswitch_20
        0x11da854a -> :sswitch_da
        0x17282be2 -> :sswitch_8c
        0x1a1d8546 -> :sswitch_39
        0x2e1bfd56 -> :sswitch_23
        0x2e53ab26 -> :sswitch_83
        0x56e01817 -> :sswitch_4f
        0x6930e982 -> :sswitch_a7
        0x69cde010 -> :sswitch_bb
        0x6ff6f0d9 -> :sswitch_c6
    .end sparse-switch

    :array_12c
    .array-data 4
        0x3f800000  # 1.0f
        0x3f4ccccd  # 0.8f
    .end array-data

    :array_134
    .array-data 4
        0x3f800000  # 1.0f
        0x3f4ccccd  # 0.8f
    .end array-data

    :array_13c
    .array-data 4
        0x3f4ccccd  # 0.8f
        0x3f800000  # 1.0f
    .end array-data

    :array_144
    .array-data 4
        0x3f4ccccd  # 0.8f
        0x3f800000  # 1.0f
    .end array-data
.end method

.method public static get()Lpubgm/loader/activity/MainActivity;
    .registers 4

    const-string v0, "ۤۢ۬ۧۦۘۜۙۨۙۥۗۤۘۨۢ۟ۖۤۖ۫ۦ۬ۥۧۘ۫۬ۤ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x158

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x358

    const/16 v2, 0x389

    const v3, -0x101c7a3a

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    packed-switch v1, :pswitch_data_1a

    goto :goto_2

    :pswitch_16  #0x4fa319b3
    sget-object v0, Lpubgm/loader/activity/MainActivity;->instance:Lpubgm/loader/activity/MainActivity;

    return-object v0

    nop

    :pswitch_data_1a
    .packed-switch 0x4fa319b3
        :pswitch_16  #4fa319b3
    .end packed-switch
.end method

.method private getKernelIndex(Ljava/lang/String;)I
    .registers 8

    const-string v0, "ۢۨۖۘۡۦۡۘۙۖۦۘ۬ۨ۬ۥ۫ۙۖ۟ۢۢۚۡۘۚ۟ۥۘۨۙۜۘ۫ۧۢۧۤۘۖۨۖۘۦ۟ۙۡۜۘ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x77

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0xa8

    const/16 v2, 0x182

    const v3, 0x446acbac

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_65a

    goto :goto_2

    :sswitch_16
    const-string v0, "۟ۤ۬ۧۙۘۘ۠ۤۡۦۥۙۜۘۚۦۥۙۡۙۖۘ۫۟ۘۤۘۥۘ۠ۗۛۛۜۥۘۘ۬ۘۦۛۙۢۖۡۘ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۛۙۖۘۧۖۖۧ۟ۡۖۗ۫ۨۦۨۙۢۦ۠ۢۘۢۙ۫ۗۧۖۗۖ۬ۘۦۤۢ۬ۜ۠ۡۘۛۢۜۤۨۘۙۖۜۘ"

    goto :goto_2

    :sswitch_1c
    const v1, -0xaa6fa5

    const-string v0, "ۙۖۖۘ۠ۗۚۘ۫ۨۘۛ۠ۜۙۖۚۦۤ۠۫۬ۖۖ۫ۤۖۧۗۡ۟ۡۘۖۙۖۘ۟ۤ"

    :goto_21
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_718

    goto :goto_21

    :sswitch_2a
    const-string v0, "ۨۧۘۘۜۨ۫ۙ۟۠ۧۦۥۘۤۢۘۘ۬۬ۥ۬ۜۨۘ۟۠ۥۘۖۚۡۘ۫ۘۥ"

    goto :goto_2

    :sswitch_2d
    const-string v0, "ۖۜۡۤۚۗۡ۬ۧ۬ۡۜۤۛۘ۫۫ۗۘۖ۫ۦۥۘۙ۬ۧ۠ۛۖۘۜۥۤۦۥ۠"

    goto :goto_21

    :sswitch_30
    const v2, 0x7d94b8c7

    const-string v0, "ۧۨۨۜۛۛۨۖۜۘۛۦۚۢۦۘۢۡۡۘۘ۠ۡۘۥ۠ۜۦۗۛۤ۟ۛ۠ۗ۬ۙ۫ۛۗۨۜۘۘۥۡۘۚۘۗ۫۬ۤۡۛۙۖۚۗ"

    :goto_35
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_72a

    goto :goto_35

    :sswitch_3e
    const-wide v4, -0xd32ae123c3a53bdL  # -1.0009928272100008E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_50

    const-string v0, "ۡۙۨۘ۫ۜۥۘۥۗۤۗۛۦۘۤ۬ۜ۫ۨۛ۟ۢۡۘ۟ۚۡۘۜۙ۫ۨۘۘۙۧۡۜۦ۟ۗۨۘ۫ۨۘۘۤۚۜۡۚۨ"

    goto :goto_35

    :cond_50
    const-string v0, "ۦ۫ۡۘۖۛۜۘ۫ۚۗۡۡۚۢۥۜۘۙ۟ۡۗ۬ۡ۬ۧۧۡ۠ۗۚ۟۟ۙۜۡۚۡۦۗۙ۫۠ۨۡ"

    goto :goto_35

    :sswitch_53
    const-string v0, "۠ۛ۠۫ۡۖۘۖۗ۬۬ۖۦۦ۠۬۬۫ۥۘ۠ۜۗۨۙۡۘۥۨۗۙۨۘۚۧ۬۠ۚۢۛۛۢ۠ۥۨ"

    goto :goto_35

    :sswitch_56
    const-string v0, "ۙۤۚ۬۫ۧ۠ۘ۟۬۟ۥ۟ۗۘۦۘۨۘ۟۟ۨۨۦۨۡۡۛ۠۬ۦۨۚۤ۠ۨ۬ۗۡۖۢۧ۫ۚۘ۬۠۟ۤ"

    goto :goto_21

    :sswitch_59
    const-string v0, "ۗۨۗۘ۠ۖۖۡۘۨۦۤ۟ۖۥۙۜۛۥۚۗۖۢ۟ۚۦۡ۫ۦۖۗ۠ۗۥۨ۟ۘۜۡۘۥۗ۟"

    goto :goto_21

    :sswitch_5c
    const-string v0, "ۥۖۧ۬ۖۗۚۚۧۜۢۚۘۥۙۗۘۡۤۘۖۘۗۥۢۢۜۙۡ۠ۙۢۙۜ۬ۢۜ"

    goto :goto_2

    :sswitch_5f
    const/4 v0, 0x0

    :goto_60
    return v0

    :sswitch_61
    const v1, -0x1e587c42

    const-string v0, "۠ۤۖۛۡۜۘۥۛۥ۠۠ۢ۬۬ۤ۠ۤۨۘۗۗ۟ۜۦۙۥۚۖ۟۟ۥۘ"

    :goto_66
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_73c

    goto :goto_66

    :sswitch_6f
    const-string v0, "۟۟ۜۘۨ۬ۙ۟۫۠ۦۘۡۖۛۨۘۥۖۘۙ۬ۥۘۚ۫۫ۗ۟۠ۜ۠ۗ"

    goto :goto_66

    :sswitch_72
    const-string v0, "۠ۨۨۘ۠ۨۧۖۦ۬ۜ۬ۖۘۙۤ۠۬ۖۙ۟ۘۤۢۦۨۚۘۦۘۧۥۧۘ۠ۨۢۢۦ۟ۨۨۛۢۧۥۖۘۥۖۤ"

    goto :goto_66

    :sswitch_75
    const v2, -0x3cd5267b

    const-string v0, "ۗۖۖۘ۫ۤۛۧ۟ۚ۫ۥۗ۟ۤ۠ۙۨۘۧ۫۠ۤۦۢ۬ۙۙۗۖۙ۫ۢۜ۠ۜ"

    :goto_7a
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_74e

    goto :goto_7a

    :sswitch_83
    const-wide v4, -0xd32ae1a3c3a53bdL  # -1.0009886597009802E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_95

    const-string v0, "ۥۢۢۢۡۘۜۥۜۘۥۙۡ۬۬۟ۗۛۡۘۢۡۜ۟ۛۤۡۖۜۘۤۗۤ"

    goto :goto_7a

    :cond_95
    const-string v0, "۫ۦۧۘۦۚۥۤۦۜۘ۟ۖۦۘۚۜۘۘۥۘۡۘۡۤ۬ۡ۬ۖۘ۠ۛۤۙۜۖۘۛۡۦۛۘۢ۬ۢ۫ۧۤ"

    goto :goto_7a

    :sswitch_98
    const-string v0, "ۚۦ۟۫ۨ۬ۙ۬ۡۜۘۧۡ۫۫ۦۘ۫ۤۚ۠ۗۥۘۛۦۛۨۗۚۗۡۥۜۚۘۘ"

    goto :goto_7a

    :sswitch_9b
    const-string v0, "۬ۢۜۘ۬ۗ۠ۦۢۘۖۘۘۖۗۙۜ۟ۥۘ۬۫ۘۘ۬ۖۡۙۘۨ۬ۤ۟"

    goto :goto_66

    :sswitch_9e
    const-string v0, "ۡ۬۟ۢ۠۬ۗۛ۠ۢۜۘۡۤۤۛۛۛ۬۫۫ۚۜۘۜۘۘۘ۬۫ۤۥۦۡۢۢۘۘۜۜۜۘۜۚۛ۟ۤۖۘۡۘۘ"

    goto/16 :goto_2

    :sswitch_a2
    const/4 v0, 0x1

    goto :goto_60

    :sswitch_a4
    const v1, -0x40a4ea20

    const-string v0, "۟ۨۡۘۘۤۤ۟ۚۜ۠ۡۦۗۚۗۘۘۧۘۤ۟۫ۙۡۨۘۜ۟ۥۡۘۗۜ۫ۢۤۥ۫ۥ۟ۥ۟ۧۚ۫ۨۤۥۡ"

    :goto_a9
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_760

    goto :goto_a9

    :sswitch_b2
    const-string v0, "ۦۧۖۙۖۛۥۦۢۦۢۦۥ۠ۖ۬ۥ۟ۚۜۛۧۖۨۘۘۖۨۤۚ۬"

    goto :goto_a9

    :sswitch_b5
    const-string v0, "ۤۙۥۘۖۥۜۚۧۖۘۘ۫ۘۢۘۦۘۤ۟ۜۘۗۛۦۘ۫۬ۨۘۖۤۗ۟ۧۗۡۘۜۦۜۨ۫ۢۢۢۙۜۜۥۤۤۨۖۘ"

    goto :goto_a9

    :sswitch_b8
    const v2, 0x201042a1

    const-string v0, "ۚۢۙ۬ۙۨۤۥۥۘۘۥۡۘۛ۬ۦ۟ۦۡۚۖۘۚۖۢۦۢۨۘۛۜۜۘ"

    :goto_bd
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_772

    goto :goto_bd

    :sswitch_c6
    const-string v0, "۬ۦۨۘ۫۟۫ۚ۟ۜۘۦۘۜۘۛۖۚۨ۬ۛۨۖۙ۬ۢۖۧۘۜۘۢۗۜ۟ۦۗۦۘۡۘۨۦۧۘۨۧۢ"

    goto :goto_bd

    :cond_c9
    const-string v0, "ۜۤۦۢ۬ۖۘۧۙۡۘ۫ۥۘۘۡۡۦۘۧ۟ۥۘۙۢۥۘۗۢ۠ۥۚ۠ۡۧۘۙۜۘۘۚۗۙۗۨۘۘۨۚ۠ۡۙۘۡۛۡۘ"

    goto :goto_bd

    :sswitch_cc
    const-wide v4, -0xd32ae013c3a53bdL

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_c9

    const-string v0, "ۜۤۨۘۧۙۜۘۘ۟ۧۢۛ۟ۤۚۖۘ۫۟۬ۧۨ۬ۦۚۧۜۘۜۧۦۘۘۗۜۗۘۥۡ۟ۚۡ۫ۧۜۤ۫ۥ۠ۤ۫ۙۖ۠ۥ۟"

    goto :goto_bd

    :sswitch_de
    const-string v0, "ۛۢۨۘۥۘۤۢۛ۟ۨۡۘۢۚۙۡۧۘۘۛۦۧۘ۫ۗۥۜ۠۠ۜۧ۠ۜۖۢ۫ۨۛ"

    goto :goto_a9

    :sswitch_e1
    const-string v0, "ۘۨۧۚ۫ۜۘۢۘۘۘۖۨ۠ۨۗۘۡۘۢۘۘۙ۠ۥۘۥۨۧۚۥۨۘ"

    goto/16 :goto_2

    :sswitch_e5
    const/4 v0, 0x2

    goto/16 :goto_60

    :sswitch_e8
    const v1, -0x7a3be1df

    const-string v0, "۟۟ۘۘ۬ۢۨۦۗۗۗۜۛۢۥۘ۠ۛ۠۫ۛۢ۠ۗۡۖۙۖ۫ۘۜۘۜ۟ۗۦۡۚۧۨۚۢ۠ۢ"

    :goto_ed
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_784

    goto :goto_ed

    :sswitch_f6
    const-string v0, "۟ۢۥۢۤۚ۫ۖۡۘۡ۟ۨۘۗۙۨۘ۠ۗۡۘۖۗۧۦۢۘۘۤۧۛۛ۫ۦۘ"

    goto/16 :goto_2

    :sswitch_fa
    const-string v0, "ۘۨۖ۠۠ۨ۟ۡۘۘۧۢۤۨۛ۟۠ۢۜۘۖۡۦۘۗ۟ۥۢۧۥۘۦ۬۠ۡۚۘۛۖ۠ۢ۬ۘۦ۟ۛۙۧۘۘۦۖۧۘ۟۟ۧۗۜۧۘ"

    goto :goto_ed

    :sswitch_fd
    const v2, 0x45ace619

    const-string v0, "ۦ۫ۧۗ۬ۘۡۙۖۗۧۤۘۦ۠ۢۜۦۘۛۡۗۤۚ۟ۡۨۦۘۤۗۖۘۨۙۤ۬ۡۖ"

    :goto_102
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_796

    goto :goto_102

    :sswitch_10b
    const-string v0, "ۗۢۦۛۗۨۡۙ۬ۡۧۙۛۤۙۚ۟ۗۨۘ۫ۙۖۗۛۚ۠ۜۖۡۗ۬ۥۧ۬"

    goto :goto_102

    :cond_10e
    const-string v0, "ۖۦۨۗ۬ۥۘ۠۫ۜۤ۫ۡۗۘۥۦۤۦ۠ۧۦ۫۠ۙۦۥۚ۠ۨۡۘۜۜ۫ۢ۟ۘۘۜ۟ۖۘۗۛ"

    goto :goto_102

    :sswitch_111
    const-wide v4, -0xd32ae083c3a53bdL  # -1.0009980365962765E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_10e

    const-string v0, "ۖۤۦۖۜۖۚۖۢ۠ۚۗۢۖۦ۟۠ۗۛۧۜۘۧۧۡۧۚۨۘۘۦۨۛ۫ۤۨۢۧ۟ۛۧۡۤۥۘۜۙۡۢۥۡۘۡۚۗۘ۠۫"

    goto :goto_102

    :sswitch_123
    const-string v0, "۬ۡۘ۟ۘۘۢۢۙۤۛۜۘۦۡۗۧ۫۬ۛ۟ۦۘۥۗۥ۫ۜۛۢۖۛ۠ۘۖۘۢۖۡۗۡ۬ۚ۬ۦ"

    goto :goto_ed

    :sswitch_126
    const-string v0, "ۖۜۖۘ۟۬ۘ۠۠۟۠۠۟ۨۘۧ۠ۖۘۢۡۦ۫ۜۛۧۗۛ۟ۦۘۜ۠ۦۘۡ۟ۡۘ۟ۘ۠ۘۧ۬ۧۥ۬ۚۦۘ"

    goto :goto_ed

    :sswitch_129
    const-string v0, "ۥۥۘۘۤۖۗۦۥۘۜ۟ۨۥۛۥ۬ۡۦۘۡۚۧۖۢۜ۬ۤۦۛۗۙ۠ۡۘۢۨ۟ۙۡ۬ۘ۫ۙۚۙۨۘۛ۬ۥۛۥۧۘۧۢۛ"

    goto/16 :goto_2

    :sswitch_12d
    const/4 v0, 0x3

    goto/16 :goto_60

    :sswitch_130
    const v1, -0x7bed44f4

    const-string v0, "۠ۨۖۛۤۥۘۤۢۢ۟ۚۜۘ۬ۚۘۘۛۗۡۘۢ۟ۧۜۧۨۜۚۧۧۘۜۖۨۙۨۦۘ۬۠ۛ۫ۚۦ"

    :goto_135
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_7a8

    goto :goto_135

    :sswitch_13e
    const-string v0, "ۚۘۘۘۤۤۗ۟ۛۨ۠ۥۘۢۖۜۛ۟ۧۥۥۘۡۧۤۥۚۘۘۤۨۖۘۨۥۦۧۖ۠ۨۛۡ۠ۛۜۥۤۜۧۨۘ"

    goto/16 :goto_2

    :sswitch_142
    const-string v0, "ۖۜۥۘۢۧۘۥ۫ۘۥۥ۟ۙۦۘۘۚ۬ۗ۠۟ۚ۟۬ۤۤ۬۠ۦۦۡۤ۟ۥۘ۫ۤۘۘۙ۟ۢۧۜۨۘۦ۬ۢۨۨۜۘۚ۬ۡۘۙۨۥۘ"

    goto :goto_135

    :sswitch_145
    const v2, -0x7977f515

    const-string v0, "ۧ۬ۥۘ۬ۥ۬ۤ۟ۜۘۢۦۛۥ۠ۡۘۢ۟ۗۤۗۗ۬ۙۡۘۡۨ۬ۜۧۜۛۤۥۙۨۘ"

    :goto_14a
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_7ba

    goto :goto_14a

    :sswitch_153
    const-string v0, "ۖۨۜ۫ۛۙۖۘۦۘۡۤۚۙۥۦ۬ۚۚ۬۟ۙ۟ۘۢۜۜۘۖۡۢۖۡۘۘۜ۬۠ۥۗۜۖۡۘ"

    goto :goto_14a

    :cond_156
    const-string v0, "ۤ۟ۨۘۚۘۙۨۦۙ۫ۥۘۜۙۢۦۘۛۙۜۜ۠ۨۤۖۤ۠ۖۥۡۚۖۖۘۚۘۥ۟۫۟ۜۛۙۨۚۘ۬ۜۙۗۧۨۘۚ۟ۧ"

    goto :goto_14a

    :sswitch_159
    const-wide v4, -0xd32aff73c3a53bdL  # -1.0007401719756299E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_156

    const-string v0, "ۢۡۗۙۘۜۘۦۨۢ۬ۙۧۢۨۥۘۡ۟۠ۦۘۗۖۡۘۛۖۘۚۙۗ۠ۦ۠۬ۘۧۘۦۡۖ۟ۖۨۥۨۗ۟ۢ۠ۦۚۨۘ۟ۧۜۘ"

    goto :goto_14a

    :sswitch_16b
    const-string v0, "ۥۗۨۘۙۧۡۘ۫۟ۨۥ۠ۡۘ۬ۦۖۘۜۖ۫ۚۢۚۚۙۧۢۚۜۛ۫"

    goto :goto_135

    :sswitch_16e
    const-string v0, "ۜ۬ۜۘۧۖۙۖۗۡ۟۠ۥۘ۫ۙۢۗۧۨۘۖۥۜۘۥۖۨ۫ۢۨۘۧۤۜۘۡ۫ۧۜ۬ۘۘ"

    goto :goto_135

    :sswitch_171
    const-string v0, "۬ۙۨۖۥۦۡۡۨۧۚۜۘۦۚۘۘۛ۬ۧۤۜ۠ۚۘۦۘۛۨۙۥۘۦۜ۬ۗۗۖۘۛۢ۬ۚۖۨۘۘۦۨۘ۟۫ۡ"

    goto/16 :goto_2

    :sswitch_175
    const/4 v0, 0x4

    goto/16 :goto_60

    :sswitch_178
    const v1, -0x15069e8d

    const-string v0, "۫۟ۦ۟۟ۙۛۘۘۨۘۖۡۧۥ۠ۛۜۘ۟۬ۖۥۜۘۘۜۢۨۘۥۘۙۘۘۘ۫ۗۡۘ"

    :goto_17d
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_7cc

    goto :goto_17d

    :sswitch_186
    const-string v0, "۟ۢۚۛۨۖۘۡۨۗۜ۫ۥۘۡۤۥۜۧۤۙۘۘۜۦۚۛۦۘۘۢ۫ۘ۟ۚ۠۠ۚۨۘ"

    goto/16 :goto_2

    :sswitch_18a
    const-string v0, "ۜ۟ۧ۟ۚۧ۫ۜۦۘۧۚۘۘ۬۫ۖۘ۠۫ۛۖۖۨۘۢۖۢۨۘۘۘ۬۠ۖۘ۫ۦۦۤۧۡ۫ۤۚۗۜۛ"

    goto :goto_17d

    :sswitch_18d
    const v2, -0x676bf1e9

    const-string v0, "۟ۥۖۨۨ۬ۧ۬ۥۘۜۜۡۘۢۤۜ۟ۛۨۘۡ۠۬ۤۦۨۘۛۖۖۘ۟۟ۡۘۗۥ۬ۛۛۨۘۡ۫ۙۥۜۜۘۖۖۡۘۙۗۡ"

    :goto_192
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_7de

    goto :goto_192

    :sswitch_19b
    const-string v0, "ۖۦۨ۠ۡ۠۬ۜ۫ۡۗۥ۟ۗۛۡۚۨۘ۬ۦۛۗۙ۫۠ۚۖۜۨۡۘۤۙۜۘۙۨۦۘۗۜۗۗۚ۠ۚ۟ۡۘۚ۠۠ۢ۫ۥۘۜۗۘۘ"

    goto :goto_17d

    :cond_19e
    const-string v0, "ۧ۬ۜۙۛۚۢۛ۠ۚۛۜۘۙۤۧۢ۟ۗ۫ۗۖۘۗۥۖۥۛۜۘۜۖۜۛ۟ۙۥۚۘۘ"

    goto :goto_192

    :sswitch_1a1
    const-wide v4, -0xd32affd3c3a53bdL  # -1.0007370463438645E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_19e

    const-string v0, "۬ۡۥۘۧۖ۫ۢۘۛۗ۠ۖۧۜۙ۠۫ۦ۫ۙۢ۟ۧۢۙۧۦۥۢۖۙ۟ۘۘۡۡۛۢۙۜۘۚۗۦۘ"

    goto :goto_192

    :sswitch_1b3
    const-string v0, "ۨۦۗۥ۟ۘۘۤۜۜۦۡۜۘۜ۫۫ۘۢ۟ۙۗۧۜۥۤ۠۫ۢۦۜۖۘۙۖۙۗۙۥۖ۠ۥۙۢ"

    goto :goto_192

    :sswitch_1b6
    const-string v0, "ۢۨۘۛۢۗ۟ۜۖۘ۬۫ۨۘ۬ۗۥۙ۫ۤۙۗ۟ۤۜۢۜۧۘۚۛۗ"

    goto :goto_17d

    :sswitch_1b9
    const/4 v0, 0x5

    goto/16 :goto_60

    :sswitch_1bc
    const v1, -0x96ffe9e

    const-string v0, "ۚۜۥۧۛۨۘۗۚۖۡ۬ۙۖۜۙۤۡۨۘۙۜ۫۟۟۫ۥۛۥۘۥۖۧۚ۫۫ۤۥۡ"

    :goto_1c1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_7f0

    goto :goto_1c1

    :sswitch_1ca
    const-string v0, "۬ۦۨۘۡۥۦۥۙۜۦ۬ۗۧ۬ۜۚۚۛۨ۠۟ۙ۠ۨۦۨۨۥۨۤۤۚۗۚۡ"

    goto/16 :goto_2

    :sswitch_1ce
    const-string v0, "۫۟ۦۘۚۥۘۘۥ۬ۛۚ۟ۥۖۡۘ۠ۗۗۙۜۤۖ۟ۖۙۚۖۘۙۤۧ"

    goto :goto_1c1

    :sswitch_1d1
    const v2, 0x4209155f

    const-string v0, "ۨ۠۬۫ۜۨۨۜۡۡ۠ۘۙۛۨۗۘۜۘۛۗۨۘ۬ۛۜۘۛۥۧ۟ۨۘ۬ۜۘۘۤۦۧ"

    :goto_1d6
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_802

    goto :goto_1d6

    :sswitch_1df
    const-string v0, "ۡۖۦۘۗۘۢۤۥۖۘ۬ۜۡۧۜۧۘۤۛ۫۠ۡۨۘ۬ۥ۬ۘۧۖۘۘۤۙۡۡۧ۠"

    goto :goto_1d6

    :cond_1e2
    const-string v0, "ۥ۠ۡۗۢۡۘۨۤۨۡۘۤۚۥۨۗۖۜۘۧۢۖۘۗۦ۠ۧۙۨۘ۬۫ۨۜۙۜۗۘۘ"

    goto :goto_1d6

    :sswitch_1e5
    const-wide v4, -0xd32afeb3c3a53bdL  # -1.0007464232391608E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1e2

    const-string v0, "۟ۦۡۘ۠۟ۖۥ۫۬۬ۢۜۘۗۗۚۧۜ۠ۡۘۖ۠۫ۦۧ۟ۦۖۚ"

    goto :goto_1d6

    :sswitch_1f7
    const-string v0, "ۚ۬ۛۛ۠ۡ۠ۛۨۘۘۘۚۢۦۘۨۦۙ۬ۧۨۢۛۡ۫۫۟۫ۥۧۘ"

    goto :goto_1c1

    :sswitch_1fa
    const-string v0, "ۦۤۖۤۢۚۖۖۘۙۗۥۛۖۘۖۢ۬۫ۛ۟ۨۢۡۘ۟۟ۨۙ۠ۚۥۦ۬ۡۢۤ۠ۗۢۢۡ۫"

    goto :goto_1c1

    :sswitch_1fd
    const-string v0, "ۜۥۡۘ۬ۖۜۘ۟ۚۡۥ۫۠ۘ۠۟ۙۗۨۘۚۢۥۘۖۛۥۛ۬ۡۘۘۥۦۘۜۤۘۘ۫۬ۖ"

    goto/16 :goto_2

    :sswitch_201
    const/4 v0, 0x6

    goto/16 :goto_60

    :sswitch_204
    const v1, 0x6393d0a0

    const-string v0, "۬ۗۖۘۛۧۥ۟ۖۧۘ۟ۗۘۘ۠ۖۥۘۦۗۘۘۡ۬۟ۧۢۢۜۛۜۘۢۗۦۘ۫۠ۖ۫ۖۜۘۗۡۨۘ۫ۦ۬ۨۦ۬ۤۜۤۡۖۘۘۚ۠ۘۘ"

    :goto_209
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_814

    goto :goto_209

    :sswitch_212
    const-string v0, "ۚۖۡۤۢ۬ۖۧۡۜۢۛۙ۫۫ۖۨۧۧۜۘۘ۟ۦ۫ۥۤ۫ۦۡۘۘۥۡۖۘۗ۬۫ۡۨۜۘ۫ۤۤۜ۠ۥ۫ۖۥۚۥۡۘۥۢۨ"

    goto/16 :goto_2

    :sswitch_216
    const-string v0, "ۥ۠ۡۘۢۛۤۧ۟ۡۜۖۜۘۜۗۡ۬ۢۡۨۖ۫ۥۨۨۢ۬ۜۨۥۢۥ۫ۘۘ۟ۥ۫ۧ۟ۚۨۧۛ"

    goto :goto_209

    :sswitch_219
    const v2, -0xa432828

    const-string v0, "ۛ۠ۘۘۛۨۜۘۡۦ۠ۦۚ۬ۧۘۜۜۗۥ۠ۤ۬ۛۛۨۘۛۢۨۡ۟ۘ۫ۚ۬ۙۘۦۘۤۗۥۘۜ۬ۨۖ۫۫ۨۤۖۘ"

    :goto_21e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_826

    goto :goto_21e

    :sswitch_227
    const-string v0, "ۜۧۡۙۨۘۥۚۧۖۦۧۛ۠ۦۘۚۢۨۢۘۨۨۦۨۘۢ۫ۗۨۧۖۘۚۚۘۖۘۘۖۛۘ۟ۙۥۢ۫ۨۦۧۘ"

    goto :goto_209

    :cond_22a
    const-string v0, "۟ۚۤۖۗۖۘۢ۟ۚۖ۬ۧ۠۫ۘۘۛۖۡۜۜۛۜۘۢۥ۟ۘ۬۫"

    goto :goto_21e

    :sswitch_22d
    const-wide v4, -0xd32afd33c3a53bdL  # -1.0007589257662224E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_22a

    const-string v0, "ۙۨۧۘۛۥۥۘ۟ۤ۫ۛۤۘۘۛۘۥۚۘۨۘۢۢۡۘۗۘ۟ۗۗۡۘ۠ۧۢۜۡۚۢ۫ۙۥۛۧۡۗۡۘ"

    goto :goto_21e

    :sswitch_23f
    const-string v0, "ۛۜۥۚۡۖۘۡۨ۠ۗۢۖۘۡۦۖۖۖۜۘۙۤۤ۟ۦۛۘۤۗ۬ۢۥۘۛۗ۟ۢۥ"

    goto :goto_21e

    :sswitch_242
    const-string v0, "ۡۖۨۘۜۥۜۤۦۙۤۛۦ۬۬ۘۘۜ۠ۧۙ۬ۧ۟ۜۜۛۨۨۧۦۦۘ۠ۢ۫ۚۧۘ"

    goto :goto_209

    :sswitch_245
    const-string v0, "ۗۨۡۘۦ۠ۧۧۥۧۡ۟ۗۦ۟ۖۛۗۦۘۘۦۖ۟ۧۡۘ۫۟ۘۘۨۡۜۘۦ۠ۜ۬۫ۢ"

    goto/16 :goto_2

    :sswitch_249
    const/4 v0, 0x7

    goto/16 :goto_60

    :sswitch_24c
    const v1, 0x28fe0be0

    const-string v0, "ۜۨۨۘۥۤۦ۟۫ۤ۠ۡۘۙۖۗۥ۠ۘۘ۠ۧۛ۠۠ۘۨۚۖۡ۟ۗ"

    :goto_251
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_838

    goto :goto_251

    :sswitch_25a
    const-string v0, "ۢۢۦۛۛۖۘۤۨ۬ۘۨۙ۬ۛۦۘۤۜ۫۠۠ۜۥۢۜۘ۬ۜۘۘۜۤۨۚۥۥۘۘ"

    goto/16 :goto_2

    :sswitch_25e
    const-string v0, "ۤۤ۬ۥ۬ۧۖۤ۫ۜۧۘۜۥۦۘۜۧۧۢۢۜۧ۟۫ۢۡۧ۬ۚۤ"

    goto :goto_251

    :sswitch_261
    const v2, -0x22cc452f

    const-string v0, "۠۫۬ۜۖ۫۫ۗۖۘۛۤۨۧۚۜۖۧۗ۫ۡۙ۬ۙۗ۠ۖ۬ۜ۟"

    :goto_266
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_84a

    goto :goto_266

    :sswitch_26f
    const-wide v4, -0xd32afda3c3a53bdL  # -1.0007552791958294E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_281

    const-string v0, "ۦۜۘۘۚۨۦ۬۫ۨۘۨۖۥۘۤۡۘۘ۫ۧ۠ۦ۟۟۫ۚ۠ۜۧۦۜۙ"

    goto :goto_266

    :cond_281
    const-string v0, "ۥۨ۠۟ۖۗۖۜ۟۬ۥۦۦ۬۬ۥۗۗۢ۫ۘۢۚۙۗۦ۟۠ۖ۬ۧ۬ۦ۟ۗۧۖ۠۬ۘۛۗ۟ۥۧۘ۟ۘ"

    goto :goto_266

    :sswitch_284
    const-string v0, "ۛۧۚۥۗۚۨۖۗ۫۟ۥۦۖۡۥۡۡۘۧۡ۟۬۠ۨۘۧۗۘۙۤ۟۟ۘۘ۟ۨۘ۫ۖۖۘ۠ۡۧۘ"

    goto :goto_266

    :sswitch_287
    const-string v0, "ۢۙۜۘۗۧۤۘۨ۠ۡۗۛ۟ۜۡۘ۫ۥۚۥۧۡۘ۫ۥۧ۬ۡۤۨۜۙۥۚۖ۠ۖ۫"

    goto :goto_251

    :sswitch_28a
    const-string v0, "ۗۧۘۨ۠ۡۘۜۢۗۚ۠ۡۙۢۨۦۜۚۨۘۘۘۦۗۜۗۤۖ۫۬ۨ۫ۗۤۦۢۙۛۡۤۧۗۧۨۤۧۥۨۚ"

    goto :goto_251

    :sswitch_28d
    const/16 v0, 0x8

    goto/16 :goto_60

    :sswitch_291
    const v1, 0x5f299053

    const-string v0, "ۥۡ۫ۡۤۘۜۥۘۦۚۨۦۙۘۖۛ۫ۧۥۘ۠ۚۛ۠ۥۢۨۚۨۘ"

    :goto_296
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_85c

    goto :goto_296

    :sswitch_29f
    const-string v0, "۟۫ۜۘۡۦۜۘ۟ۛۘ۫ۗۘۗ۟ۜ۟ۦۥۙۤۡۘۢۦۡۧ۟ۖۘۙۚ۟ۥۚۡ۠ۚۥۖ۠ۜۘۗۤۙۜۗۗۨۥۨۘ"

    goto/16 :goto_2

    :sswitch_2a3
    const-string v0, "ۢۨۜۘ۬۠ۗۤۢۦۛۤۙۚ۠ۧۤۤۡۘ۠ۨۗۛۡۥۚۨۜۖ۟ۤۥۗۜۘۛ۠ۤ"

    goto :goto_296

    :sswitch_2a6
    const v2, 0x4f0cc763

    const-string v0, "۬ۥۦۘۘۙۛ۟ۢۥۘۜۢۖۘۡۖۡۛۖۥۘ۠ۡۚ۟ۖ۬ۤۦۘۖۗۧۛۦۖۘۘ۬ۖۘ"

    :goto_2ab
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_86e

    goto :goto_2ab

    :sswitch_2b4
    const-string v0, "ۖۢۗۡۗۨۛۥ۠۫ۛۨۘۚۛۖۘۗ۬ۘۘۜ۫۟ۢۧۧ۟ۙۢۦۙۘۤۖۙۤۗۜۡۜ۠ۛۖۘۘۚۨۘۤۙۢ"

    goto :goto_2ab

    :cond_2b7
    const-string v0, "ۜۛۧۢ۫ۦۘۛۡۘۘ۠۠ۢ۬۬۠ۨۧۡ۟ۛ۠ۤۤۥۛۦ۟ۚ۟"

    goto :goto_2ab

    :sswitch_2ba
    const-wide v4, -0xd32afc03c3a53bdL  # -1.0007688236001462E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2b7

    const-string v0, "ۘۥۛۖۛۡۗۦۘ۫ۘۜۨ۫ۨۘ۟ۗ۟ۦۚ۠ۗۡۜۦۥۜۗ۟ۦۛۡۡۤۦۘ"

    goto :goto_2ab

    :sswitch_2cc
    const-string v0, "۟ۙۖۢۜ۬۠ۨۥۘۖۡۚۦۘ۬۫ۘۧۘۗۧ۠ۗۖۦۧۤۥۤۖۜۘ"

    goto :goto_296

    :sswitch_2cf
    const-string v0, "ۛۜۧۛۙۤۤ۟۟ۚۜۧۢۛۖۘۢۥۥۘ۬۬ۦۙۦۘ۫ۚۘۘۖۗۖۘ۠ۡۥۨۘۤۗۧۚۧ۠ۛۧۦۨۛۤۘۘ"

    goto :goto_296

    :sswitch_2d2
    const/16 v0, 0x9

    goto/16 :goto_60

    :sswitch_2d6
    const v1, -0x71fcf8e0

    const-string v0, "ۘۛ۟ۖۖۙۚۢۙۤۡۦۖ۟ۢۗۨۢ۠ۡۡۡۘۨۜۘۢۚۛ۠ۥۡۧ۟ۙ۠ۛۥۘۖۘۜۘۡۥۙۥۦۘۚۥۖۖۤۡ"

    :goto_2db
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_880

    goto :goto_2db

    :sswitch_2e4
    const-string v0, "ۜۡ۬۟ۜۡۢۖۚۗۤۘۘۤۖۗ۫ۡۗ۠ۢۧۨۥ۠ۨۧۘۧۛۡۗۡ۫۟۟ۦۧۗۛۛۘۘۙۚۦۘۡۦۧۘۤۨۡۦۛۜ"

    goto :goto_2db

    :sswitch_2e7
    const-string v0, "ۢۤۘۢۧۖۘۧۜۨۘۖۜۘ۟ۙۦۘۘ۫ۢ۟ۥ۟ۡۜۘۙۨۙۛ۬ۧۗۙۧۛۥۥۘۚۤۡ۬ۚۨۦۚ۬ۖۧ۬۬ۨۙۡۜۦۘ"

    goto :goto_2db

    :sswitch_2ea
    const v2, 0x1f2412a2

    const-string v0, "ۛۖۨۘۜ۠ۖۖۗۡۘ۫ۚۖۘۥۙۢ۟ۛ۫ۥۘۜۡ۟ۡۨۧ۠ۤۚۘۘۥۡ۠ۚۤ۟ۧۗۦۧۜۘۦ۟ۦۘۗۛۘ"

    :goto_2ef
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_892

    goto :goto_2ef

    :sswitch_2f8
    const-string v0, "ۘۘۛۖۚۤۤ۠ۨ۠ۡۢۜۜۢ۠ۛۡۘۙۜۚۛۤۘ۫ۨ۫۠ۨۗ"

    goto :goto_2ef

    :cond_2fb
    const-string v0, "ۥ۟ۧۚۘ۫ۙۙۥۘۗۨۘۧۙ۫ۜۧۤۦ۟ۧۦۛۥۗۢۜۧۨۡۘ۬ۖۘۖۦۜۘۥۚۜۤۤۖۘ"

    goto :goto_2ef

    :sswitch_2fe
    const-wide v4, -0xd32afcf3c3a53bdL  # -1.0007610095207327E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2fb

    const-string v0, "۫ۥۙۧۡۡۛۡۘ۠ۚۤۦۦۦۛۛۧ۟ۤۨۘۡۖۖۘۚ۬ۘۘۦ۬۫ۢ۬ۦۘۤۘۚۦۛ۟۟ۤ۠۟ۤۛۙۥۗۦۡۨ۠ۜۙ"

    goto :goto_2ef

    :sswitch_310
    const-string v0, "ۨۨۨۘۤۘۢۚۢۤۥۥۚۨۖۨۢۤۜۜۦۖ۬۫ۚۤۦ۬ۡۜۛ۫ۘ۫ۨۢۤۦۧۘۖۜۧۤ۠ۥۙۥۘۧۦۡ۠ۛۜۘ"

    goto :goto_2db

    :sswitch_313
    const-string v0, "۟ۖۛۢ۟۟۟ۚ۬ۗ۫ۤۛۦۦۘۖۙۦۘۛۤۨۘۢۛۢ۫ۚ۫ۡۜۥۤ۟۠ۙ۫ۤ"

    goto/16 :goto_2

    :sswitch_317
    const/16 v0, 0xa

    goto/16 :goto_60

    :sswitch_31b
    const v1, -0x806d2c3

    const-string v0, "ۨۜۘ۫ۧۢۦۧۨۘۗۧۧۙۛۜۘۚۢۗۡۜ۟ۖۧۘۘۨۖۙ۟ۡ۠ۢۡۨۢۥ"

    :goto_320
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_8a4

    goto :goto_320

    :sswitch_329
    const v2, 0x607824e

    const-string v0, "ۢۡۜۘۡۛۧۥۧۜۢۙ۟ۜۗ۟ۧ۟ۦۛۦ۬ۨ۟ۡۦۘۢۘۢۧ۟۟ۗۤۖۨۜۦ۠ۡ۠۠ۘۜۘۙۧ۫"

    :goto_32e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_8b6

    goto :goto_32e

    :sswitch_337
    const-string v0, "۟ۛۨۧۧۨۖۜۚۢ۠ۨۦۙ۫ۧ۫ۧۗۖۧۚ۟ۤ۬ۜۜۗۙۛ۟۫ۦ۟ۘۧۘۜۢ۠ۨۖۦ۠ۡۜۘۧۘۧ"

    goto :goto_320

    :sswitch_33a
    const-string v0, "ۡۥۤۦ۠ۙۤۗۥۗۦۖۘۦۤۖۢ۠ۥۘۖۘۡۘۦۡ۫ۗۡ۬ۤۢۖۘ"

    goto :goto_320

    :cond_33d
    const-string v0, "ۘ۫ۡۘ۟ۤۨۘۙ۠ۘۨۜۖ۬ۛۥۙۙۜۤۨۨۘ۫ۙۖ۟ۡۥۘۛۖۚ۬ۘۨۛۚۗۥۖۘۢۢۨۖۗۖۘ۬ۥ"

    goto :goto_32e

    :sswitch_340
    const-wide v4, -0xd32afb53c3a53bdL  # -1.0007745539250495E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_33d

    const-string v0, "ۗۖۧۧۨۨۧۗ۬ۤۚۧۘۘۧۘۛۤۧۜ۟ۜۘۛۨ۟ۨۤ۠ۛۘۖۛۗۘۤۧۨۨۤۤۘ۠ۨۘۛۡۢۤۥۨۘ"

    goto :goto_32e

    :sswitch_352
    const-string v0, "۫ۨ۫ۖۘۙۘۜۘ۠۬ۨۜۖۚۤۗۘ۫ۦ۬ۨۡۖۖ۫ۦۛۨۤۛۖۖ۠ۘۜۘۖۦ۠ۧۖۘۘ"

    goto :goto_32e

    :sswitch_355
    const-string v0, "ۜۚۘۘۚۖ۟ۘۨۘۦ۫۬ۙ۠ۜۘۘۗۜۢۜۦۘۜۙۛۤۤۡۚ۠ۚ"

    goto :goto_320

    :sswitch_358
    const-string v0, "۫ۦ۫۠۫ۜۖۧۜۛ۬ۤۦۡۧۘۤۘۘۛۜۦۘۘۧۘۘ۟ۨۦۥ۟ۛۚۚۥۘ۫ۦۦۨۗ۟۬ۢۗ"

    goto/16 :goto_2

    :sswitch_35c
    const/16 v0, 0xb

    goto/16 :goto_60

    :sswitch_360
    const v1, -0xb0e7229

    const-string v0, "ۛۥۦۘ۬ۦۡۥۢۜۘۙ۫ۡۚ۠ۖۦۦۘۘۡۢ۟ۥۦ۬۟ۧۦ۠۟۬ۡۜۘ۠ۢ۟"

    :goto_365
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_8c8

    goto :goto_365

    :sswitch_36e
    const v2, 0x6f32c37d

    const-string v0, "۟۠ۥۧۖۦۦۥۜۘۥۧۥ۬ۙۘۘۢۙۥۘ۟ۚۡۘۦۗۢۨۢۦۘۘ۠ۧۨۡۘ۬ۥۖ"

    :goto_373
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_8da

    goto :goto_373

    :sswitch_37c
    const-string v0, "۫ۧۗۗۦۢۖ۫ۡ۬ۧ۠۫ۦۡۘۧۙۦۘ۠ۨۜۖ۫۠ۚۙۨ۫ۥ۫ۨۨۚۛ۬ۘۙۡ۠ۙۥۘۦ۟ۢۡۚ۠ۧۦۖ۟۫"

    goto :goto_365

    :sswitch_37f
    const-string v0, "ۜۖۥۧۗۡ۫ۜۤۜۧۜۘ۠ۧ۟ۥۘۦۢۦۡۘۥۤۨۤۖ۫ۖ۟ۥۘۤۚۚۤۡۦۘ۟ۛۧ۬ۤ۠۫ۢۤۥۗ"

    goto :goto_365

    :cond_382
    const-string v0, "۫۬ۢۤۦۦۘۡۨۘ۠ۙۦۘۦۜۦۘۘۧۜۥۤ۟ۢ۬ۥۖۧۨۘۗۦ۬ۢۖ۬۠ۡۖۘۨۨۨۘۨۤۖۧۜۜۘۘۙۦۘ"

    goto :goto_373

    :sswitch_385
    const-wide v4, -0xd32afa73c3a53bdL  # -1.0007818470658354E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_382

    const-string v0, "۠ۢۖۡۖۥۗ۫۠ۙ۠ۥۘ۫ۢۦۜۢۛۥۚۜۘۘۡۦۘۜۙۙ۬۟۠ۙۨۘۛۜ۟"

    goto :goto_373

    :sswitch_397
    const-string v0, "ۥۚۘۘۚۙۢۡۤ۟۟ۤۜۤۡۘ۬۬۫۬ۘۘۘۧۙۛۘۚۙ۠ۦۢ"

    goto :goto_373

    :sswitch_39a
    const-string v0, "ۦ۠ۢۗۨ۟ۜۦ۠ۦۡۡۘۗۥۢۙۧۘۘۦۗۨۛ۟۫ۛ۟ۖ۫۟"

    goto :goto_365

    :sswitch_39d
    const-string v0, "ۙۛۜۢۖۦ۬ۗۢ۟ۨۧۜۨۨۘۙۚۖۘۨ۟۟ۡۛۛۙۘۜ۫۟ۤۤ۟ۨۗۡۘۡۢ۟۟ۛۡ"

    goto/16 :goto_2

    :sswitch_3a1
    const/16 v0, 0xc

    goto/16 :goto_60

    :sswitch_3a5
    const v1, 0x14986f11

    const-string v0, "ۙۢۥۘۙ۫ۜۤۡۘۤۗۘ۟ۨۡۙۦۙۖۚۗۧۨۢۘۜۘ۠ۛۥ۠۫ۚۙۘۙ"

    :goto_3aa
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_8ec

    goto :goto_3aa

    :sswitch_3b3
    const-string v0, "ۘ۟ۥۗ۟ۗۘۚۜۘ۟ۜ۬۟ۢۦۚۥۜۘۜ۟ۦۘۛۜۜ۬ۛۡۛۖۨۤ۬ۗ۬ۚۙۡ۟۠ۙۘۗۙۖۙۤۘۘ"

    goto :goto_3aa

    :sswitch_3b6
    const-string v0, "ۛۜ۬ۥۖۥۘۨۘۘۥۧۨ۬ۖ۬ۙ۬۠۟ۥۥۛۖ۟ۘۚۦۘۗۤۖۧۖۦۘۚۜۡۘ"

    goto :goto_3aa

    :sswitch_3b9
    const v2, 0x5ed6b652

    const-string v0, "ۤۘۧۘۜۥۦ۟ۘۘ۠ۤۥۘۙۥۖ۫ۥۛۡ۬۟ۛۢۖ۟ۘۘ۠ۚۢۦۢۥۘۙۗۨ۫۟۬ۥۨۘ"

    :goto_3be
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_8fe

    goto :goto_3be

    :sswitch_3c7
    const-string v0, "ۦۚۤۚۥۤۥۡۧ۟ۗ۟ۗۗۥۘۚۤ۫ۙۛۡۛۦۦۘۥ۬ۖۘۘۧ۬ۥ۠ۘۤۘ۫ۘۘۘۤۘۘ"

    goto :goto_3be

    :cond_3ca
    const-string v0, "۬ۦۖۛۚۥۙۧۜۘ۠ۡۨۘۛۦۤۖۨۧۘۖۛۤۛۦۛۛۦۧۘۙۗ۟ۜۗۦۘ۬ۚۦۘۡ۠ۨۘۡ۫ۖ"

    goto :goto_3be

    :sswitch_3cd
    const-wide v4, -0xd32af913c3a53bdL  # -1.000793307715642E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_3ca

    const-string v0, "ۜۧۘۛ۟۠ۧۗۜۘۦ۠ۛۛۖۘۦۧۢۡۚۦ۠۬ۘۧ۠۠ۥۧۗۦۖۨۘۜ۟ۦۘ"

    goto :goto_3be

    :sswitch_3df
    const-string v0, "ۢ۫ۜۘۨۜۜۙۘۥۘ۬ۖۚۨۤۤۢۦ۟۬ۗۥۘۡۚ۠۬ۚ۟ۛۜۘۘ"

    goto :goto_3aa

    :sswitch_3e2
    const-string v0, "ۖۡۢۖۡۡ۬ۤۖۘۚۖ۟ۗۥۖ۠ۦۘۙۥۡۨۢۙۗۥۦۗۚۢۡ۠ۨۗۖ۠ۜۘۤ۬ۘۙۢ۬ۨۛۡۖۘ"

    goto/16 :goto_2

    :sswitch_3e6
    const/16 v0, 0xd

    goto/16 :goto_60

    :sswitch_3ea
    const v1, -0x5d25d165

    const-string v0, "ۚۙۗۚ۟۠۫ۡۘۘ۟ۚ۠ۗۦۖ۫۟۠۬ۡ۟ۦۨۘۖۗۘۦۡ۫۫ۜۙۚ۟ۨۧۘ۫۟ۦۘ"

    :goto_3ef
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_910

    goto :goto_3ef

    :sswitch_3f8
    const-string v0, "ۦۘۘۘۦۚ۟ۛ۬ۖۘۖۦۖۘۜۨ۬ۗۧۥ۠ۛۛۗۗۖۧۜۧۢۤۚ"

    goto/16 :goto_2

    :sswitch_3fc
    const-string v0, "۠ۚۦۘ۫ۧۦۚۧۨۘ۠ۦۦۘۤۢۨۘ۠ۥۘۗ۟ۥ۫ۤ۫ۧۡۘۘ۟۠ۘۡۦۧۚۡ۟ۛۘۘ۠ۧۗۙۧ۟ۨۗۖۘ"

    goto :goto_3ef

    :sswitch_3ff
    const v2, 0x7d440baf

    const-string v0, "۬ۙۗۨۚۗ۫ۖۜۜۙۘۖۜۜۡۥ۫۠ۘۡ۬ۛۖ۠ۤۡ۟ۨۨۘۨۧۨۧۖۘۘۦۜۦۘۢۨۡۘۛۙ۬ۥۗۖۘ۠ۦۡۦۥۢ"

    :goto_404
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_922

    goto :goto_404

    :sswitch_40d
    const-string v0, "ۘۖۜ۬ۛۥۙ۫ۨۛۗۘۘ۟ۧۛ۫۫ۘۥ۬ۡۘۗۚ۫ۤۡۧۦۙۤۨۗ۠ۛۘۨۛۚ۫ۜۗۤ"

    goto :goto_3ef

    :cond_410
    const-string v0, "۬۟۟ۨۤۡۨۦۗۙۤۨۘۜۛۜۚ۬ۥۘۥۖۢۗۖۘۘۢ۫ۨ۬ۡۥۖۜۡۘۨۘۧۚۜۨۙۘۨۥ۠ۥۘۡ۠ۦۘ"

    goto :goto_404

    :sswitch_413
    const-wide v4, -0xd32af9c3c3a53bdL  # -1.0007875773907387E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_410

    const-string v0, "ۦۖۖۘۚۛۦۢۨ۬۬ۖۖۘۢۛۨۧۤۜۘ۬۠ۚۜۗۗ۟۠ۦۢۧ۫ۨۨ۬ۜۨۜ"

    goto :goto_404

    :sswitch_425
    const-string v0, "ۨۨۥۜ۠ۥۘۦۖۥ۟ۛۦۗ۟ۘۚۜۘۗۜۘۘ۫ۗۦۨۗۢ۟ۦ۫ۡۤۦۘ۠ۦۜ۫ۛۘۨ"

    goto :goto_404

    :sswitch_428
    const-string v0, "ۢ۬ۖۥۨۤۚۨۘ۫۫ۡۜ۠۟ۗ۟ۜۦ۫۠ۚۛۙۤۗۙۖۤۦۧۚۖۛۛ۟ۧۗۛۦۤۛۖۘۙۥۘۤۧۡۘ۫ۢۘ"

    goto :goto_3ef

    :sswitch_42b
    const-string v0, "ۧ۟ۚۤۨۘۧۖ۫ۚۨ۟ۛۥۥۘ۠۬ۡۥۙ۟ۘۦۦۘ۬ۖۖۦ۫۬ۨۚۖۘۢۨۜۦۚۢ۬ۡ۬۬۠۬ۚۢۦۧۡۨۛۥۜۘ"

    goto/16 :goto_2

    :sswitch_42f
    const/16 v0, 0xe

    goto/16 :goto_60

    :sswitch_433
    const v1, -0x26628ef5

    const-string v0, "ۚۢۨۘۖ۬ۧۧۧۦۧۘۚۙۖ۟ۢۧۤۡۘۘۨۨۚۡۙۦۚۘۛۜۜۥۢ۬"

    :goto_438
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_934

    goto :goto_438

    :sswitch_441
    const-string v0, "ۨ۫۠ۦۧۛۘ۫ۖۙۦۦ۬۫ۢۤۡۨۘۢۗۤۖ۬ۘ۠ۖۤۖۤۥۘ۠ۦۨۢۙۘ"

    goto/16 :goto_2

    :sswitch_445
    const-string v0, "ۘۢۘۘۤۤ۠ۘ۬۬۠ۢۘۙۢۚۚۗۖۘۚۢۘۖ۫ۡۤۘۧ۫ۘۘ۬ۙۦۘۧۥۚۧۥۥۚ۬ۦۘ"

    goto :goto_438

    :sswitch_448
    const v2, -0x379c655d

    const-string v0, "ۖۗۥ۫ۡۙۛۛۥۘۤۜۥۧ۬ۜۛۘۘۧۖ۠ۨۖۥۛۢۦۘۖۦۨۘ۫ۗۜ۫ۘۨۘ۠۟ۚۤۤ۫"

    :goto_44d
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_946

    goto :goto_44d

    :sswitch_456
    const-string v0, "ۚ۫ۗۥۢۥۘ۟ۚۧ۠ۘۡ۠ۖۙۧۨۧ۫ۢۥۧۢۘۖ۠۫ۛۚۜ۫ۙۖۜۜۥۘ"

    goto :goto_44d

    :cond_459
    const-string v0, "ۤ۠۬ۥۘۚۦۥۗۦ۠ۛۙۘۛۨ۠ۖۘ۟ۡ۠ۛۨۖۘۢۤۤ۟ۖۤۦۢۥۘۦۤ۫ۘۗۡۘۥ۟ۦۘۧۘۖۥۢۨۘ"

    goto :goto_44d

    :sswitch_45c
    const-wide v4, -0xd32af873c3a53bdL  # -1.0007985171019176E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_459

    const-string v0, "ۗۦ۬ۖۡۥۦۗ۟ۙۡۡۘ۟ۜ۟۠ۚ۫ۤۦۧۦۨۨۙۦۥۘۗۨۙۛ۬ۥۙۚۢ"

    goto :goto_44d

    :sswitch_46e
    const-string v0, "۫ۙۚۨۚ۠ۤۤۥۘۤ۫ۘۥۜ۠ۥۧ۬۫ۨۧۘۘۦۤ۟۬ۨ۫ۥۨۨۡۘ۫ۢۖۘۘۚۡۘۥۨۨۨۥۨۘ۟۬ۥۘ"

    goto :goto_438

    :sswitch_471
    const-string v0, "ۙۛۧۨ۫ۨۗۥۘۚۥۙ۟ۨۡۘۜ۫ۘۦۜۧۘۗۜۖۘۤۙۨ۟ۧۛ"

    goto :goto_438

    :sswitch_474
    const/16 v0, 0xf

    goto/16 :goto_60

    :sswitch_478
    const v1, 0x5c55a0be

    const-string v0, "ۗۚۘ۟ۗۨۡۤۜۘ۠ۤۗۤۜۜ۫ۛۦۘۜۖۢۧۨۚۧۢۚۡۙۦۘۥ۠ۦۘۢۙ۠ۛۘۖۘۢۨ۟"

    :goto_47d
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_958

    goto :goto_47d

    :sswitch_486
    const-string v0, "ۧۜۡۛۧۗۙۡۢۦۨۖۗۥۙ۫ۛۚۜۙ۟ۤۤۥۧۗۦ۟ۥ۬۟ۧۢ۠ۖۧۧۚۨۗۡۘۖۢ۠ۘۖ۫ۦۢ۠ۥۛۢ"

    goto/16 :goto_2

    :sswitch_48a
    const-string v0, "ۖ۠۬ۦۛۜۨۤ۠ۗۡ۫ۙۦۗۧۜۨۘۧۘ۬ۜۦۢۨۜ۫ۖۙۗۙۧۖۖۘۘۘۢۚۡۘۙۘۛ۟ۦۘۖ۟"

    goto :goto_47d

    :sswitch_48d
    const v2, 0xdeac328

    const-string v0, "ۤۗۡۨۡ۬ۤ۫۫ۙۛۜۘۗۛۢۧ۬ۘ۫ۗۘۘۛ۫ۗۙ۠ۖۘۘۙ۠۠۬ۡۜ۫۫ۨۥۜۡ۠ۗۧ۠۠ۦ۠ۧ۟ۤۦۘۙۢۖ"

    :goto_492
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_96a

    goto :goto_492

    :sswitch_49b
    const-string v0, "۫ۘ۫ۤ۬ۡۛۛۚۦۖۖۘۥۦۚۗۜۨۘۨۤۧ۬۟ۖۘۚۥۘۗۥۘ"

    goto :goto_492

    :cond_49e
    const-string v0, "۬ۛۦۘۧۗۘۡۥۛ۬ۧۨ۫ۚ۟۬ۙۥۙۖۦۘۢۦ۫ۜۡۥۚۖۨۘۘۨۘ۬ۤۤ۬ۤ۫۬ۡ"

    goto :goto_492

    :sswitch_4a1
    const-wide v4, -0xd32af893c3a53bdL  # -1.0007974752246625E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_49e

    const-string v0, "ۧۘۤۨۗ۫ۥۢ۟ۡۘۦۨۖۘۘۡۥۗۘۡ۫ۡ۬ۜۘۜۦ۬۫۠ۡ"

    goto :goto_492

    :sswitch_4b3
    const-string v0, "۬ۤۘۘۗۜۛۚ۬ۥۘۨۦ۬ۖۡۨۧۚۡۥ۬۟ۗۚۦۘ۬۫ۘۥۡ۬ۨۡۤۧۨۗۤۧۚۤۜ"

    goto :goto_47d

    :sswitch_4b6
    const-string v0, "ۥ۫ۘۨۚۧۜۥۧۘۛۛ۠ۨۢ۠ۙۜ۟۠۬ۘۛ۬ۘ۟ۦۤ۬ۖۧۘ"

    goto :goto_47d

    :sswitch_4b9
    const/16 v0, 0x10

    goto/16 :goto_60

    :sswitch_4bd
    const v1, -0x6bea1201

    const-string v0, "ۜ۫ۦۘۢۖۗۚۖۡۘ۠ۤۚ۠ۡۧۘۛۗ۟۬ۨۧۤۖۢۨۚ۠۫ۢۙ۫ۙۨۘ۬ۖۖ"

    :goto_4c2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_97c

    goto :goto_4c2

    :sswitch_4cb
    const v2, -0x69d18e8b

    const-string v0, "۫ۙۘ۟۫ۦۘۛۢۚۛۧۨۘۤۖۖۥۧۜۘ۬ۢۖۗۥۧۜۜۧۘۢۧۦۘۜۘۥۛۛۖ۫ۚۚۛ۫ۗۨۧۦ۠ۥۦۘ"

    :goto_4d0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_98e

    goto :goto_4d0

    :sswitch_4d9
    const-string v0, "ۢۙ۠۬ۢۘ۟ۛ۬ۥۛۦۧۨۦۤۖۨۘۡۙۦ۫ۤۦۘۨۘ۫۬ۗۖۘۧۨۖۘۧۚۦ"

    goto :goto_4c2

    :sswitch_4dc
    const-string v0, "ۤۛۗۦۖۢ۫ۧۙ۠ۤۨۧۜۜۘۢۜۥۙۤۗۨۨۘۥ۠ۡۘۖۦۖۙۢۡۚۗۜ"

    goto :goto_4c2

    :cond_4df
    const-string v0, "ۜۧۨۙۨۨۘ۬ۚۦۘۢۖ۟۟ۥۥۘۡۦۦۙۛۙۥۡۦۚۗۤۦۚۘۘۥ۠ۨۧۢۨۘۖۙۨۘۛۧ۬ۢۡۧۙۦۤ"

    goto :goto_4d0

    :sswitch_4e2
    const-wide v4, -0xd32af8c3c3a53bdL  # -1.0007959124087798E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_4df

    const-string v0, "ۧۖ۟۠ۘۡۜۥۚۜ۬ۥۦۧۘۥۢ۟ۧۘۧۡۧۜ۠ۛ۟ۚۖۦ"

    goto :goto_4d0

    :sswitch_4f4
    const-string v0, "ۗۤۚۖۗۢۤۥۨۥ۟ۘۙۢۦۙۚۙۧۖۘۜ۫ۚۥۗ۫ۤ۫ۜ۠ۧۗۢۤۥ"

    goto :goto_4d0

    :sswitch_4f7
    const-string v0, "ۙۙۦ۠ۙۘۘۙۛۦۘ۠۟۬ۡ۬ۥۦۖۖۘۗۥۡۢۙۙ۬ۖۘۢۗۦۘۚۥۡۜۜۚۗۦۦۧۧۥۘۥ۬ۗۘۧ۠ۚۜۜۘ"

    goto :goto_4c2

    :sswitch_4fa
    const-string v0, "ۛۥ۬۬۟۬ۧۜۜۙۦ۟ۥۡۘۖۦۡ۟۬ۛۨۡۦۥۡۖۘۖۡۡۤۖۤۖۦۦۧۛ۫ۤ۫ۜۡ۠ۦۡ۟ۚۦۛۚ۠۠۠"

    goto/16 :goto_2

    :sswitch_4fe
    const/16 v0, 0x11

    goto/16 :goto_60

    :sswitch_502
    const v1, -0x6d32bc65

    const-string v0, "ۢۙۖۘۤۙۗۤ۫ۛۡۘۖۖۤ۟ۥۤۡۦ۠ۜۢ۟ۘ۠۬ۨۘۤۦۘ۬ۗۢ۬ۙۢۗۜۘۥۦۚۘۥۧۜ۫ۙ۬ۧۜۨۘۥ"

    :goto_507
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_9a0

    goto :goto_507

    :sswitch_510
    const-string v0, "ۘۚۘۘۤ۬ۙۘۜۜۘ۬۬۬ۗۥۦۘ۟ۥ۠ۥۡۦ۫۠ۢۧۦۧۘۛۘۡ"

    goto :goto_507

    :sswitch_513
    const-string v0, "ۗۥۛۘ۬ۚ۠ۘۨۘۘۡۗۦ۫ۢۜۧ۠ۛۛۖۘۨۦۥۘ۬ۖۖۨۥۘۘۛۧۤۘۢ۫ۗۡۦۖۙۖ"

    goto :goto_507

    :sswitch_516
    const v2, -0x25f7520

    const-string v0, "۟ۧ۫۫ۚۡۛۦۦۘ۠ۢۜۙ۠۟۠ۛۨۧۙۡۤۨۘ۬۬ۜۘ۫ۧۙۙۛۖۘ۟ۚۢ"

    :goto_51b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_9b2

    goto :goto_51b

    :sswitch_524
    const-wide v4, -0xd32af763c3a53bdL  # -1.0008073730585863E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_536

    const-string v0, "ۥۜ۬ۨ۫ۚۧ۬۟ۧۤ۟ۖ۟ۥۘ۫ۨ۬۠ۘۗ۬ۜۧۘۦۧۧۦۦۙ"

    goto :goto_51b

    :cond_536
    const-string v0, "ۨۡۡۘۤۨۢ۬۟ۖۘۢۛ۠۫ۤۨۘۧۚ۟ۤۤۥۘۦ۫ۤۗ۬ۤۗۡ۬ۖ۠ۨۘ۟ۥۧۘ۬ۧ۬ۥۥۡ"

    goto :goto_51b

    :sswitch_539
    const-string v0, "ۥۛۧ۠ۜۜۘ۫۠ۙۦۛۙۙۧۦۘ۠ۖۧۘ۬۫ۧۖۘۘۡۜۧۘۢۖۗ۟ۘۙۢۢ"

    goto :goto_51b

    :sswitch_53c
    const-string v0, "۫۟ۡۘۢۢۜۗۘۜۘ۬ۜۦۖۨۥۘ۠ۛۜۘ۟ۢۙۥۖۖ۠ۙ۟ۗۨ۟ۦۖۦۥۖۛۚۧۖۘۗۜۖۥۚۘۘ۟ۨۦۘ"

    goto :goto_507

    :sswitch_53f
    const-string v0, "۫ۨۥۚۛۜۘ۟ۧ۬۟ۙۘۘ۫ۖۘۘۢۧ۠ۘۥۚۖ۫ۧ۠۬ۤۛۘۡ۟ۥۛۘۜ"

    goto/16 :goto_2

    :sswitch_543
    const/16 v0, 0x12

    goto/16 :goto_60

    :sswitch_547
    const v1, 0x7a34b9d6

    const-string v0, "ۡ۟ۜۥۢۢۛ۬ۚۛۦۤۨ۟ۜ۫ۘۢۚۖۧۡ۫ۤ۫ۨۙۘۚۗۘۜۘۚۥۦۘ۫۫ۨۘۚۙۜۘۛ۠۫ۘۦۗ"

    :goto_54c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_9c4

    goto :goto_54c

    :sswitch_555
    const-string v0, "ۢۗۤۛۢۡۥۥۖۘۘۖۧۘۢۢ۬ۚۦۖۤۖۘۘ۠ۦۜۘ۟۟ۙ۠ۛۦۚۡۧۘۜۨۧۚۜۙۤۙۡۥ۬ۘۢ۬ۥۘۘۥۘۜ۬"

    goto/16 :goto_2

    :sswitch_559
    const-string v0, "ۡۙۨ۬۫ۜۢۙۖۘۛ۟ۚۧ۬ۛ۠ۡۙ۫ۡۖۨۜۤ۬ۦۧ۬ۘۘۛۚۛۧۧ۫"

    goto :goto_54c

    :sswitch_55c
    const v2, 0xd008cbc

    const-string v0, "ۤۢۚۧۘۛۦۧ۟۟ۥۤ۬ۡۥۘ۫ۤۧ۬۫ۥۜۗۦۘۛۨۙۚۤۤ"

    :goto_561
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_9d6

    goto :goto_561

    :sswitch_56a
    const-wide v4, -0xd32af683c3a53bdL  # -1.0008146661993723E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_57c

    const-string v0, "ۜۗۖۛۥۨۘۢۘۜۘۡ۟ۖۚ۬ۥۘۖۚۘۥۢۘۢۚۗ۬ۢۥۘۤۥۧۘۗ۠ۛۗۗۦ"

    goto :goto_561

    :cond_57c
    const-string v0, "۬ۘۖۧۦۙۥۜۢ۬ۨۘۦۢۥۘۨۦ۬۫ۡ۫۠ۙۜۦۖۨۦ۫ۤۢ۟ۨۗۧۘۦۚۖۘۛۦۢۚۥۧ۟ۨۘۢۘۜۘۧ۟ۥ"

    goto :goto_561

    :sswitch_57f
    const-string v0, "ۛ۫ۖۘۚ۟ۜۨۥۜۘ۟ۡۘۢۧۙۥۨۤ۬ۘۛۢۤۘۨۥۤۥۚ"

    goto :goto_561

    :sswitch_582
    const-string v0, "۠ۤۘۘۢۘۘۦۤۡۗۜۥۘۚۖۧۘۥۦۘۘ۠ۡۘۖۚۥۘۡۛۘۘۛۛۖۘ"

    goto :goto_54c

    :sswitch_585
    const-string v0, "ۥۚ۫ۥۖۧۧۘ۟۫ۙۢۗۘۘۘۧۤۛۛۛۜ۬ۥۘۘۦۤۛ۫ۘ۬ۨۗۤۡۦۖۥۙ۫ۦ۠۠۫ۖۘۦۢۜ۠۟۫۠ۦ"

    goto :goto_54c

    :sswitch_588
    const/16 v0, 0x13

    goto/16 :goto_60

    :sswitch_58c
    const v1, -0x41fa96bf

    const-string v0, "ۗۛۥۢۖۨۘۦۦۤۦ۟ۢۦ۬ۜۘۖۗۘۨۖۡۘۖ۫ۢ۬ۖۦۛۛۜۘۧ۬۠ۚ۬ۥۥۚ۟ۦ۬ۖۖۘۗ۬ۥۥۘ"

    :goto_591
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_9e8

    goto :goto_591

    :sswitch_59a
    const-string v0, "ۖ۫ۙۢۥۨۗ۠ۜۜ۠ۗ۠ۛۘ۫ۧ۠ۚۥۖۥۢۛ۟ۖۜۢۧ۬ۧۗۚۚۢۜ"

    goto/16 :goto_2

    :sswitch_59e
    const-string v0, "ۢۧۥۥۨۡۢۚۡۖۖۜۘ۠ۖ۟۬۫ۤۙۗۙۡۢۛۨ۬۬ۙۨۛۤۛۗۤۨۘ۟ۜۦۘۦۨۤۘۖۚۧ۬ۦۘۛ۬ۦۘۙۜۘۘ"

    goto :goto_591

    :sswitch_5a1
    const v2, 0x573c833

    const-string v0, "ۡۜۨۖۧۙۜۘۨۘ۫۠ۗۦۢۙ۫ۛۖ۬۬۬ۖۙۦۘۚ۬ۛۧ۫ۥۦۤۢ۫ۡۧۘ۬۟۫ۗۗۜ"

    :goto_5a6
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_9fa

    goto :goto_5a6

    :sswitch_5af
    const-wide v4, -0xd32af553c3a53bdL  # -1.0008245640332961E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_5c1

    const-string v0, "ۥۢۘۘ۠ۙۜۘۘۚۚۨ۠ۜۚ۠۫۫۫ۜۛۡۥۘۙۙۢۛۚۢۤۙۧۨۘۖۘۨ۠ۦۦۨۧۛۤۙ"

    goto :goto_5a6

    :cond_5c1
    const-string v0, "ۡۗۥۘ۠ۙۦ۬ۘۘ۠ۢۜۘۖۛۖۘ۠۟ۦۘ۬ۛ۫ۢۥۦۛۗۗۘۘۡ"

    goto :goto_5a6

    :sswitch_5c4
    const-string v0, "ۢۨۜۘۡۜ۫ۚۥ۫ۙ۬ۡۢ۟ۧۥۥۘۘۥۖۧۚۡۖۨۤۨ۟ۛۜۘۦۨۡۡۡۖۘۘۡۘ"

    goto :goto_5a6

    :sswitch_5c7
    const-string v0, "۠ۛۖۘۚ۟ۛۥۛۚۧۨۜۘۙۡ۠ۥۙۘۢۧ۟ۚۧ۬۫ۡۜۘۤۛ۟ۦۗ۫ۦۚۥۗۗ۟ۢۖۚۙ۫۠۬ۖ۫ۧ۫ۥۦ"

    goto :goto_591

    :sswitch_5ca
    const-string v0, "ۢۗۗۘ۫ۢۡۤۤۤۚۛۜۘۜۚۜۘۤۖ۟ۖۧ۠ۜ۫ۘۙۛۛۙۢۥۘۘۗ۠ۤۘۙۤۨۚ"

    goto :goto_591

    :sswitch_5cd
    const-string v0, "ۢۖۚۗۘۘۘ۬۠ۤۧۜۥۜ۟۠ۡۥۙۖۖۛۥۨۦۨۜۢۘۜۡۘۦ۠۟۫ۥۘ۟ۘۥ۬۠ۚ۠ۢۧۘۥۧۘۘۦۥۘۢ۬ۤ"

    goto/16 :goto_2

    :sswitch_5d1
    const/16 v0, 0x14

    goto/16 :goto_60

    :sswitch_5d5
    const v1, 0x639df05e

    const-string v0, "ۦۛۢۙ۬ۖۜۤ۟ۤۘۨۖۥۖۥۙۚۡ۬ۡۘۢۚۨ۫ۥۨۘۖ۠ۢ۟ۖۘۥ۟۟ۧۡۦۘۥۦۖۤۢ۫ۧۙۙ"

    :goto_5da
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_a0c

    goto :goto_5da

    :sswitch_5e3
    const v2, -0x40d22339

    const-string v0, "ۦ۫ۖۛۤۧ۫ۤ۬ۢۛۖۘ۬ۖۥ۟ۚۢۛۡۖۘ۠ۙۛۤۦۖۨۛۦۜۡۡۜۧۦۛۨۧۘ۬ۜۥۘ"

    :goto_5e8
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_a1e

    goto :goto_5e8

    :sswitch_5f1
    const-string v0, "۫ۡۨۜ۬ۧ۬۠ۨۤ۟ۡۘۢۤۥ۟ۧ۟۟ۖۙۤ۠ۡۜۘۤۜۘۘ"

    goto :goto_5da

    :cond_5f4
    const-string v0, "ۨۦۧۥۛۥۛۦ۠ۗۨ۬ۥۧ۠ۜۥۧۘ۫ۖۧۘۥۗۙ۬ۗۖۘ۫ۥۨۘۧۚۡۘ۟ۡۦ"

    goto :goto_5e8

    :sswitch_5f7
    const-wide v4, -0xd32af423c3a53bdL  # -1.0008344618672199E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_5f4

    const-string v0, "ۦۘ۬ۢۖۗ۬ۛۖۦ۬ۚۜۛۗۡ۟ۥۘۧ۬ۥ۫ۜ۠ۙۨۛۨ۬ۜۘۧۜۧۨ۟۫ۘۥۖ۬ۤۨۦۦۚۗ۫ۥ۟۠۫ۥ۠"

    goto :goto_5e8

    :sswitch_609
    const-string v0, "ۢۘۜۡۢۙۚۥ۬ۨۛۧۙۜۡۗۤۖۘۦۦۚۛۘۧ۫ۗۚ۫ۢۦۚۘۘۨۗۢۧۢ۠ۘ۟ۗۧ۟ۤ۟ۥۘ۠ۦۘۘۧۗۗ"

    goto :goto_5e8

    :sswitch_60c
    const-string v0, "ۚۥ۟ۥ۫ۧۨ۫ۘۤۤۛۗۤۡۘۦۚۦۘۗۘۨۘ۫۠ۡۘۙۡۗۨۤۜۘ"

    goto :goto_5da

    :sswitch_60f
    const-string v0, "۟۫۠ۘ۬ۤۗۢۛۙۚۧۡ۠ۗ۠ۜۡۘۥۜۧۘ۫ۖۘۘۨۨۥۦۘۜۤۚۖۘۙ۬ۘۘ۟ۗۨۘۖۚۨۘۜۚۨۧۖۘۚۚۨۘۚۦۦ"

    goto :goto_5da

    :sswitch_612
    const-string v0, "ۡۡۘۘ۫ۨۚۦۘۡۘۗ۬۠ۖۧ۫ۙۡۦۤۡ۟۬ۡۛۡۖۘ۬ۙۦۖ۠ۦۘۙۦۜ"

    goto/16 :goto_2

    :sswitch_616
    const/16 v0, 0x15

    goto/16 :goto_60

    :sswitch_61a
    const/4 v0, -0x1

    goto/16 :goto_60

    :sswitch_61d
    const-string v0, "ۦۖ۟ۤۗۦۘۨۨۖۘۤۘ۫ۚۨۚ۟ۨۦۗ۫ۘۨۗۨۢۡۦۘۛۤ۫ۚۥۨۘۥۘ"

    goto/16 :goto_2

    :sswitch_621
    const-string v0, "ۧۜۦۚۤۚۗۙۜۤۚۗۥۛۨۤۘۘ۠ۜۖۘۧ۫ۧ۬۬ۦۘۢۦۛۛۥۗۨۘۘ"

    goto/16 :goto_2

    :sswitch_625
    const-string v0, "ۨۚۘۜۢۘۘۗۡ۬ۙ۫۟ۥ۟ۜۧ۠۠ۧۜۘۙۚۖۘۦۜۙۧۛ۠ۘۨۦۘۘۜۡۘ۟ۦۦ۟ۦۘۙۙۛۗۤۡۘ"

    goto/16 :goto_2

    :sswitch_629
    const-string v0, "ۨۧۜۢۜ۠۬ۚۤ۬۟ۗۘۦۘۘۚۨۤۙۗۘۥۚۘ۫ۚ۟۠ۤۚۗۢۜۘۖۘۥ۟ۡۖۜۨ۠"

    goto/16 :goto_2

    :sswitch_62d
    const-string v0, "ۧۘۡ۫۫ۘۘۗۧ۫ۚۘۗ۫ۥۗۤۖۨ۬ۥۧۘ۬ۗۗۘۘۥۘ۠ۛۛۡ۬ۜۘۛۜۘۛۤۨۘۥۧۜۘۘۖۜ۠۫ۤۜ۟۟ۨۘ"

    goto/16 :goto_2

    :sswitch_631
    const-string v0, "ۘۥ۠ۛۡۦ۫ۙ۠ۚۗۥۡۚۤۨۗۚۜۢۗۜ۠ۨۘۤۚۖۘ۟ۜۘ"

    goto/16 :goto_2

    :sswitch_635
    const-string v0, "۫ۥۦۘۥۚۛۧ۠۠ۤۖۜۦۤۥۘۙۥۖۗۡۢۚ۬۫ۨۛۗۡۖۨۘۨۧۥۘۗ۫ۘۘۤۙ۟۬ۚۙۘۗۤۦۨۥۘۛۨۖۤۗۚ"

    goto/16 :goto_2

    :sswitch_639
    const-string v0, "ۚۥۥۙۜۜۖ۟۬ۢ۠ۗۜۥۘۤۜ۬ۥ۫۬ۖۢۢۢ۬ۥۘۧۜۖۘۚۢ۟ۧۨۖۘۡۚ۟۬ۦۛ۟ۛ۠ۛۡۛۗ۠ۥۘۗۦۜ"

    goto/16 :goto_2

    :sswitch_63d
    const-string v0, "ۨ۠ۡۘۜۜۘۨۜۦۘۢۦۜۘۢ۬ۚ۬ۙۖۘۙۡۦۢۛۚۜ۫ۤۖۖۡۘۘۚۡۘ۫ۜ۠ۙۨۥۘۧۚۦۦۥۦۘۛۛۡۨۘۗ۬ۙ"

    goto/16 :goto_2

    :sswitch_641
    const-string v0, "ۗ۫ۗۛۚۖۚۥۚۚۤۧۖۙۖ۟ۗۛۢۚۡۘۧۗ۟ۧۚۥۘۘۥۦۘ"

    goto/16 :goto_2

    :sswitch_645
    const-string v0, "۫ۥ۟ۧۜۨۖۤ۫ۡۛۦۘۦۚۜۘۤۚ۟ۙ۬ۘۜۘۢۚ۫ۘۖ۠۫ۡۖۥۘۗۡۥ"

    goto/16 :goto_2

    :sswitch_649
    const-string v0, "ۥۡۢۥۡۤۛ۫ۢۙ۬۬ۜۙۧ۬ۡۧۧۡ۟ۙۘۘۘۤۡۗۚۧۢ۟ۖۘۘۚ۠ۖۘۦۛ۠۠ۛۧ۫ۜۛۢۢ۫ۥۢ۟ۡۙۛ"

    goto/16 :goto_2

    :sswitch_64d
    const-string v0, "۟ۛۢۢ۠ۦ۠ۨۘۘۗۛۗۚۦۥۜۖۤ۫ۢۥۘۚۜۡۢۤ۬ۥ۫ۛۖۤ۬۫ۧۖ۟ۙۨۘۛ۠ۢۧ۫ۤ۟"

    goto/16 :goto_2

    :sswitch_651
    const-string v0, "ۦۘۜ۠ۛۚ۫ۧۡۘۡۡ۟۟ۙۦۘۚۨۨۗۗۖۥۡۧ۟ۢۜۘۦۨۦ"

    goto/16 :goto_2

    :sswitch_655
    const-string v0, "ۧۡۢۦۡۜۘ۟ۢۡۘۙۨۧۥۜۖۘ۫ۥۧۘ۠ۦۚۤۦۨۛۘۖۘۗۖۘۧۚۖۙۤۗ۠ۖ۠ۥۙۥۚۥۙۘۦۤ"

    goto/16 :goto_2

    nop

    :sswitch_data_65a
    .sparse-switch
        -0x7cc9098a -> :sswitch_5d5
        -0x7a9fda81 -> :sswitch_204
        -0x7a4cd9d1 -> :sswitch_24c
        -0x79a2a5f4 -> :sswitch_61a
        -0x786d6471 -> :sswitch_474
        -0x6973e462 -> :sswitch_433
        -0x59d08820 -> :sswitch_178
        -0x42bbcd73 -> :sswitch_2d6
        -0x422252d5 -> :sswitch_4bd
        -0x3a0afc58 -> :sswitch_58c
        -0x27b9feb4 -> :sswitch_16
        -0x25c421ab -> :sswitch_3e6
        -0x25718e93 -> :sswitch_291
        -0x212dea7e -> :sswitch_478
        -0x1d883111 -> :sswitch_130
        -0x1b3c0b1e -> :sswitch_e8
        -0x17d486e1 -> :sswitch_2d2
        -0x58428e2 -> :sswitch_e5
        0x6d9d250 -> :sswitch_31b
        0x7f6312b -> :sswitch_12d
        0xda04cb4 -> :sswitch_360
        0xfb79861 -> :sswitch_a2
        0x10b7b758 -> :sswitch_3a5
        0x11afd705 -> :sswitch_4fe
        0x15f7a2f4 -> :sswitch_1b9
        0x1c3346c3 -> :sswitch_3a1
        0x204c9434 -> :sswitch_588
        0x225a99ed -> :sswitch_317
        0x22761101 -> :sswitch_175
        0x276898f5 -> :sswitch_19
        0x2775a1e5 -> :sswitch_35c
        0x28fbfcc1 -> :sswitch_502
        0x2f1e70c0 -> :sswitch_543
        0x36cdbd13 -> :sswitch_5f
        0x36fbdcca -> :sswitch_249
        0x3b717ba9 -> :sswitch_a4
        0x410e6f49 -> :sswitch_42f
        0x4d81f421 -> :sswitch_616
        0x539d9b8c -> :sswitch_1bc
        0x57f5dd8d -> :sswitch_4b9
        0x59128409 -> :sswitch_3ea
        0x5edcaf21 -> :sswitch_547
        0x5f9536ba -> :sswitch_5d1
        0x607be587 -> :sswitch_28d
        0x6158fd22 -> :sswitch_1c
        0x6681b03f -> :sswitch_61
        0x7edc7dfd -> :sswitch_201
    .end sparse-switch

    :sswitch_data_718
    .sparse-switch
        -0x77a73907 -> :sswitch_5c
        -0x5f090e7 -> :sswitch_59
        -0x577d861 -> :sswitch_2a
        0x2c4a9a4d -> :sswitch_30
    .end sparse-switch

    :sswitch_data_72a
    .sparse-switch
        -0x68fb4b79 -> :sswitch_2d
        -0x34d10e9a -> :sswitch_3e
        0xc8cc18b -> :sswitch_56
        0x42341a18 -> :sswitch_53
    .end sparse-switch

    :sswitch_data_73c
    .sparse-switch
        -0x18698ff4 -> :sswitch_61d
        0x18ca343b -> :sswitch_6f
        0x2c30e74d -> :sswitch_75
        0x7c8966cf -> :sswitch_9e
    .end sparse-switch

    :sswitch_data_74e
    .sparse-switch
        -0xbf2eac0 -> :sswitch_83
        0x1b614678 -> :sswitch_72
        0x2fd00288 -> :sswitch_9b
        0x5e7bc16a -> :sswitch_98
    .end sparse-switch

    :sswitch_data_760
    .sparse-switch
        -0x32bd1459 -> :sswitch_e1
        -0x1660bc3 -> :sswitch_621
        0x158bb698 -> :sswitch_b2
        0x27ee8e68 -> :sswitch_b8
    .end sparse-switch

    :sswitch_data_772
    .sparse-switch
        -0x4de9658c -> :sswitch_c6
        -0xc4ba93 -> :sswitch_de
        0x2767d77b -> :sswitch_cc
        0x57ffc4f6 -> :sswitch_b5
    .end sparse-switch

    :sswitch_data_784
    .sparse-switch
        -0x595f18b7 -> :sswitch_fd
        -0x56d8b254 -> :sswitch_f6
        -0x29e587a9 -> :sswitch_129
        0x2c8b8646 -> :sswitch_126
    .end sparse-switch

    :sswitch_data_796
    .sparse-switch
        -0x622bafb0 -> :sswitch_fa
        0x8210655 -> :sswitch_10b
        0x16f69b42 -> :sswitch_111
        0x62358b07 -> :sswitch_123
    .end sparse-switch

    :sswitch_data_7a8
    .sparse-switch
        -0x5ab87adc -> :sswitch_16e
        -0x534acced -> :sswitch_13e
        -0x4bab620d -> :sswitch_171
        -0x1c849fa -> :sswitch_145
    .end sparse-switch

    :sswitch_data_7ba
    .sparse-switch
        -0x3e0d23cb -> :sswitch_159
        -0x312e839e -> :sswitch_142
        0x31fa69bb -> :sswitch_16b
        0x4c117f34 -> :sswitch_153
    .end sparse-switch

    :sswitch_data_7cc
    .sparse-switch
        -0x609a6b1b -> :sswitch_186
        -0x4ee5570c -> :sswitch_18d
        0x2e39d048 -> :sswitch_625
        0x57a6e7e1 -> :sswitch_1b6
    .end sparse-switch

    :sswitch_data_7de
    .sparse-switch
        -0x34a0fc69 -> :sswitch_1a1
        0x55dfbb36 -> :sswitch_19b
        0x5b0e89ca -> :sswitch_1b3
        0x63695ae4 -> :sswitch_18a
    .end sparse-switch

    :sswitch_data_7f0
    .sparse-switch
        -0x7cda4812 -> :sswitch_1fa
        0x10c32dac -> :sswitch_1fd
        0x542a8bdf -> :sswitch_1ca
        0x617a9dd0 -> :sswitch_1d1
    .end sparse-switch

    :sswitch_data_802
    .sparse-switch
        0x272b27e5 -> :sswitch_1ce
        0x3111e199 -> :sswitch_1df
        0x4fd14372 -> :sswitch_1f7
        0x518f6ca7 -> :sswitch_1e5
    .end sparse-switch

    :sswitch_data_814
    .sparse-switch
        -0x30f6cd12 -> :sswitch_242
        -0xfec901a -> :sswitch_245
        0xc35d813 -> :sswitch_212
        0xf473743 -> :sswitch_219
    .end sparse-switch

    :sswitch_data_826
    .sparse-switch
        -0x5085b90f -> :sswitch_22d
        -0x32b6586 -> :sswitch_23f
        0x1d9d4719 -> :sswitch_227
        0x62e9e76f -> :sswitch_216
    .end sparse-switch

    :sswitch_data_838
    .sparse-switch
        -0x40e0d038 -> :sswitch_28a
        -0x26fc1ce3 -> :sswitch_25a
        0x51be1764 -> :sswitch_261
        0x7b82e782 -> :sswitch_629
    .end sparse-switch

    :sswitch_data_84a
    .sparse-switch
        -0x670a6b4d -> :sswitch_287
        -0x3db916d7 -> :sswitch_284
        0x4e06efc5 -> :sswitch_26f
        0x712a1bef -> :sswitch_25e
    .end sparse-switch

    :sswitch_data_85c
    .sparse-switch
        -0x667b19ea -> :sswitch_62d
        -0x61f55001 -> :sswitch_2a6
        0x1079a092 -> :sswitch_29f
        0x443838b6 -> :sswitch_2cf
    .end sparse-switch

    :sswitch_data_86e
    .sparse-switch
        -0x4da5d462 -> :sswitch_2a3
        0x1cdedd28 -> :sswitch_2cc
        0x408c28bf -> :sswitch_2ba
        0x6c734321 -> :sswitch_2b4
    .end sparse-switch

    :sswitch_data_880
    .sparse-switch
        -0x7e91563b -> :sswitch_631
        -0x9d91454 -> :sswitch_313
        0x550d6c7f -> :sswitch_2e4
        0x6537e5c4 -> :sswitch_2ea
    .end sparse-switch

    :sswitch_data_892
    .sparse-switch
        -0x4ec23523 -> :sswitch_2fe
        -0x3a6a03a8 -> :sswitch_2f8
        0x19087b60 -> :sswitch_2e7
        0x6266af11 -> :sswitch_310
    .end sparse-switch

    :sswitch_data_8a4
    .sparse-switch
        -0x6ceee873 -> :sswitch_635
        -0x6c096f94 -> :sswitch_329
        0x5ff4dcf2 -> :sswitch_358
        0x6660ad05 -> :sswitch_355
    .end sparse-switch

    :sswitch_data_8b6
    .sparse-switch
        -0x21f79fb5 -> :sswitch_352
        0x36889c76 -> :sswitch_337
        0x580c0e4b -> :sswitch_33a
        0x5b4d0d5d -> :sswitch_340
    .end sparse-switch

    :sswitch_data_8c8
    .sparse-switch
        -0x471c532e -> :sswitch_639
        -0xfa90dbf -> :sswitch_39d
        0xb42269 -> :sswitch_39a
        0x2140036 -> :sswitch_36e
    .end sparse-switch

    :sswitch_data_8da
    .sparse-switch
        0x1d73f174 -> :sswitch_37c
        0x3ccc67c3 -> :sswitch_385
        0x5a0e13eb -> :sswitch_37f
        0x702d53df -> :sswitch_397
    .end sparse-switch

    :sswitch_data_8ec
    .sparse-switch
        -0x61c200d6 -> :sswitch_3b9
        -0x402e96fa -> :sswitch_3b3
        -0x232e8e3d -> :sswitch_63d
        -0x43c3060 -> :sswitch_3e2
    .end sparse-switch

    :sswitch_data_8fe
    .sparse-switch
        -0x424f62e2 -> :sswitch_3c7
        -0x2b2c5b0b -> :sswitch_3df
        0x294b9b4d -> :sswitch_3cd
        0x4f4b3b41 -> :sswitch_3b6
    .end sparse-switch

    :sswitch_data_910
    .sparse-switch
        -0x7f9747e6 -> :sswitch_3f8
        -0x4e50e79c -> :sswitch_42b
        0x363dc5f2 -> :sswitch_428
        0x5b903353 -> :sswitch_3ff
    .end sparse-switch

    :sswitch_data_922
    .sparse-switch
        -0x7350f735 -> :sswitch_425
        0xaae904d -> :sswitch_3fc
        0x5dd46b40 -> :sswitch_413
        0x5ebd293d -> :sswitch_40d
    .end sparse-switch

    :sswitch_data_934
    .sparse-switch
        -0x4978f18c -> :sswitch_471
        -0x2808492b -> :sswitch_641
        0x56602a78 -> :sswitch_441
        0x5f700c05 -> :sswitch_448
    .end sparse-switch

    :sswitch_data_946
    .sparse-switch
        0x1756e2d9 -> :sswitch_46e
        0x183d9a9c -> :sswitch_45c
        0x212e9f96 -> :sswitch_456
        0x424dcf37 -> :sswitch_445
    .end sparse-switch

    :sswitch_data_958
    .sparse-switch
        -0x70eb7da6 -> :sswitch_486
        -0x1a33101e -> :sswitch_4b6
        -0xa7859c9 -> :sswitch_48d
        0x1195b98e -> :sswitch_645
    .end sparse-switch

    :sswitch_data_96a
    .sparse-switch
        -0x57f9a495 -> :sswitch_4a1
        -0xb65e89d -> :sswitch_48a
        -0x3cdbfd8 -> :sswitch_4b3
        0x715ab30c -> :sswitch_49b
    .end sparse-switch

    :sswitch_data_97c
    .sparse-switch
        -0xddd5d6f -> :sswitch_649
        0x622970e -> :sswitch_4fa
        0x3311e7ba -> :sswitch_4cb
        0x386c4bcc -> :sswitch_4f7
    .end sparse-switch

    :sswitch_data_98e
    .sparse-switch
        -0x7ad62a9e -> :sswitch_4d9
        -0x7a3345da -> :sswitch_4dc
        0x98eb4ac -> :sswitch_4e2
        0x7857d99b -> :sswitch_4f4
    .end sparse-switch

    :sswitch_data_9a0
    .sparse-switch
        -0x7c3f89a1 -> :sswitch_516
        -0x2d1b0831 -> :sswitch_53f
        0x1a298dca -> :sswitch_64d
        0x77e964d8 -> :sswitch_510
    .end sparse-switch

    :sswitch_data_9b2
    .sparse-switch
        -0x4e451b36 -> :sswitch_524
        -0x4b1f8336 -> :sswitch_539
        -0xcf4ac79 -> :sswitch_53c
        0x53be94c1 -> :sswitch_513
    .end sparse-switch

    :sswitch_data_9c4
    .sparse-switch
        -0x7df2003a -> :sswitch_55c
        -0x68b7db17 -> :sswitch_585
        -0x3b3719be -> :sswitch_555
        0x488c8aa6 -> :sswitch_651
    .end sparse-switch

    :sswitch_data_9d6
    .sparse-switch
        -0x7cd74d74 -> :sswitch_582
        0x3fcd28d5 -> :sswitch_56a
        0x5dc1eaad -> :sswitch_57f
        0x797bfaab -> :sswitch_559
    .end sparse-switch

    :sswitch_data_9e8
    .sparse-switch
        -0x6fcbe77 -> :sswitch_5a1
        0x195a1461 -> :sswitch_59a
        0x65619712 -> :sswitch_5ca
        0x73f9131c -> :sswitch_5cd
    .end sparse-switch

    :sswitch_data_9fa
    .sparse-switch
        -0x75948529 -> :sswitch_5c4
        -0x42a72c08 -> :sswitch_59e
        -0x3535de88 -> :sswitch_5c7
        0x6f210a29 -> :sswitch_5af
    .end sparse-switch

    :sswitch_data_a0c
    .sparse-switch
        -0x4dd9a86e -> :sswitch_655
        -0x4acd9f8d -> :sswitch_60f
        0x57c78e8d -> :sswitch_612
        0x5d736253 -> :sswitch_5e3
    .end sparse-switch

    :sswitch_data_a1e
    .sparse-switch
        -0x1fe2b867 -> :sswitch_60c
        0x1f736823 -> :sswitch_5f1
        0x2a83b2ab -> :sswitch_5f7
        0x65d9527c -> :sswitch_609
    .end sparse-switch
.end method

.method private hideSystemUI()V
    .registers 5

    const-string v0, "ۚۧۧ۫۫ۛۛۚۘۧ۫ۙۨۘۖۦۡۘۢۘ۟ۜۦۜۘۥۢ۬۟ۤۡ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x274

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x395

    const/16 v2, 0x2fa

    const v3, 0x79bc3a68

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_2a

    goto :goto_2

    :sswitch_16
    const-string v0, "۫ۡ۠ۙۢۤۛۦ۠ۙ۬ۢۤۥۘۦۦۚ۟ۚ۠۟ۡۜ۟ۖۢۡۖۤۙ۟ۜۘۗۘ۠ۘۖۥۙۥۘۨۦۙۢ"

    goto :goto_2

    :sswitch_19
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/16 v1, 0xd04

    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const-string v0, "ۧ۫ۚۖۙۘۙۨۧۘۦ۫ۜۤۡۡۘ۠ۘۢۙ۫ۖۘۚۘۡۘۖۧۤۗۖۥ۠ۤۨۛۘۙ۟ۚۛۘ۟ۗ۟ۤۚۗۘ"

    goto :goto_2

    :sswitch_29
    return-void

    :sswitch_data_2a
    .sparse-switch
        -0x5bab90ef -> :sswitch_19
        -0x21a4e3d9 -> :sswitch_29
        0x40ca5f5b -> :sswitch_16
    .end sparse-switch
.end method

.method private installKernel(I)V
    .registers 32

    const/16 v26, 0x0

    const/16 v24, 0x0

    const/16 v23, 0x0

    const/16 v22, 0x0

    const/16 v21, 0x0

    const/16 v20, 0x0

    const/16 v19, 0x0

    const/16 v18, 0x0

    const/16 v17, 0x0

    const/16 v16, 0x0

    const/4 v15, 0x0

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/16 v25, 0x0

    const-string v2, "۬ۚۗۡۡۥۗۧۛۗ۫۟ۖ۟ۧۢ۠ۡۥ۠۬ۦۛ۫۫ۥۘ۬ۛۜۘۡ۟ۦۘۛ۟ۙۨۖ۫ۘۘۥۘ"

    :goto_25
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v27

    const/16 v28, 0x3a6

    xor-int v27, v27, v28

    move/from16 v0, v27

    xor-int/lit16 v0, v0, 0x1d6

    move/from16 v27, v0

    const/16 v28, 0x53

    const v29, -0xe7d87e7

    xor-int v27, v27, v28

    xor-int v27, v27, v29

    sparse-switch v27, :sswitch_data_2b8

    goto :goto_25

    :sswitch_40
    const-string v2, "ۛۧ۠ۢ۠ۜ۫ۥۖۜ۠ۥۘۨۨۙۙ۫۟ۨ۟ۧۥ۠ۢ۬ۨۜۖۤۨۘ"

    goto :goto_25

    :sswitch_43
    const-string v2, "ۙۢۦۘۚۡۦۘۘ۠ۥۥ۠ۦۥۦۘۥۧۤ۟۠ۥۛۧۢۗۛ۫ۡ۫۠"

    goto :goto_25

    :sswitch_46
    const-wide v26, -0xd32af4e3c3a53bdL  # -1.000828210603689E245

    invoke-static/range {v26 .. v27}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v26

    const-string v2, "ۘ۬ۡ۫ۥۦۘ۫۠ۡۘ۠ۨۨۘۚۢۛۤۜۡۘۡۢۖ۠ۚ۠ۗۚۗۦۘۖۤ۫۬ۤۛۖ۠ۗۧۦ۠ۥ"

    goto :goto_25

    :sswitch_52
    packed-switch p1, :pswitch_data_3e6

    const-string v2, "ۥۡۗۘۤۢۙۦۘ۬ۢ۟۫ۦۥۘۦۙۚۜۧۡۧۖۡۤۨ۟ۙ۟ۥ"

    goto :goto_25

    :sswitch_58
    const-string v2, "ۥۗۧۡۢۦ۟ۨ۫ۜۙۖۢۥۘۛۘۛۜۥ۬ۖۛۡۘۙۙۜۘۦۢۡۘ"

    move-object/from16 v25, v26

    goto :goto_25

    :sswitch_5d
    const-wide v28, -0xd32ade33c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v24

    const-string v2, "ۢۙۦۧۙۥۜۧۨۘ۬ۚۥۘ۟۟ۦۘ۠ۤۚۚۜۖۘ۠ۧۖۘ۫ۚۘ۟ۢۢۤ۠ۦۢۙۥۛۨۘ۫ۜۚۖۤۨۢ۫ۖۤ۬۟ۨۗۛ"

    goto :goto_25

    :sswitch_69
    const-string v2, "۬ۜۙۤۙۡۘۛ۬ۙۧۦۘۨ۠ۘۛ۬ۜۘۨ۫ۘۦۤ۠ۘۖ۬ۡۚ۠ۗۖۘۚۘۙ۬ۙۛۦۘ۬ۢۡۚۚۜۘۗۖۚۥۚۖۘ"

    move-object/from16 v25, v24

    goto :goto_25

    :sswitch_6e
    const-wide v28, -0xd32ac0c3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v23

    const-string v2, "ۙۘۦۡۦۤۙۚۨۘ۠ۖۨۘۚۜۜ۟ۘۗۥۥۛ۠ۘۘۙۨۖ۟۫ۡۖۙۗۧۦۥۘ"

    goto :goto_25

    :sswitch_7a
    const-string v2, "ۨۘۦۨۖۥۘۦۖۦۘۖۢۨۘۛ۟ۖۘۧۡۜۡۖۤ۟ۙۨۘۚۦ۟ۢۜۥۜۢۨۘۥۡۘۘۖۘۦۤۙۥۘ۠ۖ۠ۖۦۢ"

    move-object/from16 v25, v23

    goto :goto_25

    :sswitch_7f
    const-wide v28, -0xd32ac1d3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v22

    const-string v2, "۫ۦۖۘ۫۫۠ۘ۬ۜۘۨ۠ۜۚۚۨۘۙۤۨۡۡۖۡۦۘۚۡۛۥ۫ۘۘۡۛ۠ۢۡۖۥۦۙۥ۟ۚۚۜ۫ۗ۟ۜۘ۠۫ۨۢۚۦۘ"

    goto :goto_25

    :sswitch_8b
    const-string v2, "ۨ۟ۚ۬ۨۦ۠ۙۚۢۥۥۜۡۧۚۖ۬ۤۖۧۛۙۖۘۖۧۜۘ۫ۜ۠ۘ۬ۦۧۥۦۘ"

    move-object/from16 v25, v22

    goto :goto_25

    :sswitch_90
    const-wide v28, -0xd32ac213c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v21

    const-string v2, "۬ۘۚۤۛۖۘۗۤۡۙۛۥۛ۬ۖۘ۬ۨۧۘۤۨۦۢۖۖۘۥ۫ۦۘۢۦ"

    goto :goto_25

    :sswitch_9c
    const-string v2, "ۘۗۥۘۚۡۙۖۙۤ۠ۡۘ۟ۜۘۘۨۜۦۥۜۘۘۨۥۧۗۛۜۛۜۖ۫ۗۙۚۧۙۛۜۖۖۨۘ"

    move-object/from16 v25, v21

    goto :goto_25

    :sswitch_a1
    const-wide v28, -0xd32ac353c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v20

    const-string v2, "ۚۛۚۥۗۡۘۗۥۙۚۡۚۥۧۢ۠ۧۨ۬ۛۖۨۤۘۗۢۡۘ۟ۛۘۘۙۦ۬ۖۗۚۗۤۖۘۙۙۦۘۤ۬ۙۥ۟ۥۘۨ۟ۜۘ۬ۥۦۘ"

    goto/16 :goto_25

    :sswitch_ae
    const-string v2, "ۚۤۨۘ۫ۢ۬ۤۨۥ۟۬ۚۡۛۦۜ۬ۨۦۧۨۘۤۧۖۘۡۗ۟ۦۡۥۘۤۛۘۗۦۘۘ"

    move-object/from16 v25, v20

    goto/16 :goto_25

    :sswitch_b4
    const-wide v28, -0xd32ac483c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v19

    const-string v2, "ۤۙۢۥۦۡۘۜۨۡۘۧۘۘۘۢۨۘۦۤۜۘۥۡۜۘۗۙۧ۬ۙ۟ۜۚۢۛۛ۠ۥۡۦۘۦۡۢ۟ۧۨۘ۬ۧۘۘۡۤۨۨۖۨۢۖۡ"

    goto/16 :goto_25

    :sswitch_c1
    const-string v2, "ۡۨۖ۟۬۠۬۠ۚۛۚۥۖۡۜۘۡۘۛۗۢۡ۠ۦۖۤۢۨ۫ۗۜۘ۠ۥۘۚۘ۫ۙۦۢۦۙۚ"

    move-object/from16 v25, v19

    goto/16 :goto_25

    :sswitch_c7
    const-wide v28, -0xd32ac5c3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v18

    const-string v2, "ۦۜۜۘۤۘۡ۠ۜۤۛ۫ۡۘۜۛ۫ۤۗ۟ۧۦۜۘۛۧۡۧۚۡۘۧۛ۟ۘۦۨۘۡ۠ۜۘۘۚۖۘۤۖ۟"

    goto/16 :goto_25

    :sswitch_d4
    const-string v2, "ۢ۫ۚ۫ۖ۫ۨۤۢۖ۠ۗۘ۬ۡۘ۫ۥۘۧۥۖۘۙۡۢۥۙ۟ۢۡۡۘ۟۬ۤۘۤۦۘۤۛۖۚۢۘۘ"

    move-object/from16 v25, v18

    goto/16 :goto_25

    :sswitch_da
    const-wide v28, -0xd32ac573c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v17

    const-string v2, "ۢۘ۠۟۬ۦۗۘۜۦۘ۟ۚۖۜۗ۫ۗۥۧۜۗۙۤۗ۟ۥۘۡۘۛ۫ۥۘۙۧۘۙۛۨۘۧ۠ۢۡۚۤ۫ۖۙۛۦۥ۟ۜ"

    goto/16 :goto_25

    :sswitch_e7
    const-string v2, "ۥ۫ۛ۫ۦۘۗۜۦۘۚۗۤۙ۟ۡۦۡۘ۟ۖۦۘۧ۬ۢۚۙۧ۟۟ۨۗۖ۫۠۟ۡۘۗۦۡۖۖۘۛۥۘۥۘۥۜۨۘۜۛ۠"

    move-object/from16 v25, v17

    goto/16 :goto_25

    :sswitch_ed
    const-wide v28, -0xd32ac623c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v16

    const-string v2, "ۥۡۘۘۦۡۛ۟ۙۡۘۜۨۦۧ۟ۦۧۡۘۥ۠۟ۛۗۧۧ۟ۗۚۙۜ"

    goto/16 :goto_25

    :sswitch_fa
    const-string v2, "ۜۖۙۛۛۦۘۦۙۧۜۖۢۡۜۘۤۥۙۗ۠ۡۘۖۘۖۖۢ۟۠ۘۦۘ"

    move-object/from16 v25, v16

    goto/16 :goto_25

    :sswitch_100
    const-wide v28, -0xd32ac8e3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v15

    const-string v2, "ۚۡۙ۟ۡۡۘۛۚۧۖۛ۟ۡۨۘ۟ۦۡۘۧ۬ۡۘۦ۫ۛ۟ۥۦۘۙۗۚ"

    goto/16 :goto_25

    :sswitch_10d
    const-string v2, "ۢۛۥۘۨۛۤۤۘۢ۠ۗۙۦۧۦۘۘۥۜۘۥۘۡ۟ۢۖۘۘۖۡۚ۠ۥ"

    move-object/from16 v25, v15

    goto/16 :goto_25

    :sswitch_113
    const-wide v28, -0xd32ac9a3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v14

    const-string v2, "ۢ۬ۨۘ۫ۢۨۘۚۘۘۤۨۘۦ۠ۨۘۘۡۦۘ۠ۛۧۢ۫ۗۖۦۘۚۗۗ۬ۦۥۘۢۜۚ۫ۧۨۘۜۘۤۗۧۜۛۙۚ"

    goto/16 :goto_25

    :sswitch_120
    const-string v2, "ۚۦۡۖ۬ۢۥۧۥۤۨ۫ۨۖ۠ۡۤۦۜۚ۟ۚۧۛۚۜۡۥۙ۬ۥۚ۫ۢ۬ۗ"

    move-object/from16 v25, v14

    goto/16 :goto_25

    :sswitch_126
    const-wide v28, -0xd32acaa3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v13

    const-string v2, "ۖۙۨ۬۬ۡۘ۬ۨۨۛۨۤۤۗۖ۟ۦۜۘۡ۟ۨۘۢۛۥۘ۟ۙۜ۬ۧۤ"

    goto/16 :goto_25

    :sswitch_133
    const-string v2, "ۧ۫۟۬ۧۥۘ۫ۜۦۘۦۚۚۦۢۤۗۥۨۘ۟ۚۛۚۥۖۘۖۚۦۦۧۗۦۗۤۘۥۢ"

    move-object/from16 v25, v13

    goto/16 :goto_25

    :sswitch_139
    const-wide v28, -0xd32acb93c3a53bdL  # -1.001172551036512E245

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v12

    const-string v2, "ۦۘۥۘۜ۫ۗۚۦۢۡۗۘۘۖۘۨۘۥۙ۬ۖ۠ۦۖۗۖۘۢۧ۫ۛۛۤۛ۟ۦۘ۬ۧ۬ۧۢۢۖ۬ۚۗۦۦۗۢۛ"

    goto/16 :goto_25

    :sswitch_146
    const-string v2, "ۖۥۥۘۗ۫ۦۘ۠ۖۚۙ۬۟ۧ۫ۧۥۘۥۛ۟ۖۜۥۛ۟ۧۚۨۦ۫ۨۤۢۚ۠ۢ۬ۧۡ۟"

    move-object/from16 v25, v12

    goto/16 :goto_25

    :sswitch_14c
    const-wide v28, -0xd32acc93c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v11

    const-string v2, "۟ۨۛۥۖ۟ۘۤۢۜۨۘۡۡۘۘۢۘۦۡۙ۠ۘ۟ۘۘۤۚۜۘ۬ۢ"

    goto/16 :goto_25

    :sswitch_159
    const-string v2, "ۜۥۜۘۖۗۚۧ۠۠ۖ۫ۤۥۥۦۡ۬ۖ۠ۖۘۢۧۖۘۛۡۚ۠ۗۜ۟ۘۜۜۧۘۛۨۙۜۥۧ"

    move-object/from16 v25, v11

    goto/16 :goto_25

    :sswitch_15f
    const-wide v28, -0xd32acd83c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v10

    const-string v2, "۠ۙۖۘۡ۟ۡ۟ۚۢۢۘۘۘۜۛۧۜۘۛۚ۬ۧۡ۠ۨۘۥۖ۫ۦۨ۬۟ۥۘۢۛۥۘ"

    goto/16 :goto_25

    :sswitch_16c
    const-string v2, "ۨۗ۟ۖۢ۟ۨۨۖۗۡۜۚۚ۟ۧۚۧۙۙۙ۬۬ۦۘۗۤۥۛ۟ۚۛ۬ۘۘ۠ۧۥۘۙ۠ۘ۟ۖۜ۠ۘۦۤۜ"

    move-object/from16 v25, v10

    goto/16 :goto_25

    :sswitch_172
    const-wide v28, -0xd32acee3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v9

    const-string v2, "ۦ۫ۧ۟۠ۡۦۦۧۘۜۚۗۚ۬ۘۘۚۛۡۘۛۥ۠ۧ۫۟ۢۘۘۥ۟ۦۘ"

    goto/16 :goto_25

    :sswitch_17f
    const-string v2, "۟ۜۨۘۙ۟ۙۧۤۛ۟۫۫ۥ۫ۢۚۚۚۥۜ۟ۦۨۜ۟ۗ۫ۡۘۜۗۗۖۖۘ"

    move-object/from16 v25, v9

    goto/16 :goto_25

    :sswitch_185
    const-wide v28, -0xd32acfe3c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v8

    const-string v2, "۬ۚۨۨۥۚۛۨ۫ۚۗۨ۟۟ۜۥۡۡۘۥ۟ۡۦ۟ۢ۟۟ۜۤ۬ۘۨۦۘۘۥۢۥۥۗۥۙۚۥ۠۟ۗۙۜ"

    goto/16 :goto_25

    :sswitch_192
    const-string v2, "ۨ۟ۦۘۛۢۥۥۖۡۧ۟ۢ۬ۙۦۢۦۛۜۨۡۤۘۚۤ۠ۥ۠ۡۧۚۨۘۜۧۖۘۘۨ۟ۜ۫ۘۘ"

    move-object/from16 v25, v8

    goto/16 :goto_25

    :sswitch_198
    const-wide v28, -0xd32af0e3c3a53bdL  # -1.0008615506758535E245

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v7

    const-string v2, "۟ۤ۠ۚۧۜۤۗۦۘۗۛۘۨۧۗ۬ۖۨ۟۫ۢ۬ۛۡۘ۫ۡۢۘۜۦۘ۟ۖۨۛۥۘ"

    goto/16 :goto_25

    :sswitch_1a5
    const-string v2, "ۥۢۥۘۚۛۦۘ۟ۖۛۛۚۥ۟۟ۨۘۛ۫ۘ۫ۧۨۘۢ۬ۦۗۡ۬ۗۗۘۘۘۨۤۧۜۨۘۜۨۥۘ۬ۢۚ۫ۢ۟ۧ۫ۥۘۡۨ۫ۚۚ۬"

    move-object/from16 v25, v7

    goto/16 :goto_25

    :sswitch_1ab
    const-wide v28, -0xd32af1d3c3a53bdL  # -1.0008537365964399E245

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v6

    const-string v2, "ۙ۠ۖۘۤۙۥۘۨ۟ۥۚ۬ۘۘۧۡۘۡۛۘۘۧۥۤۢۙۚۨۡۦۘۨۥۥۘۥۥۥۘۖۢۡ۫ۙ۬۠ۗۖۘۚۢ۬ۜۥۧۛۜۘۛۡۘ"

    goto/16 :goto_25

    :sswitch_1b8
    const-string v2, "ۥۧۨۘ۫۠ۧۤۡ۠ۚۡ۟۟ۨۘۚۘۧ۬ۤ۬ۙۧ۬ۡ۠ۥۘۘۗۨ۫ۨ۠ۡۛۗ"

    move-object/from16 v25, v6

    goto/16 :goto_25

    :sswitch_1be
    const-wide v28, -0xd32af2c3c3a53bdL  # -1.0008459225170264E245

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v5

    const-string v2, "ۘۧ۬۬ۤ۟ۚ۟ۨ۬ۤۘ۟۬ۢ۫ۥۜ۠ۚۛۘۡۦ۫ۨۖۘۗۧۧ"

    goto/16 :goto_25

    :sswitch_1cb
    const-string v2, "ۧۗ۫ۧۡۚۘۗۥۘۗ۫ۤ۠ۤۚۖۘۧ۠۫۫ۛ۫ۤۜۘۦۨۘۛۙۥۘۧۗۦۘۧ۬۠۬۠ۢۧۥۘۡۙ۠"

    move-object/from16 v25, v5

    goto/16 :goto_25

    :sswitch_1d1
    const-wide v28, -0xd32af233c3a53bdL  # -1.0008506109646745E245

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v4

    const-string v2, "۠ۢۨۘ۟ۛۧۙۧۦۘۧۜۜ۫ۚۥۘۜ۟ۜۘۤ۟ۚ۠ۡۙۧۨۗۥۤۚۡ۬ۘ۠ۡۡ۫ۤۛ۠ۜ۫ۢۨ۠۫ۦۦۘ"

    goto/16 :goto_25

    :sswitch_1de
    const-string v2, "ۡۡ۫۟۫ۡۘۜ۬ۘ۟۟ۤۥ۬۠ۘۘۖۘۦۚۨ۟ۖۢۡۡۜۛۢۗۖۡۡ۫ۧۗ"

    move-object/from16 v25, v4

    goto/16 :goto_25

    :sswitch_1e4
    const-wide v2, -0xd32af4d3c3a53bdL  # -1.0008287315423166E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v3

    const-string v2, "ۨ۟ۢۧۡۖۘۥ۫ۜۘۜ۟ۦۤۗ۠۟ۛۛۛۖۢۦۢ۫ۥۙۖۘ۟ۨ۫۬ۢۡۛۨۤۜۦۘۢۜۘ۟ۧۢۧۦۗۚۚۛ۫۟ۦ"

    goto/16 :goto_25

    :sswitch_1f1
    const-string v2, "ۙۘۧۚۚۡۘۙۜۥۘۖۢۥ۬۫ۘۘۘ۬ۛۦۢۥۘ۬۟ۘۜۜۙۙۘۖۘۖۖۚۦۥۢ"

    goto/16 :goto_25

    :sswitch_1f5
    const-string v2, "ۖ۠ۚۚۡ۫۬ۙۜۧۡ۠ۡۡۨۡۛۚۥۢۖۘ۟ۢۖ۠ۜۚ۫ۜۜۘ"

    move-object/from16 v25, v3

    goto/16 :goto_25

    :sswitch_1fb
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v27

    move-object/from16 v0, v27

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-wide v28, -0xd32add13c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v0, v27

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v0, p0

    move-object/from16 v1, v25

    invoke-direct {v0, v2, v1}, Lpubgm/loader/activity/MainActivity;->MoveAssets(Ljava/lang/String;Ljava/lang/String;)Z

    const-string v2, "ۤۨۖۘۚۦ۟ۚۙۨ۫ۢۨۘۢ۫ۧ۬۫ۖۦ۟۠ۛۦۙۗۗۙۛۖ"

    goto/16 :goto_25

    :sswitch_228
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v28, -0xd32add73c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v0, v27

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v0, v25

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-wide v28, -0xd32add53c3a53bdL

    invoke-static/range {v28 .. v29}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v0, p0

    move-object/from16 v1, v27

    invoke-virtual {v0, v2, v1}, Lpubgm/loader/activity/MainActivity;->Exec(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "ۤۗۘۘۘۖۛۧۥۖۘۖۨۚۘۛۙ۠ۤۢۤ۠ۙۢۥۥۘۛۚۖۘۙۖ۫ۛۗۘۢۖۘۖۖۘۘۗۚۗۜۖۜۨۨۢۢۨۧۘۤۚۜۘ"

    goto/16 :goto_25

    :pswitch_25a  #0x15
    const-string v2, "ۖۥۛ۠ۥۧۘۧۨۢۤۜۘۚ۠ۢ۟ۚ۠ۨۗۨۘۘۛۡۙ۫ۛۤۥۘۡۛۨۧۘۘۘۜۧ۠ۢۥۘۖۚۖۧۖۨۘ۠ۡ۠ۦۖ۫"

    goto/16 :goto_25

    :pswitch_25e  #0x14
    const-string v2, "ۖ۬ۗۖۘۜۥۥۥۦۢۚ۬ۜ۠ۚۨۘۗۚۘۘۥۗ۠ۙ۬ۖۘ۫ۦۨۜۜۖۥۚۖۘ"

    goto/16 :goto_25

    :pswitch_262  #0x13
    const-string v2, "ۡۙۙۧۢۚۥۥۜۘۥۙۜ۠ۦۘۛۡۧۦۦۘۧۖ۠۬ۜ۫۟ۢۚۦ۬ۧۨۢ۬ۡۘ۟ۖۢۢۥ۠ۤ۠ۘۘ"

    goto/16 :goto_25

    :pswitch_266  #0x12
    const-string v2, "ۖۚۜۘۢۜۛ۠ۚۨۘۜۥۘ۫ۚ۟ۤ۟۬ۚۘۘۧۥۜۗۧۡۘۙۢ۠ۡۛۖۘ۬ۧۖۙ۟ۥۘۧۚۢۥۗۡۘ۟ۖۚ"

    goto/16 :goto_25

    :pswitch_26a  #0x11
    const-string v2, "ۥۡۗۘۨۚۥۚۦ۫ۧۨۘۦۢۜۛۚۛۗ۟۠ۢۧۙ۟ۧۗۨۥۚۗۦۘۤۖ۟ۜۜۥۥۚۛ۟ۦۤۤۜۡۘ"

    goto/16 :goto_25

    :pswitch_26e  #0x10
    const-string v2, "ۚۨ۫ۥ۠۠ۘ۟ۦۨ۬ۦۘۖۢۥۢۙۖۥۤۘۖۛۚۜۙۙۖۖۘ"

    goto/16 :goto_25

    :pswitch_272  #0xf
    const-string v2, "ۡۙۖۥۦۖۙۘۙۗۡۧۘۖۖۡۘۧۗۨۚۗۨۥۗۚ۫ۜۥۘۥۚۥۛ۫ۧۥۛۘۘ۟ۗ۬ۦ۟ۥۘ۫ۨۢۥ۬ۙۗۦۘ۟ۦۧ"

    goto/16 :goto_25

    :pswitch_276  #0xe
    const-string v2, "ۥۖۡۗۛۙۙۦۜۘ۫ۤۤۦ۫ۢۙۢۢ۠ۗۨۘۡۨۙۚۗۚۥۨۙۚۦۧۗ۠ۜۥ۫ۤ۠۫۫"

    goto/16 :goto_25

    :pswitch_27a  #0xd
    const-string v2, "ۚۡۘۘۙۦ۠۬ۦۤ۠۫۠ۦۧۖۘ۟ۥۛۦۥۛۥۡۡۧ۫ۧ۠ۙۨۘ"

    goto/16 :goto_25

    :pswitch_27e  #0xc
    const-string v2, "ۗ۫ۡۖۙۗۢۢۦۚۜۘۘۘۢ۟ۡۧۨۦۤ۫ۚۜۤۖۜۘۘۧ۫ۦۘۧۚۡۢۤۖۙۨۨۘۢۢۡ۟ۘ۟ۖۘۥۘ"

    goto/16 :goto_25

    :pswitch_282  #0xb
    const-string v2, "ۤۧۤ۫ۖۦۚۗ۬۠ۤۗۧۖۘۘۜ۬ۙۗۖۡۘۘۡۜۨۢۘۗۨۛۖۗۥۘۤۦ۫ۨ۬ۥۢۚ۬۠ۚۥۜۨۨ"

    goto/16 :goto_25

    :pswitch_286  #0xa
    const-string v2, "ۡۜۘۘ۫ۧ۬ۦ۫ۖ۫۟ۛ۫ۧۤۥۘۨۘۜۚۦۘ۠۟۫ۚۡۘۗۤ۫۬ۘۨۘ۟ۨۦۡۤۢۦۙۛ۫ۥۖۘۨۨۖ"

    goto/16 :goto_25

    :pswitch_28a  #0x9
    const-string v2, "ۨۤۗۜۙۖۘۥۡۙۚۖۢ۟ۧۨۜۙۧۖۗۡۧ۠ۨۘۧۘۗۦۨۘ"

    goto/16 :goto_25

    :pswitch_28e  #0x8
    const-string v2, "ۜۨۜۙۡۘۘۜۨۖۘۜ۟ۜۙۜۡۢۦۜۘۙۦ۫ۥۦۛۢۦۡۘۦۨۜۘ۟۬ۡ۫ۘۜۖۙ۠ۢ۬ۡۘ۟ۢۘۘۘۛۙ"

    goto/16 :goto_25

    :pswitch_292  #0x7
    const-string v2, "ۧۘۜۘۤۢۦ۠ۜۚ۟ۢۜۘۚۜۜۘۙۦ۠ۧۥۡ۬ۡۢۜۦۛۥۢۦۡۚۘۚۖ۠ۨۨ۫ۡۡۖۧۧۡۨۖ۫"

    goto/16 :goto_25

    :pswitch_296  #0x6
    const-string v2, "ۥۖۧۙۤۥ۫۫ۡۘۗۛۘۤۦۙ۫ۚۖۘ۫۫ۦۘۚۜۚۥۗ۟ۧۧۖۘ"

    goto/16 :goto_25

    :pswitch_29a  #0x5
    const-string v2, "ۗۗ۫ۥ۠ۖۗ۬ۥۧۧۥۘۧ۟ۚۦۙۨۥۨۧۨۜۙۦ۠ۡۛ۟ۚ۬ۨۥۥۤۨۛۚۢۗۙۨ۟۠ۘۤ۠ۧۦۧۙ۬ۨ"

    goto/16 :goto_25

    :pswitch_29e  #0x4
    const-string v2, "ۜۚۗ۬ۥۙۘۜۖۤۜۖۘۖۤ۠ۘ۠ۜۛۛۗ۠ۚۜۘ۫ۖۘ۬ۗ۬ۗ۟ۧۘۜۧۘۥۚ۬۫ۘۤۗۤۖۘ۫"

    goto/16 :goto_25

    :pswitch_2a2  #0x3
    const-string v2, "ۙۖۜۥۜۚۢ۫ۨۡۙ۟ۘۧۖۘۢۘۘۛ۬ۦۘۡۜ۠۫۬۠ۧۗۤ۫ۖۗۚۙۘۘۛۗۨۧۚۚۘۘۤۛ۟ۨۘ"

    goto/16 :goto_25

    :pswitch_2a6  #0x2
    const-string v2, "۬ۘ۟۠ۥۚۡۜۧۘۢۛۗۡۥۙ۠۫ۡۘ۠ۛۜۘۘ۠ۘۘۗ۟ۨۙۗۙۦ۠ۜۤۦ"

    goto/16 :goto_25

    :pswitch_2aa  #0x1
    const-string v2, "۟ۤ۠۟ۚۡۛۨۡۘۙۨۖۨۘۚۥۤۗۨۡۘۛ۫ۤۦۜۘۘ۬ۖۦۘۜۛۜۘۢۖۚۡۖۘۘۘۚۥ۟ۜۘۘ۫ۧۘ"

    goto/16 :goto_25

    :pswitch_2ae  #0x0
    const-string v2, "۫ۤۙۤۗۜ۫۫ۚۗۙ۬ۖۛۡ۟ۛۘۡۛۡۘۥۡ۫ۧۘۜۜۙ۫ۜۛۧۤۧۛۡۥۙۜۧۘۙ۟ۗ۟۟ۧ"

    goto/16 :goto_25

    :sswitch_2b2
    const-string v2, "ۖ۠ۚۚۡ۫۬ۙۜۧۡ۠ۡۡۨۡۛۚۥۢۖۘ۟ۢۖ۠ۜۚ۫ۜۜۘ"

    goto/16 :goto_25

    :sswitch_2b6
    return-void

    nop

    :sswitch_data_2b8
    .sparse-switch
        -0x7d5acde6 -> :sswitch_c1
        -0x7c51431a -> :sswitch_10d
        -0x7a7ac6fa -> :sswitch_90
        -0x79186146 -> :sswitch_7a
        -0x752914a5 -> :sswitch_2b2
        -0x700630ef -> :sswitch_2b2
        -0x67e217a6 -> :sswitch_133
        -0x60b34af3 -> :sswitch_2b2
        -0x58e830db -> :sswitch_2b2
        -0x53804a27 -> :sswitch_1be
        -0x4e32d565 -> :sswitch_2b2
        -0x4c978951 -> :sswitch_192
        -0x474a7416 -> :sswitch_14c
        -0x457682af -> :sswitch_b4
        -0x3ca5b468 -> :sswitch_198
        -0x3c0b938f -> :sswitch_1b8
        -0x2d58fed1 -> :sswitch_d4
        -0x2bbe65e7 -> :sswitch_c7
        -0x28f1f16c -> :sswitch_40
        -0x26f32eea -> :sswitch_113
        -0x25883bea -> :sswitch_139
        -0x2416c4b5 -> :sswitch_1f5
        -0x23c861da -> :sswitch_2b2
        -0x22452820 -> :sswitch_1de
        -0x219d13a3 -> :sswitch_185
        -0x1d2cdbd5 -> :sswitch_5d
        -0x1a7172d5 -> :sswitch_69
        -0x198351ed -> :sswitch_2b2
        -0x16d785ae -> :sswitch_1cb
        -0x155a84b8 -> :sswitch_2b2
        -0x116788a0 -> :sswitch_1fb
        -0xdbf6e20 -> :sswitch_fa
        -0xb81431c -> :sswitch_100
        -0xb05b934 -> :sswitch_2b2
        -0xab510c8 -> :sswitch_2b2
        -0x90afc22 -> :sswitch_1a5
        -0x23b7fab -> :sswitch_1d1
        0x114fe5e -> :sswitch_1ab
        0x284f72d -> :sswitch_2b2
        0x31d638c -> :sswitch_16c
        0xcafd480 -> :sswitch_2b2
        0x148886f3 -> :sswitch_1f1
        0x1bc1d4af -> :sswitch_2b6
        0x1c91cb44 -> :sswitch_2b2
        0x225f8b2b -> :sswitch_146
        0x226efee9 -> :sswitch_a1
        0x250f79fc -> :sswitch_e7
        0x25bad122 -> :sswitch_2b2
        0x283a91bf -> :sswitch_da
        0x2b78494f -> :sswitch_2b2
        0x2ba2074b -> :sswitch_228
        0x2cd1892f -> :sswitch_17f
        0x31a65099 -> :sswitch_ae
        0x33a7bb12 -> :sswitch_ed
        0x37366e0c -> :sswitch_2b2
        0x3feac87a -> :sswitch_58
        0x414af494 -> :sswitch_46
        0x44d53f2e -> :sswitch_8b
        0x48dfd543 -> :sswitch_126
        0x50ad2f92 -> :sswitch_7f
        0x51495310 -> :sswitch_43
        0x55676bee -> :sswitch_6e
        0x5ceef083 -> :sswitch_159
        0x5edb28c2 -> :sswitch_2b2
        0x60cf9edc -> :sswitch_1e4
        0x6309bd18 -> :sswitch_2b2
        0x634ca102 -> :sswitch_172
        0x674a6693 -> :sswitch_2b2
        0x686a5cb7 -> :sswitch_120
        0x69a9ff95 -> :sswitch_2b2
        0x6ef11873 -> :sswitch_2b2
        0x766625e4 -> :sswitch_9c
        0x7773dbbb -> :sswitch_15f
        0x7e96bcc1 -> :sswitch_52
        0x7f0a39a8 -> :sswitch_2b2
    .end sparse-switch

    :pswitch_data_3e6
    .packed-switch 0x0
        :pswitch_2ae  #00000000
        :pswitch_2aa  #00000001
        :pswitch_2a6  #00000002
        :pswitch_2a2  #00000003
        :pswitch_29e  #00000004
        :pswitch_29a  #00000005
        :pswitch_296  #00000006
        :pswitch_292  #00000007
        :pswitch_28e  #00000008
        :pswitch_28a  #00000009
        :pswitch_286  #0000000a
        :pswitch_282  #0000000b
        :pswitch_27e  #0000000c
        :pswitch_27a  #0000000d
        :pswitch_276  #0000000e
        :pswitch_272  #0000000f
        :pswitch_26e  #00000010
        :pswitch_26a  #00000011
        :pswitch_266  #00000012
        :pswitch_262  #00000013
        :pswitch_25e  #00000014
        :pswitch_25a  #00000015
    .end packed-switch
.end method

.method public static isAppInstalled(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 5

    const/4 v0, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v2, 0x1

    :try_start_6
    invoke-virtual {v1, p1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_9
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_6 .. :try_end_9} :catch_a

    :goto_9
    return v0

    :catch_a
    move-exception v0

    const/4 v0, 0x0

    goto :goto_9
.end method

.method private isServiceRunning()Z
    .registers 8

    const/4 v3, 0x0

    const-string v0, "ۛۚۙۖۛ۠۟ۘۧۘ۟ۤۥۘۗۜۘۧ۠ۦۘۢۤۡۘۛۦۡۘ۫ۙۜ۠۬ۢۘۦۜ۠ۜۘۢ۫ۡۖۥۡۘ۬ۨۗ۠۬۟"

    move-object v1, v0

    move-object v2, v3

    move-object v4, v3

    move-object v5, v3

    :goto_7
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v3, 0x38f

    xor-int/2addr v0, v3

    xor-int/lit16 v0, v0, 0x3da

    const/16 v3, 0x2e5

    const v6, -0x7b99c1f0

    xor-int/2addr v0, v3

    xor-int/2addr v0, v6

    sparse-switch v0, :sswitch_data_112

    goto :goto_7

    :sswitch_1b
    const-string v0, "ۧۡۙۘۙۖۘۧۛۥۘۥۛۦۘۜۧ۬۟ۤۢۜۧۘۜۜۥۧۨۜۜۦۘ۫ۨۘۧۨۧۘۙۚ۫ۤۚۨۘۥۧۛۡۡۨۘ"

    move-object v1, v0

    goto :goto_7

    :sswitch_1f
    const-wide v0, -0xd32a11a3c3a53bdL  # -1.002722343453529E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    const-string v1, "ۘۤۧۡ۟ۡۘۗ۠۠ۚۛۡ۠ۗۨ۬ۜۘ۟ۨۜۛ۬ۡۘۜۥۤۥ۫ۧۙۧۘۥۡۛۗ۠۬ۥۢۗ"

    move-object v5, v0

    goto :goto_7

    :sswitch_32
    const v1, 0x262be9c7

    const-string v0, "۫۟ۨۘۙۡۜ۫ۥۖۘۦۡۦ۫۟ۦۨۡۨۗۢ۠ۨۙۚۨۘۖۦۥۛۡۖۨۤۘۘۨۥۨۤ۟ۚ۬ۥۘۜۥۦۘ۫ۖۚ۫ۧۦۘ"

    :goto_37
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v1

    sparse-switch v3, :sswitch_data_13c

    goto :goto_37

    :sswitch_40
    const-string v0, "ۥۗۖۤ۫ۙۢۢۡۘۨۘ۟ۚۙۘ۟ۘۦۘ۫ۢۘۘ۫ۖ۫ۖۛۥۨۖۘۤۜۘۛ۫۫ۘۗۢ۠ۦ۟"

    goto :goto_37

    :sswitch_43
    const-string v0, "ۢ۫ۨۦۨۢ۠ۡۛۜۦۧۘ۬ۗۡۘۨۛۨۧۥۚۖۤ۠ۗۡۖۗۢۛۧ۠ۗۧۖۛۦۤۗۖۥۤۖۘۛۙ"

    goto :goto_37

    :sswitch_46
    const v3, 0x4c96a49e  # 7.8980336E7f

    const-string v0, "ۨۗۡۘۖۨ۫۟ۜۦ۟ۤ۟۠ۨ۟ۤ۫ۗۥۥۖۘۨۨۚ۫ۜ۬ۥۦۘۙۖۗۘۡۢ۟ۥۦۘۗۘۤ"

    :goto_4b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v3

    sparse-switch v6, :sswitch_data_14e

    goto :goto_4b

    :sswitch_54
    const-string v0, "۫ۥۦۥۖۦۘ۠ۘۢ۬۬ۨۘ۟ۗۖۛۡۗۥۘۘۖۤۘۗۛ۬ۡۥۨ۫۠ۜۘۦ۠ۗۨۧ۟ۨۦۘ"

    goto :goto_37

    :cond_57
    const-string v0, "ۨ۫ۥۙۨۦۘۛۛۜۘۛۘۧۘۥۘۜۘۥۚۙ۬ۗۖ۟ۤۥۘۘۡۘۘۜۧ۠۫ۗۗۥۗ۫"

    goto :goto_4b

    :sswitch_5a
    if-eqz v5, :cond_57

    const-string v0, "ۖۨۚۜۦۙۖۘۨۘۥۢ۫ۥۘۚۗۜۘۙۦۙۗ۫۠۟ۡۦۛۢۙۤ۟۫ۚۧۖۘ"

    goto :goto_4b

    :sswitch_5f
    const-string v0, "ۜۚۧۤۧۦۢۜ۬ۘۤ۠ۙ۬۟ۚۖۧۘۥۢۤ۟ۙ۠۟۬ۖۚۖۧۘۧۖۜۘۦۥۡۘۢۡۦۘۢۙ۬ۗۘۖۗۙ"

    goto :goto_4b

    :sswitch_62
    const-string v0, "ۗۘۜۥ۠ۦۘۚۘۛۚ۟ۘۘۨۖۥ۠ۦۚۦۛ۫ۜۥۘۡۢ۬ۛۢۤۜۦۘ۠ۢ۫"

    move-object v1, v0

    goto :goto_7

    :sswitch_66
    const v0, 0x7fffffff

    invoke-virtual {v5, v0}, Landroid/app/ActivityManager;->getRunningServices(I)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const-string v0, "ۧۤ۠ۦۖۙ۠ۛۜۘۦۤۜۘۧ۠ۡۗۛ۫۟ۢۦۘۘۙ۠ۥۤۛۛۚ۠ۙۘۘ۬ۤۘۢۖ۟ۧۢۨۤۢۡۘۡۜۘۗۡۙۚۜۛ"

    move-object v1, v0

    move-object v4, v3

    goto :goto_7

    :sswitch_76
    const v1, 0x4a26373f  # 2723279.8f

    const-string v0, "ۧۤۥۙ۬ۖۨۧۜۘۥۖ۠ۡۨۘ۫ۙ۠ۧۡ۬۠۟ۗۡۤۤۤۙۡ۬ۖۜۘۧۛۥۜۘۥۖۜۖۘۚۘۨۜۛۨۘ۬ۛۢۗۤۛ"

    :goto_7b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v1

    sparse-switch v3, :sswitch_data_160

    goto :goto_7b

    :sswitch_84
    const-string v0, "۟ۨۜۘۥ۫۟ۥ۟ۨ۫ۧۛۢۡۘۤۙۦۘ۬ۡۗۖ۫ۦۘۤۙۡۜۦۧۘ"

    move-object v1, v0

    goto :goto_7

    :sswitch_88
    const-string v0, "ۚۤۙۧۤۡۘۙ۟ۦۖ۬ۥۨۦۚ۬ۛۢۨۤۦۘۨۢ۠ۘۜۧۧۚۥۘۥۛۦۗۖۗۡۘۘ۬ۖۦ"

    goto :goto_7b

    :sswitch_8b
    const v3, 0xfe48eab

    const-string v0, "۬ۜۖۡ۠ۘۘ۟ۨۚ۫ۦۥۘ۬ۚۘۘۥۦۖۗۜۘۜۡۘۥ۟ۦۘۖۧۚۡۦۛ۟۠ۘۡۛۘۜ۠ۡۡۤۗۚۛۗ۬ۨۖۜۢۖ"

    :goto_90
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v3

    sparse-switch v6, :sswitch_data_172

    goto :goto_90

    :sswitch_99
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a2

    const-string v0, "ۗۢ۬ۛۢۗۧۘۨۨۜۧۙۥۘۤۗۘۘ۠ۧ۟ۧۨۨۘۗۛ۬۟۬ۘ"

    goto :goto_90

    :cond_a2
    const-string v0, "ۦۨۢۗ۬ۚۧۥ۟ۚ۫۬۠۫ۡۘۥ۠ۛۛۜۗۨۡۖۘۙۤۜۢۥۧ۬ۤۦۘۡۚۘۘ"

    goto :goto_90

    :sswitch_a5
    const-string v0, "۫ۘۜۘۗۗۚۗ۬ۨۧۢۜۘۡۚۢۤۗۗ۬ۢۦۙۚۘۘ۫ۙۧ۬ۖۥ۟ۜۖۧ۫ۨ۠۫ۙ۟ۚۙۤۤۤۚ"

    goto :goto_90

    :sswitch_a8
    const-string v0, "ۖۘۦ۫ۤۦۗۥۜۦۧۘۘۧۥۖۘۖ۟ۢۛۛۥۘ۠ۨۦۘۦۧۥۤۨۖۤۜۜۘۚۥ۫۫ۖۤۖۧ"

    goto :goto_7b

    :sswitch_ab
    const-string v0, "ۜ۬۠ۖۚۙۥۧ۠ۧۗۨ۟ۖۡۡۜ۟ۥ۟ۜ۟ۢۦۘۛ۠ۡ۠ۘۘۘ۬ۥۦۖۛۥۘ"

    goto :goto_7b

    :sswitch_ae
    const-string v0, "ۨۢۦۘۥ۬ۨۘۡ۬ۡۙ۠ۗۤۘۘۚۗۥۘۜۦ۫ۜ۟ۘۢۜۨۨۗۧ"

    move-object v1, v0

    goto/16 :goto_7

    :sswitch_b3
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager$RunningServiceInfo;

    const-string v1, "۠ۗۜۘ۟ۖۗۥ۬ۤۖۗۧۦۜۜۘۙ۠ۦۘۧۜ۬ۦۢۤ۟ۘ۫ۙۚۢۗۜۚۖۧ۠ۖ۟ۖۘۙۥۢۨ۬ۨۘۨ۠۟"

    move-object v2, v0

    goto/16 :goto_7

    :sswitch_be
    const v1, -0x6c8bae72

    const-string v0, "ۛ۠ۡۘۚۛ۠ۗۙۜۘۛۙۡۘۧۡۖ۟ۜۦۥۡ۠ۦ۟۬ۗ۫ۘۘۥۡۦۤۢۘۘۖۚ۬ۙۧۗ"

    :goto_c3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v1

    sparse-switch v3, :sswitch_data_184

    goto :goto_c3

    :sswitch_cc
    const-string v0, "ۡۧ۠ۨۜۛ۟ۤۦۦ۟ۖۘۡۜۜۘ۫۬ۖۘ۟ۚۙۜۤۙۚ۟ۗ۟۟۬ۖۖۘۙ۬۟ۘۤۜۘۤ۫۫"

    goto :goto_c3

    :sswitch_cf
    const-string v0, "ۢ۠ۡ۟۬ۡۘ۬ۤۚۙۙۨۘۤۦۛ۬۟۬۬ۙۜۘ۠۠ۡۘۦ۠ۡۧۦۗ"

    goto :goto_c3

    :sswitch_d2
    const v3, -0x31ca2e5d

    const-string v0, "ۢۤۘۘۚۧۤۖۧۛۤۢۥۘ۟ۦۖۘۧۛ۬ۤۙۥۘ۬ۗ۫۠ۨۡۡۦۗۘۜۜۘۦۘ۟ۗۖۦۘۥۦۘۘ"

    :goto_d7
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v3

    sparse-switch v6, :sswitch_data_196

    goto :goto_d7

    :sswitch_e0
    const-string v0, "ۧۡۜ۫ۡۥۘ۠ۧ۟ۙۨۨۘۜ۟۟ۤ۟ۨۘۘۤۨۘۤۛۘۦۛۨۢۨۢ"

    goto :goto_c3

    :cond_e3
    const-string v0, "ۥۨۘۘۨۖۦۘۧ۫۫۠۟۬ۜۚۡۘۜۚۖۘۤۤۘۗ۟ۜۖۜۖۘۜۖ۠"

    goto :goto_d7

    :sswitch_e6
    const-class v0, Lpubgm/loader/floating/FloatingService;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    iget-object v6, v2, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    invoke-virtual {v6}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e3

    const-string v0, "ۥ۟ۚ۟ۤۢۙۜۘۨۘۢۤۦۥۘۖۜۨۙ۫ۖۛۜ۬ۦ۠ۥۘۖۦ۫"

    goto :goto_d7

    :sswitch_fb
    const-string v0, "۫۟ۖۤۡ۫ۙۢۨۘۤۢ۠ۗۜۥۘۘۤۨۘۘ۟۫۬۫ۡۘۡۨ۠ۦۤۜۘۤۢۗۚ۬ۙۖۚۜۘۦۨۨۥۥۦۘۥۛۘۘ"

    goto :goto_d7

    :sswitch_fe
    const-string v0, "۬ۧۦۥۙ۠ۦۙۡۘۦۚۜۘۥۤۘۢۦۘۛۘۧۤ۟ۡۡۤۦۘۧۘۡۛۖۘۚ۬ۡۡۛۘۢۦ۬ۢۥۘ۟ۚۖۘ۫ۛۗۛۨۡۘ"

    move-object v1, v0

    goto/16 :goto_7

    :sswitch_103
    const/4 v0, 0x1

    :goto_104
    return v0

    :sswitch_105
    const/4 v0, 0x0

    goto :goto_104

    :sswitch_107
    const-string v0, "ۧۤ۠ۦۖۙ۠ۛۜۘۦۤۜۘۧ۠ۡۗۛ۫۟ۢۦۘۘۙ۠ۥۤۛۛۚ۠ۙۘۘ۬ۤۘۢۖ۟ۧۢۨۤۢۡۘۡۜۘۗۡۙۚۜۛ"

    move-object v1, v0

    goto/16 :goto_7

    :sswitch_10c
    const-string v0, "۬ۘۨۘۚۜۘۘۗۥۘۖۤۤۨ۠ۖۦۛ۬۬ۢۙ۬ۙۗ۬ۨۧۡۢ"

    move-object v1, v0

    goto/16 :goto_7

    nop

    :sswitch_data_112
    .sparse-switch
        -0x7524e063 -> :sswitch_66
        -0x42765c10 -> :sswitch_76
        -0x404350fd -> :sswitch_be
        -0x284b1a47 -> :sswitch_105
        -0x20858332 -> :sswitch_1f
        0x2e6ffad5 -> :sswitch_b3
        0x3030986a -> :sswitch_1b
        0x3c1aff7d -> :sswitch_32
        0x3d1fb03e -> :sswitch_103
        0x717e6622 -> :sswitch_107
    .end sparse-switch

    :sswitch_data_13c
    .sparse-switch
        -0x4fade9c0 -> :sswitch_40
        -0x23f23733 -> :sswitch_62
        0xd27cbc9 -> :sswitch_46
        0x4bf1a484 -> :sswitch_84
    .end sparse-switch

    :sswitch_data_14e
    .sparse-switch
        -0x5dc73c10 -> :sswitch_54
        -0x57e8d715 -> :sswitch_5a
        -0x1bccfe92 -> :sswitch_5f
        0x51e09321 -> :sswitch_43
    .end sparse-switch

    :sswitch_data_160
    .sparse-switch
        0x5b5f610 -> :sswitch_ae
        0xe25bfbc -> :sswitch_8b
        0x2c559b22 -> :sswitch_84
        0x54507af3 -> :sswitch_ab
    .end sparse-switch

    :sswitch_data_172
    .sparse-switch
        -0x67e642fd -> :sswitch_88
        -0x327e8405 -> :sswitch_a8
        -0x3199f53d -> :sswitch_99
        0x2c26d1d3 -> :sswitch_a5
    .end sparse-switch

    :sswitch_data_184
    .sparse-switch
        -0x4e73d92e -> :sswitch_10c
        -0x1dfff833 -> :sswitch_d2
        0x1690a73d -> :sswitch_cc
        0x6d08bf3c -> :sswitch_fe
    .end sparse-switch

    :sswitch_data_196
    .sparse-switch
        -0x78119149 -> :sswitch_fb
        -0x6a44db6b -> :sswitch_e0
        -0x2df6b02c -> :sswitch_e6
        0x6365c667 -> :sswitch_cf
    .end sparse-switch
.end method

.method private showSystemUI()V
    .registers 5

    const-string v0, "۠۫۠ۥۘۘ۫ۚ۬ۗۖ۠ۖۘۧۢۧۢۧۥۧۙۘۘ۠ۡۥۘ۟ۨۤ۫ۛۘۨۘۘ۬ۘۜۚ۠۟ۙۡۤ۬ۗ۫"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x23

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x163

    const/16 v2, 0x109

    const v3, -0x4645f1a

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_2a

    goto :goto_2

    :sswitch_16
    const-string v0, "ۧ۬۟ۚۘۡ۠ۖۨۥۖۚۙۛ۬ۖۨۤ۬۠۠۫ۘ۫ۥۦۖۦۛ۟ۖۥۥۘۖ۟ۨۦۦۢۚ"

    goto :goto_2

    :sswitch_19
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x500

    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const-string v0, "ۥ۬ۜۘۗۧۖۢۨۘۘۦۤۘۤۧۙۥۡۧ۠۠۠۟۟ۖۖۜۨۥۥۢۚۛۡۤۗۨ۫ۨۘۙۘۛ۬۬ۛ۫ۗ"

    goto :goto_2

    :sswitch_29
    return-void

    :sswitch_data_2a
    .sparse-switch
        -0x3e472ad7 -> :sswitch_19
        0x35b40b3a -> :sswitch_29
        0x7a04e697 -> :sswitch_16
    .end sparse-switch
.end method

.method private startFloater()V
    .registers 11

    const/16 v9, 0x40

    const/16 v8, 0x20

    const/4 v2, 0x0

    const-string v0, "ۦ۬ۦۥۢۦۘۗ۬ۗۥ۬ۨۘۨۘۘۛ۬ۘۘ۫ۦۖۘۨۜۥۛ۫ۛ۬۠ۡۘ"

    move v1, v2

    move v3, v2

    :goto_9
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    const/16 v5, 0x2ba

    xor-int/2addr v4, v5

    xor-int/lit16 v4, v4, 0x264

    const/16 v5, 0x4f

    const v6, 0x284ff5ae

    xor-int/2addr v4, v5

    xor-int/2addr v4, v6

    sparse-switch v4, :sswitch_data_232

    goto :goto_9

    :sswitch_1d
    const-string v0, "ۖۤ۠ۡ۠۟ۨ۬ۙۖۜۤۨۡۤۡۧ۫ۧۢۤۦۚ۠۠۟ۖۘۧۘۘۘۗۜۘۘۡۢ۬۟ۜۜ۠ۗۢۘ۬ۨۘۗۦۗ"

    goto :goto_9

    :sswitch_20
    const v4, 0x5adc2961

    const-string v0, "ۨ۫ۧۡ۬ۛ۫ۙۨ۫ۙۘۨۢۧ۠ۦۖۘۙۗۘۖۘۥۗۖۚۚ۫ۜۘ۬۫ۨ۬ۛۜۜۢۦۘۢ۫ۗۡۧۧۡۘ۟۠۠ۥۜۧ"

    :goto_25
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_288

    goto :goto_25

    :sswitch_2e
    const-string v0, "ۙ۫ۡۘۡۡۚۙۖۚۘۧۗۛۦۦ۟ۤۧۦۥۧ۬ۧۖۘۚۘ۟۠ۜۘ"

    goto :goto_25

    :sswitch_31
    const-string v0, "ۧۧۥۘۥۧۥۘۚ۠ۥۢۖۥۗ۠ۡۘۖۖۗۗ۫ۦۜۛۡۘۨۤ۠ۚۘۖۘ۬ۦ۠ۢۧۨۖۙۖۘۜ۟۬ۜۖۡ"

    goto :goto_25

    :sswitch_34
    const v5, 0x11c550ce

    const-string v0, "ۗۚۜۥ۠ۙۡۖۢۦ۟ۤ۠۫۠ۨ۟ۤۛۛۗ۬۟۫۠۟ۥۙۦۘۖ۟۠ۨۖۘ"

    :goto_39
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_29a

    goto :goto_39

    :sswitch_42
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->isServiceRunning()Z

    move-result v0

    if-nez v0, :cond_4b

    const-string v0, "ۥۧۛ۫ۨۧ۫۬ۡۘ۫ۧۦۘۖۘۘ۬ۖۜۢ۫ۖۘۥۗۜۘۧۜۦۘ۟ۨۜۘ"

    goto :goto_39

    :cond_4b
    const-string v0, "۟ۦۦۘۚۙۥۚۨۨۘۨۡۡ۠ۧ۬ۙۡ۬ۛۤۢۖۖۛۖۗۧۘۛۚ۟ۧۘ۠۬ۗ۟ۧ۫۟ۨۥ"

    goto :goto_39

    :sswitch_4e
    const-string v0, "۫ۨۖۚۨۧۨۤۖۘۘۨۦۘۜۥۧۘ۟ۙ۠۫ۡ۟ۗۚۜۘۢۗۡۘۨۜۗۨۦ۟ۜۤۗ"

    goto :goto_39

    :sswitch_51
    const-string v0, "ۧۚۗۗۨۧۘۖۤ۬ۘۦۤۡۛۛ۠ۨۥ۠ۖ۬ۗۗۜۘۨۡۧ۠۟ۗۜۦۜۧۡۡۘۨۡۘۢۤۡۘ۟ۜۖۘۙۙۤ"

    goto :goto_25

    :sswitch_54
    const-string v0, "ۜۘۜۘۥۛۡۘ۫ۢۘ۬ۦۘ۫ۧ۫ۥ۬ۧۨۘۡۘۖ۬ۜۜۘۡ۬ۗۡۛۨۨۗۖۘۘۦۜۛۡ۫ۦۘ"

    goto :goto_9

    :sswitch_57
    const v4, -0x7b778ecf

    const-string v0, "ۤ۫۠۫ۘ۠ۨۖۢۦۦۜ۠ۗۡۘۧ۬ۢۥۦۧۘۖۢۦۘۗۜۦۘ۠ۘۖ"

    :goto_5c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_2ac

    goto :goto_5c

    :sswitch_65
    const v5, 0x6dd81bce

    const-string v0, "ۙۖۛۦۚ۠ۚۗ۬۟ۗۖۘۘ۬ۚۨۘۘۥۖۨۦۨۘ۠ۗۖۘ۬ۜۡ۠ۙ۬۟ۤۖ۟ۥۧۥۨۗ۟ۖۛۜۧ"

    :goto_6a
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_2be

    goto :goto_6a

    :sswitch_73
    const-string v0, "ۖ۫ۜۘۚ۟ۘ۬ۧۡۤۡۛۦۥۧۤ۫ۘۘۡۦۧۘۜ۬ۥۘۗۡۘۘ۬ۨۙۜ۬ۜۧۨۦۘۨۡۖۛۤ"

    goto :goto_6a

    :sswitch_76
    const-string v0, "ۢۢۡۖۙ۟۫ۚۨۙۧۨ۠ۖۤۥۦ۠ۛۖۘۦۦۧۦۛۢۤۤۦۘ۠ۡۛۡۛۖۘۜۥۡۤۜۢ"

    goto :goto_5c

    :cond_79
    const-string v0, "ۧ۫۬۠ۦ۟ۤۤ۠۟ۖۜۘۡۖۡۘۖ۫ۘۘۡ۫۠ۚۗۖۘۚۤۤۦۨ۟ۗۤۗۦۡۖ"

    goto :goto_6a

    :sswitch_7c
    sget-boolean v0, Lpubgm/loader/activity/MainActivity;->kernel:Z

    if-eqz v0, :cond_79

    const-string v0, "ۚۥ۟۟ۜۢۖۗۥ۫ۜۧۢ۬ۦۘۦۨ۬ۘ۟ۖۘۙۙۡۘۥۘۧۦۦ۟ۖۜۦۢ۠ۨۦۢۚۥ۫ۡۘۦۨ۟ۢۥۖ۬ۗۡۢۢ"

    goto :goto_6a

    :sswitch_83
    const-string v0, "۫ۤ۫ۚۚۚۦ۫ۚۧۙۥ۠ۥ۠۬ۡۡۨۘۘۧۛۧۦۦۛۛۡۖۚۨۖۚ۟ۦۘ۬ۛۨۘ۬۠ۗۖ۟ۛۤۜۚ"

    goto :goto_5c

    :sswitch_86
    const-string v0, "۫ۘۙۤۗۖۨ۬ۜۘۛۡۡۤ۟ۧۖۜۘ۫ۢۥۘۢۜۡۘۖۦۦۘۘۙۥۖ۬ۖۘۦ۟ۛ"

    goto :goto_5c

    :sswitch_89
    const-string v0, "ۨ۠ۥۘۦۖۚۦ۟ۧۚۢۖۘۚۢ۠ۗۖ۟ۜ۫ۖۘ۟ۡۖۢ۫۬۟ۛۥۨۤۘۘ۟۬ۛ"

    goto/16 :goto_9

    :sswitch_8d
    sget v3, Lpubgm/loader/activity/MainActivity;->bitversi:I

    const-string v0, "ۢۘۡ۬ۥۢ۫ۗۡۘۡۙۨ۫ۨۜۙۤ۟ۙۗۡۘ۠ۛۢۥۜ۟۫ۧۦۘ۠ۦۡۗۧ۫ۥۛۙ۬ۨۙ"

    goto/16 :goto_9

    :sswitch_93
    const v4, 0xe318728

    const-string v0, "ۢۦۚۧۘۢۡۦۘۚۤۜۘۡۤۙۜۚۜۘۡ۬ۦۘ۟ۦۙۜۤۡۜۗ۬ۚ۟ۘۢۤ۬ۘۙۙۗۦۜۧۦۚۛۡۘ"

    :goto_98
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_2d0

    goto :goto_98

    :sswitch_a1
    const-string v0, "ۛۖۨۘ۠ۖ۬ۖۙۦۗ۫۫ۘۚۦ۫۬ۙۗۥۥۘ۟ۗۜۘۨۨۡ۫ۤۛ"

    goto/16 :goto_9

    :sswitch_a5
    const-string v0, "ۨ۠ۧۖۢۤۦۙ۟ۛۖۦۖۥ۠ۥۦۤۨۗۗۗ۟ۘۘۜ۠۟ۥۦۙۤۙۡۧۤ"

    goto :goto_98

    :sswitch_a8
    const v5, 0x15ce3458

    const-string v0, "ۨۤۗ۫ۛۖۥۙ۟ۥ۫ۡۘۘ۫۬ۗۜ۟ۜۚۗۥۖۙ۠ۙ۠ۨۦۨۗۢ۟ۤۤۘۘۧۧۖۘۥۖۥۘ۬ۥۜۘۙۙۡ"

    :goto_ad
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_2e2

    goto :goto_ad

    :sswitch_b6
    if-ne v3, v9, :cond_bb

    const-string v0, "ۨ۬ۡۘۥۛۢۘۡۦۘۥ۬ۦۘ۠ۦ۫۫۟ۨ۫۠ۨۖۗۨۧ۫ۤۗۤۚۚۢۜۘ۟۬ۦۘۤ۫ۡ۟ۜۧۘۦۤۡ۠ۙۜۘۧۜۜۡۨ۬"

    goto :goto_ad

    :cond_bb
    const-string v0, "۫ۗۧۥۜۦۚۥۘۘۤۛۖۢۥۜۧۛۖۘۧۧۖۘۚۚ۟ۜۧۜ۫۫ۤۖۜۗ۠ۜۖۚ۬ۦ۠ۙۡۘ۫ۡ۠ۢ۟ۘ"

    goto :goto_ad

    :sswitch_be
    const-string v0, "۟ۥۨۘۜۡۨ۟ۚۜۢۧۜ۠ۗۨ۠ۢۥۘۜۚۤۡۨۚۗ۬ۨۘۛۘۜ۫ۛ۟ۗۨۦۘۙۙۨۧۡ۠ۜۜۗۤۦۧ"

    goto :goto_ad

    :sswitch_c1
    const-string v0, "ۤ۠ۧۥ۫ۡۡۘ۫ۨۘ۫ۡۜۜۛۜۛۥ۫ۜ۠۟۟ۡۦۨۘۢۧ۫ۙۘۜۘۥۖۜ۟ۡۥۡۗۗۖۙۥۘۜۗۜۘۛۡۧۘۚ۟ۡ"

    goto :goto_98

    :sswitch_c4
    const-string v0, "ۥۥۨۘۤۜۦۘۚ۠۟۟۠ۦۘۤۗۚ۬ۜ۬ۚۖۧۡۦۦۖۥۜۘۧۨ۬ۘۡ۟ۘۖۥۜۖۨۡۡۤ"

    goto :goto_98

    :sswitch_c7
    const-wide v4, -0xd32aede3c3a53bdL  # -1.0008865557299768E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->loadAssets(Ljava/lang/String;)V

    const-string v0, "ۜۡۤۡۢۢۢۘۦۘۦۥۛۜۧۙۗۧۡۘۥ۫ۜۗۗۥۜۦۗۘۚۨۘ۟ۖۜۘۛۥۡۢۚۥۘۜ۠ۧ"

    goto/16 :goto_9

    :sswitch_d7
    const v4, 0x66ce8348

    const-string v0, "ۗ۠۠ۢۘۦۘۗۤۘۖۥۘۚ۠۫ۙۡۨۙۦۧۘۤۖ۠۠ۨۘۘۧۛ"

    :goto_dc
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_2f4

    goto :goto_dc

    :sswitch_e5
    const-string v0, "ۖۦۡۧ۟ۖۘ۟ۦ۠۬ۗۡۘۢۛۘۘۖۨۚۢۤۖۘۡۚ۫۠ۗۧۢۡۜۘ۫ۢۗۘۥۛ۠ۤ۠۟ۡۖ۫ۜۘۜۜۨ"

    goto/16 :goto_9

    :sswitch_e9
    const-string v0, "۠ۗۙ۟ۢۖۨۡۛۤ۬ۡۨۤۘۘۤۗۛۥۡۚ۠ۡۘۘۦۢۧۛۥۜۘۨۜۡۦۨۢۙۡۘ۟ۘۙۢۦۨۘ۬ۢ"

    goto :goto_dc

    :sswitch_ec
    const v5, 0x405dbd8c

    const-string v0, "ۧۢۖ۟ۘۖۗۢۢۘۤۗ۫ۥۗۦۥۘۡ۬ۦۘۙ۫ۗ۟ۨۤۨۢۙ"

    :goto_f1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_306

    goto :goto_f1

    :sswitch_fa
    if-ne v3, v8, :cond_ff

    const-string v0, "ۤۗۘۜۤۘۘۡۛۢۜۥۘ۟ۗۥۘۡۙ۫ۙۢۘۘ۠ۦۤۦۗۚ۫۫ۡۘۖۚۜ۫ۗۡۘۨ۠۟۠ۦۧۘ۟۫ۖۥۘۦۘ"

    goto :goto_f1

    :cond_ff
    const-string v0, "ۧۜ۬۟ۚۚۤۥۘۜ۟ۖۘۧۥ۟۫ۨۨۘ۫ۥۛۙۚ۟ۘ۬ۘۘۖۜۧۜۛۥۘ۟۫ۚۛۢۥۛۖۙ"

    goto :goto_f1

    :sswitch_102
    const-string v0, "ۧۥۘۘۧۙ۫ۨ۠ۛۖۘ۫ۖۨۜۦۡ۠ۨۛۨۢۢۘۘۖۘۗۥۢۙۖۤ۟ۜ۬ۡۘۗۘۥۦ۬ۢ۬ۢۘۘۧۡۥ"

    goto :goto_f1

    :sswitch_105
    const-string v0, "ۘۧۡۙۢۗۖۚ۫ۢۚۖۙۖ۫۠۫ۦۜ۫ۜ۬ۤۖۦۙۢ۬ۤۙۦۙۗۤ"

    goto :goto_dc

    :sswitch_108
    const-string v0, "۟ۥۛۥۖ۠۬ۘۖۢۥ۠ۜۙ۫ۜۦ۫ۧ۠ۜ۠ۚۚۜۘ۫ۖ۠ۗ۫۬ۨ"

    goto :goto_dc

    :sswitch_10b
    const-wide v4, -0xd32aec43c3a53bdL  # -1.0009001001342935E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->loadAssets(Ljava/lang/String;)V

    const-string v0, "۫ۚۛۘۨۘۥۦۧۜۖۤۦۙۢ۫ۘۥۘۜۦۢۤۧ۠ۘۚۥۘۧۡۧۘۙۜۥۘۗۘ۠"

    goto/16 :goto_9

    :sswitch_11b
    sget v1, Lpubgm/loader/activity/MainActivity;->bitversi:I

    const-string v0, "ۧۥۧۦۥۛۗۢ۟۬ۖۘۨۘ۫ۦۖ۬ۚۦۜۘ۟۠ۨۗ۟ۧۦۦۗ"

    goto/16 :goto_9

    :sswitch_121
    const v4, -0x4757bd83

    const-string v0, "ۤۧ۫ۧ۬ۜۘۗ۟ۨ۠ۗۡۙۨۖ۬ۜۖۨۡ۠ۘ۫۟ۚۛۜۡۧۜۘۘۦۗ۟ۚۡ"

    :goto_126
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_318

    goto :goto_126

    :sswitch_12f
    const-string v0, "ۡۜۨۘۨ۫ۜۘۨۜ۟۬ۨ۬ۙۡۦۧ۬ۗۚۗۚۘۦۜۘ۠ۨۛۘۦۥۗۡۘ۟ۢۙۜ۬ۦ"

    goto :goto_126

    :sswitch_132
    const-string v0, "۠ۧۗۗۨ۟ۖۖۥۙۙۖۛۚۖ۟ۛۚ۫ۜۘۘ۫ۖۤۜۦۦۘۡۙۖۘ"

    goto :goto_126

    :sswitch_135
    const v5, -0x541dce77

    const-string v0, "ۘۜۥۘۨۚ۠ۗۡۥۘۜۛۜۘۤۥۙۡۧۘۧۛۥ۟۠ۚ۟ۖۢۙۜۖۘۗۙۧ۫ۡۡ"

    :goto_13a
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_32a

    goto :goto_13a

    :sswitch_143
    const-string v0, "۟ۗ۟ۧۡۖۗۙۧۚۡۙ۬ۘۘۚۧ۬ۘ۠ۜۗۨ۠ۡۗۥۢۘۗۥ۬ۖۢۥۨۘ۟ۨۘۦۡۖۘ"

    goto :goto_126

    :cond_146
    const-string v0, "ۛۖۢ۫ۜۘۘ۟ۡۙۚۡۖ۟۫ۨۘۥۜۖۘۚۛۧۦ۠۟ۙ۬ۨۘۨ۫۟ۡۧۛۙۚ۫ۘۗ۫ۘۖۨ"

    goto :goto_13a

    :sswitch_149
    if-ne v1, v9, :cond_146

    const-string v0, "ۡ۫ۥۥ۟ۨۘۗۘ۫۠ۡۥۘۥۨۚۨۙۤۥ۬۬ۛۢۡۘۤۜۡۘۙۥۤۧۘ۠۟ۤۨۘ"

    goto :goto_13a

    :sswitch_14e
    const-string v0, "۠۟ۖۜۗ۫ۙۤ۫ۢۥۧۘۖۘۙۘۢۙۘۨۘۘۨۘۖۘ۫ۜۢۛۛۜ"

    goto :goto_13a

    :sswitch_151
    const-string v0, "ۚ۟ۖۘۙۢۚۤۨ۬ۡۙۡۘۤۛۜۘۤۢۖۜۛۙۥۢۨ۬ۚۛۢۙۙۤ۬ۥ۬ۖ"

    goto/16 :goto_9

    :sswitch_155
    const-wide v4, -0xd32aeb23c3a53bdL  # -1.0009094770295898E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->loadAssets(Ljava/lang/String;)V

    const-string v0, "ۜۥۤ۠۫ۢ۠ۤۤۘۢۧۙۨۛۘۙۡ۬ۤۛۘۥۖۥۘۗۤۤۚۚ۟ۤۙۛۚۘۥۜۢ۫ۡۘۡۛۥ۫ۘۘ"

    goto/16 :goto_9

    :sswitch_165
    const v4, -0x446c442f

    const-string v0, "ۦۚ۬۟ۜ۫ۖۘۦۖۥۖۘۚۨۛۤۗۗۡۥ۟۬ۨ۟ۧ۠ۛۡۥۦۘ"

    :goto_16a
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_33c

    goto :goto_16a

    :sswitch_173
    const-string v0, "ۤۡۧۘۢۨ۫ۗۨۛۖۜۤۘۛۘۘ۠ۚۥۘۥ۠ۘۘۚۘ۬۟ۥۥۘۢۘ۠ۧۖۘۘ۬۬ۘۨۥۡۘۧۗ۬"

    goto/16 :goto_9

    :sswitch_177
    const-string v0, "ۛۢۨۧۗۚ۟۟ۨۧۢۙۜۢۜۘۚۤۡۘۙۤۖۧۗۙ۟ۨۜۘۗۧۨۘ"

    goto :goto_16a

    :sswitch_17a
    const v5, -0x1ae3df63

    const-string v0, "ۧ۫ۥۘۖۘۖۧۡۡۢۦۘۧۤۜۘۨۛۧۚۛ۠ۧۦۧۘۡۢۜۘۦۖۙ۟ۧۥۗۥۥۛۖۥۘۚ۠ۢ"

    :goto_17f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_34e

    goto :goto_17f

    :sswitch_188
    if-ne v1, v8, :cond_18d

    const-string v0, "۬ۥۤۢۙۦ۟ۤۥۢۡۧۤۧۘۜۥۢۚۘۡۘۨۨۘۘ۟ۜۤۧۖۧۘۥ۟ۢۢ۟ۥۘ۠ۖۧۥۖۧ"

    goto :goto_17f

    :cond_18d
    const-string v0, "ۙ۫ۦۜ۬ۛۖۛۤۥۘۚۥۧ۬ۤۤۡۜ۟۠ۛۖۧۗۧۢ۫ۦۜۗۛۨۜۜۗۜۘۡۙۨۘۥۘۚ۬ۢۨۘ"

    goto :goto_17f

    :sswitch_190
    const-string v0, "۟ۗۜ۠ۘۦۘۙ۬ۗۖ۫ۡ۫ۛ۠ۨۢ۫ۗۚ۬ۗۙۙ۫۟ۡۘۢ۠ۡۘ"

    goto :goto_17f

    :sswitch_193
    const-string v0, "ۥۢ۬ۘ۟ۜۘ۬ۧۖۘۜ۫۟ۜۗۨۘۗ۟ۨۘۖ۠۫ۙۢۦۘۡۙۗۦ۬ۢ"

    goto :goto_16a

    :sswitch_196
    const-string v0, "ۛ۫۬۠۬ۥ۫ۖۧۘۧ۠ۘۘ۬ۗ۠۟۬ۦۘ۬ۗ۫ۤۜۛۡ۫ۦۘۧۛ۠۠ۥۘ۟ۡۜۘۗۥۗۧۡۘ۫ۚۙ۫ۛۦۘ"

    goto :goto_16a

    :sswitch_199
    const-string v0, "ۛ۟ۖۘۤ۟ۨۗ۠ۖۘۚۙ۟ۚۚۖۘۘ۬ۛۡۖ۠ۦۦۘۧۘۖۘۦ۫ۛۤۚۜۗۜۜ"

    goto/16 :goto_9

    :sswitch_19d
    const-wide v4, -0xd32aebc3c3a53bdL  # -1.0009042676433141E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->loadAssets(Ljava/lang/String;)V

    const-string v0, "ۤۡۧۘۢۨ۫ۗۨۛۖۜۤۘۛۘۘ۠ۚۥۘۥ۠ۘۘۚۘ۬۟ۥۥۘۢۘ۠ۧۖۘۘ۬۬ۘۨۥۡۘۧۗ۬"

    goto/16 :goto_9

    :sswitch_1ad
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v6, -0xd32aea53c3a53bdL  # -1.0009162492317482E245

    invoke-static {v6, v7}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    sget-object v5, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-wide v6, -0xd32ae993c3a53bdL  # -1.000922500495279E245

    invoke-static {v6, v7}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    sget-object v5, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-wide v6, -0xd32ae763c3a53bdL  # -1.0009407333472439E245

    invoke-static {v6, v7}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v2

    invoke-static {v0}, Lcom/topjohnwu/superuser/Shell;->su([Ljava/lang/String;)Lcom/topjohnwu/superuser/Shell$Job;

    move-result-object v0

    invoke-virtual {v0}, Lcom/topjohnwu/superuser/Shell$Job;->submit()V

    const-string v0, "ۜۨۜۘۤۜۗ۬۫۠ۖۜۖۘۦۖۧۧۤ۬ۘۢۢۘۧۖ۟ۨۙۘۥۜۘۢۧۤ۫ۨۘ"

    goto/16 :goto_9

    :sswitch_1f9
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v4

    const-class v5, Lpubgm/loader/floating/FloatingService;

    invoke-direct {v0, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    const-string v0, "ۥۛۦ۠۫ۦۘۗۥۤ۬۠ۥ۫ۦۧۘۜۚۚۖۢۖۘ۫ۜۦ۬ۙ۫ۘۛۦۡ۬۠۬ۨ۬۠۫ۤۘۙۡ"

    goto/16 :goto_9

    :sswitch_20b
    const v0, 0x7f0700ee

    const v4, 0x7f120108

    invoke-virtual {p0, v4}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Lpubgm/loader/activity/MainActivity;->toastImage(ILjava/lang/CharSequence;)V

    const-string v0, "ۢۛۘۘۡۘۘۘۥۘۡۤۡ۟ۦ۟۫ۘۛۥۘ۟ۨۤۗۚۨ۟۟ۡۘۢۚ۬۬ۜۘۘۡ"

    goto/16 :goto_9

    :sswitch_21c
    const-string v0, "ۜۡۚ۠۟ۘۤۙۛ۫ۘۗۗۤۦۘ۠ۙ۬ۖۧۙۙۡۦۛۡۡ۫ۧۤۥ۠۬ۧۥۘۙۘۡۘۥۡۨ۟۠ۦۘۙ۠ۦ"

    goto/16 :goto_9

    :sswitch_220
    const-string v0, "ۦۢۖ۟ۨۨۘۛۘۡۘ۠ۜۡۘۡۛۡۛ۫ۜۘۦۧۢۦۨۥۗۡۥ۠ۤۤۚۨۚۡ۠ۥۜ۫ۚۦۢۘ۬ۚۙۥ۬ۚۛۚۛۜۢۨۘ"

    goto/16 :goto_9

    :sswitch_224
    const-string v0, "ۖۥۜۡۗۤۘۛۘۘۤۗ۬ۖ۟ۘ۠ۨۜۛۛۙۢۦۥۘۖ۟ۛۛۥۥۦۚۖ۫۠"

    goto/16 :goto_9

    :sswitch_228
    const-string v0, "۬ۙۨۦ۟ۛۦۢۖۘۧۘۖۧۘۛۧۛ۬۬ۥۘۧۛۦۘۛ۠ۨ۫ۜ۠ۤ۬ۨۘۦۨ۠ۧۗ۫ۧۗۖۘ"

    goto/16 :goto_9

    :sswitch_22c
    const-string v0, "ۢۛۘۘۡۘۘۘۥۘۡۤۡ۟ۦ۟۫ۘۛۥۘ۟ۨۤۗۚۨ۟۟ۡۘۢۚ۬۬ۜۘۘۡ"

    goto/16 :goto_9

    :sswitch_230
    return-void

    nop

    :sswitch_data_232
    .sparse-switch
        -0x6e91a5d1 -> :sswitch_19d
        -0x615763cb -> :sswitch_8d
        -0x4aef70f9 -> :sswitch_1ad
        -0x48b96804 -> :sswitch_10b
        -0x409a0136 -> :sswitch_173
        -0x3f69f1d9 -> :sswitch_165
        -0x3f3f5865 -> :sswitch_57
        -0x36119cea -> :sswitch_155
        0xd2c55b2 -> :sswitch_173
        0x189bb7b5 -> :sswitch_20b
        0x1a288680 -> :sswitch_11b
        0x203f18f6 -> :sswitch_c7
        0x230402dd -> :sswitch_93
        0x235cc37e -> :sswitch_173
        0x29d09643 -> :sswitch_1f9
        0x3b4a33f9 -> :sswitch_22c
        0x4c3702b1 -> :sswitch_d7
        0x51e0b5dd -> :sswitch_230
        0x60af422e -> :sswitch_1d
        0x71edb6f6 -> :sswitch_121
        0x78a44a67 -> :sswitch_20
    .end sparse-switch

    :sswitch_data_288
    .sparse-switch
        -0x30122f28 -> :sswitch_228
        0xc4b586f -> :sswitch_2e
        0x3903d53c -> :sswitch_54
        0x43d9b29c -> :sswitch_34
    .end sparse-switch

    :sswitch_data_29a
    .sparse-switch
        -0x7b45e386 -> :sswitch_42
        -0x5a73994a -> :sswitch_4e
        -0x49824339 -> :sswitch_51
        0x514a52ad -> :sswitch_31
    .end sparse-switch

    :sswitch_data_2ac
    .sparse-switch
        -0x415b1ee4 -> :sswitch_89
        -0x3042192f -> :sswitch_220
        -0x2c394085 -> :sswitch_65
        0x14f6631d -> :sswitch_86
    .end sparse-switch

    :sswitch_data_2be
    .sparse-switch
        -0xa26bade -> :sswitch_83
        0x25504eac -> :sswitch_7c
        0x3837f78b -> :sswitch_73
        0x7594ba08 -> :sswitch_76
    .end sparse-switch

    :sswitch_data_2d0
    .sparse-switch
        -0x67b807a2 -> :sswitch_21c
        0x8e9fdc9 -> :sswitch_c4
        0x1c17b1b6 -> :sswitch_a8
        0x61b99822 -> :sswitch_a1
    .end sparse-switch

    :sswitch_data_2e2
    .sparse-switch
        -0x3b289c46 -> :sswitch_b6
        0x711f7e -> :sswitch_be
        0x56ce9493 -> :sswitch_a5
        0x7a3f2d8c -> :sswitch_c1
    .end sparse-switch

    :sswitch_data_2f4
    .sparse-switch
        -0x5d5fc75 -> :sswitch_173
        0x5aaec12b -> :sswitch_108
        0x6026ca24 -> :sswitch_e5
        0x7cd4cc1c -> :sswitch_ec
    .end sparse-switch

    :sswitch_data_306
    .sparse-switch
        -0x6356b2f6 -> :sswitch_e9
        -0x47fee50a -> :sswitch_fa
        0x34d42a49 -> :sswitch_105
        0x7f518fe1 -> :sswitch_102
    .end sparse-switch

    :sswitch_data_318
    .sparse-switch
        0x30e6f911 -> :sswitch_12f
        0x330ae135 -> :sswitch_224
        0x43719f5b -> :sswitch_151
        0x494d81be -> :sswitch_135
    .end sparse-switch

    :sswitch_data_32a
    .sparse-switch
        -0x7bbfe697 -> :sswitch_143
        -0x4901ce7f -> :sswitch_132
        -0x21bf334 -> :sswitch_149
        0x472633e0 -> :sswitch_14e
    .end sparse-switch

    :sswitch_data_33c
    .sparse-switch
        0x2067f68b -> :sswitch_17a
        0x5361cac0 -> :sswitch_199
        0x59987af4 -> :sswitch_173
        0x7b507b44 -> :sswitch_196
    .end sparse-switch

    :sswitch_data_34e
    .sparse-switch
        -0x78858948 -> :sswitch_193
        -0x2ae75d41 -> :sswitch_177
        -0x1f831925 -> :sswitch_188
        0x2d1e4b86 -> :sswitch_190
    .end sparse-switch
.end method

.method private startPatcher()V
    .registers 7

    const-string v0, "ۛ۬ۗۚ۫ۥۘ۟ۧۨۘۢۖۛۡ۠ۢۖۛۙۡۘۘ۟ۗۘۨۦۛۚۢۤۦۥۨ۬ۥۗۛۦۡۨۚ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x22a

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x19d

    const/16 v2, 0x11c

    const v3, 0x1e227e47

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_d4

    goto :goto_2

    :sswitch_16
    const-string v0, "ۤۙۡ۟ۚۦۘ۬ۙۜۘۥۚۤۡۘۗۘۦ۟۬ۘۘۛۧۛ۬ۖ۠ۖۨۛۗ۬ۜۘۚۧۡۘ"

    goto :goto_2

    :sswitch_19
    const v1, -0x6f3ed232

    const-string v0, "ۙۙۢۘۚۥۘۘۚۡ۠ۥۤۛ۫ۡۘۗۡۧۘۛۜ۟۫۫ۜ۬ۥۖۥۙۢۢۤۙۛۤۢۥۡۖۘۗۚ۬۟ۦۜ۫۫ۗ"

    :goto_1e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_f2

    goto :goto_1e

    :sswitch_27
    const-string v0, "ۘۢۖۘۦۖۢ۫ۢۙۛ۟ۢۨۤۦۘۜۢۘۘۢۗۨۜۥۦۘ۬۬۬ۜۦۜۤ۬ۘۘۚۘ"

    goto :goto_2

    :sswitch_2a
    const-string v0, "ۧۖۗۜۗ۟ۘ۬ۜۤۜۥۢ۟ۖۜۖۥۘۛۙۦۘ۟ۗ۠۬ۦۥۘ۠ۚۦۘۙۙۦۘۗۤۛۘۦۤ۬ۚۙ"

    goto :goto_1e

    :sswitch_2d
    const v2, 0x2f1ed0e1

    const-string v0, "ۚۗۚ۠ۢۜۚۜۦۘۙۖۧۤۘۘۜۡۧۥۤۢۦۜۢۡ۬ۢۦۛۙۧۚ۫ۜۙۧ۬ۤ۠ۨ۟ۦۖ۬ۦ۫ۨۧ"

    :goto_32
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_104

    goto :goto_32

    :sswitch_3b
    const-string v0, "ۥۤۧ۟۟ۡۘ۟ۙۡۘۙۤۦۦ۫ۥ۫۬ۢۨ۟ۡۘۥۖۚۘۚ۠ۥۤۜۘۙ۟ۛ۬ۦۡۘۖ۫ۨۘۡۤۜۡۧۢۜۘ۠۠ۘۗۡ"

    goto :goto_32

    :cond_3e
    const-string v0, "۫ۨ۫ۥۜۧۘۗۥۖۧ۫ۤۨۤۦۘ۟ۢۘۡۜۢ۫ۥۛۜ۟ۛ۟ۨۛۡۢۖ۬ۡۥۖ۫۠ۗۗۦۜۙ۟ۤ"

    goto :goto_32

    :sswitch_41
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x17

    if-lt v0, v3, :cond_3e

    const-string v0, "ۗۜۥۘۥۡ۠ۚ۠ۛۥ۬ۖۧۥۤۜۥۘۚۛۥۥۤۧۥۘۨۘ۟ۧۡ"

    goto :goto_32

    :sswitch_4a
    const-string v0, "ۢ۬ۥۨۙۢۚۖۨۖۗۙۖۥۘۥۨۤۨۨۤۘ۟ۛۦ۟ۥۘۢۗۘۢ۟ۧۖ۫ۦۘ۟ۤ۫ۥۗۤۤۦۘۥۢۧۥۧۤۚ۟ۨۘ"

    goto :goto_1e

    :sswitch_4d
    const-string v0, "ۛۜۖۧۡۨ۠۠ۢۗۧ۫ۘۤ۟ۤۙۜۢۜۨۖۜۖۖ۬۟۟۟۟"

    goto :goto_1e

    :sswitch_50
    const-string v0, "ۙۗۤ۟ۛ۟ۡۖۘۤۧۜ۟ۜۖۘۙۧ۬ۢۢ۟۬ۙۖۚۦۤۛ۬ۛۗۤۖۘۛۖۘۖۘۧۚۦۘ۬ۛۤ۟۠ۖۘ"

    goto :goto_2

    :sswitch_53
    const v1, -0x3650041c  # -1441660.5f

    const-string v0, "ۥۛۤۦ۫ۚۡۚۦۘۤۡۛۘ۟ۨۘ۬ۥۜۚ۬ۨۢۜۘ۫ۜۦۘۘۢۥۘ"

    :goto_58
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_116

    goto :goto_58

    :sswitch_61
    const v2, -0x3e9d7f4b

    const-string v0, "ۧ۫ۡۘۧۥۛۘۙۖۘۢۥۘۘ۫ۨۡۢۗۖۥۗۧ۠ۜۜۘۦ۬۫۠ۙۜ"

    :goto_66
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_128

    goto :goto_66

    :sswitch_6f
    const-string v0, "ۚۢۘۘۧۢۖۘۜۥ۫ۗۗۥۙۤۖۢۖۡۘۧۗۥۘۚۦۢۨۢۡۘۧۘۦۚ۬ۥ۬ۛۢۖۡۘۚ۫ۚۛۨۢۨ۬ۘۘ"

    goto :goto_58

    :sswitch_72
    const-string v0, "ۜۢ۫ۧۛۥۘ۟ۤۚۜ۠ۜۜ۠ۨ۬ۦۨۡۥۘۡۜۢۚۜۡۘۚۤ۟ۖۦ۫ۥۚۢ۫ۨ۫ۙ۠ۘۤۡۙۜۖۖۗ۬ۜۘ۫ۖۘ"

    goto :goto_58

    :cond_75
    const-string v0, "ۡۗۗۗۛۜۗۧۢ۠ۙ۟ۡ۠ۖۚۚۡۘۖۤۦۘۥۧۢۢ۠ۨ۠ۗۥ"

    goto :goto_66

    :sswitch_78
    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v0

    invoke-static {v0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_75

    const-string v0, "ۚۜۖۘۡۨۖ۟ۦۢۦۧۖۥۘۥۘۜۨۥۘۛۖۤۨۜۧۨۙ۟ۦ۠ۤ۠ۛۡ۬ۨۧ"

    goto :goto_66

    :sswitch_85
    const-string v0, "ۧ۟ۛۗ۟ۛۙۢۦۘۖ۟ۦۘۜۨۖۥۗ۬ۖۛۨۦۡۖ۟ۤۘ۟ۜۘۜ۫ۘۘ۫ۢۛۢۨۘۢ۫ۦۘ۬ۨۧۖۥۚ"

    goto :goto_66

    :sswitch_88
    const-string v0, "ۛۜۨۘۜۚۜۘۚۖۛۢ۠ۡۙۦۧۖ۠ۦ۠ۢ۫ۗ۠ۢ۟ۜۘۤ۠ۥۗۗۖۙ۫۬ۗۛۡۡۘۦۘۙۥۖۘۛۗۨۘۘۡۡ۟ۢۜ"

    goto :goto_58

    :sswitch_8b
    const-string v0, "ۧۥۘۘۨ۫ۨۘۗ۟۟۬ۙۘۡۘۜۥ۠ۗۢۖۛۥۨۢ۬ۖۧۘ۠ۜۨۢۖۚۤۜۘۤۤۙۦۖۜۘۗۧۛۙۨۦۘۘۘ۫ۢۨۜ"

    goto/16 :goto_2

    :sswitch_8f
    new-instance v0, Landroid/content/Intent;

    const-wide v2, -0xd32a1013c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v4, -0xd32aed73c3a53bdL  # -1.0008902023003697E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/16 v1, 0x7b

    invoke-virtual {p0, v0, v1}, Lpubgm/loader/activity/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    const-string v0, "ۦ۫ۛۡۙۦۜۡۧ۫ۨۘۘۘ۬ۘۤۜۘۖۤۨۥۚۧ۠ۘۦۘۖۚۙ۟ۤ۠ۦۛ۬ۡ۠ۜۘ۫ۙ۫۫ۡۙۛ۟ۥۡۚۘۘ۫۠ۛ"

    goto/16 :goto_2

    :sswitch_c8
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->startFloater()V

    const-string v0, "ۘۢۖۘۦۖۢ۫ۢۙۛ۟ۢۨۤۦۘۜۢۘۘۢۗۨۜۥۦۘ۬۬۬ۜۦۜۤ۬ۘۘۚۘ"

    goto/16 :goto_2

    :sswitch_cf
    const-string v0, "ۢ۟ۨۘ۬ۛۜۙۦۤ۠ۡۧۘۧ۠ۧۦۙ۬۫ۛۨۗۗۡۘ۬۬ۙ۫۟ۤ"

    goto/16 :goto_2

    :sswitch_d3
    return-void

    :sswitch_data_d4
    .sparse-switch
        -0x4aa3b44d -> :sswitch_16
        -0x12a8aa1b -> :sswitch_8f
        0xdf67d3e -> :sswitch_c8
        0x27988e75 -> :sswitch_27
        0x45468707 -> :sswitch_53
        0x512b3525 -> :sswitch_19
        0x623813e8 -> :sswitch_d3
    .end sparse-switch

    :sswitch_data_f2
    .sparse-switch
        -0x539ca873 -> :sswitch_2d
        -0x3efa4bc3 -> :sswitch_4d
        -0x2fbc57d5 -> :sswitch_27
        0x55ff1cf0 -> :sswitch_50
    .end sparse-switch

    :sswitch_data_104
    .sparse-switch
        -0x7ec58edf -> :sswitch_41
        -0x5280471c -> :sswitch_2a
        -0x51c3ce7d -> :sswitch_4a
        -0x28ca4ade -> :sswitch_3b
    .end sparse-switch

    :sswitch_data_116
    .sparse-switch
        -0x3d640854 -> :sswitch_61
        -0x38c72916 -> :sswitch_8b
        0x2ddea19a -> :sswitch_88
        0x6a1f1cf3 -> :sswitch_cf
    .end sparse-switch

    :sswitch_data_128
    .sparse-switch
        -0x5b048985 -> :sswitch_6f
        -0x5508f880 -> :sswitch_85
        0x3f3b1953 -> :sswitch_78
        0x42811bd4 -> :sswitch_72
    .end sparse-switch
.end method

.method private stopPatcher()V
    .registers 5

    const-string v0, "ۙۨۗۦۦ۫ۚۦۨۘۥۡۙ۫ۘۧ۠ۘۜۘۚۚۙۡۨۘۥ۫ۢۦۦۧۙۛۦۘۥۤ۠"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x261

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x1a6

    const/16 v2, 0x3cc

    const v3, -0x34221e55  # -2.9082454E7f

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_70

    goto :goto_2

    :sswitch_16
    const-string v0, "۬۬ۡ۠ۛۥۡ۫ۗۨۛۥۦۖۘۖۘۙۡۦۘۘ۟ۜۛۨۖ۬ۥۧۢ۫ۖۧۥۡۜۘۚ۟ۚۨۧۨۦۦۡۘ"

    goto :goto_2

    :sswitch_19
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/FloatingService;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "ۤۧۜۘۙۡۥ۬ۛۚۦۘۘۜۥۚۖۘۥۗۖۗۤۧۛۛ۫۟ۙ۬ۙۚۢۙۥۛ۠۬ۦۜۧۚۙۗ۠ۡ۫ۜ۠۫ۨۖۘ۫۬۬"

    goto :goto_2

    :sswitch_2a
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/Overlay;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "۠ۚۡۘۥۡۗۦۗۡۙۡۘۘۦۙۥ۫ۨۘۖ۠ۤۡۘۨۛۛۙۗۨۚۡ۟ۥۤ۫۬۠۫ۜۤۢۜۘۗۨۧۢ۫۠"

    goto :goto_2

    :sswitch_3b
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/ToggleAim;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "۫ۤۘۘۧ۫ۘ۬ۖۛۥۡۛ۬ۙۖۥۙۤ۟ۚۘۖۦۘ۬ۡۛۛۥۖۦۖۖۜۗ۠ۧۢۨۢ۠ۥۤۘ۟۟ۜۘۨۥۘ۫"

    goto :goto_2

    :sswitch_4c
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/ToggleBullet;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "ۛۗۖ۬ۛۥۘ۫۠ۧۡۧۖۘ۫ۡۛۚۘۘۧۨۨۜۚۘۘۗ۫ۥ۟۬ۢۛ۫ۡۘۦۘۧۗ۟ۜۙ۠ۥۨۢۧۜۦ"

    goto :goto_2

    :sswitch_5d
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/ToggleSimulation;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "ۗ۟ۤۖۤۥۘۡۥ۬ۘۧ۫۠ۦۦۘ۬ۗۛۧۨۧۚۛۡۨۛۙۧ۬ۚۖۗ۬ۗ۟ۡۘ"

    goto :goto_2

    :sswitch_6e
    return-void

    nop

    :sswitch_data_70
    .sparse-switch
        -0x77ddeeeb -> :sswitch_5d
        -0x2f94ba6 -> :sswitch_16
        0x4336f116 -> :sswitch_2a
        0x4581ed10 -> :sswitch_3b
        0x45fad73a -> :sswitch_4c
        0x6870a901 -> :sswitch_19
        0x7bc513da -> :sswitch_6e
    .end sparse-switch
.end method

.method private updateCountdownUI(JJJJ)V
    .registers 18

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const-string v0, "ۛۛ۟ۘۤۥۘ۠ۜ۬ۤ۫ۢۧۧۘۘۙۤۢ۠ۧۜۛۤۨۙۡ۠ۡۤ"

    move-object v1, v0

    :goto_8
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v7, 0x270

    xor-int/2addr v0, v7

    xor-int/lit8 v0, v0, 0x34

    const/16 v7, 0x1c5

    const v8, 0x20126bf4

    xor-int/2addr v0, v7

    xor-int/2addr v0, v8

    sparse-switch v0, :sswitch_data_27a

    goto :goto_8

    :sswitch_1c
    const-string v0, "ۡۛۡۘۚ۫ۨۘۦۜۚۗۛ۠ۙۨۘۙۢ۬۠۫ۘۘۥۡۧۘۤ۠۟۠ۛۙ۫ۢۜ۫۟ۖۦۦۜۘۤ۠۫۬ۘۙۨۤ۬"

    move-object v1, v0

    goto :goto_8

    :sswitch_20
    const-string v0, "ۚۦۧۘۥ۬ۙۤۡۡۤۥ۠ۡۤۤۤۦۖۘۛۧۚۡۜۜۚۤۖۘۚۤۖۢۡۡۘ۠۫۬ۙۜۥۘۥۜۖ"

    move-object v1, v0

    goto :goto_8

    :sswitch_24
    const-string v0, "ۦۨۗۢ۫ۚۖۡ۠ۧ۟ۜۘۧ۟ۖۘ۫۬۟ۛۦۖۤ۠ۥۘۙۧۚۦۙ۟"

    move-object v1, v0

    goto :goto_8

    :sswitch_28
    const-string v0, "ۜ۬ۖۘۢۧۥۘ۬ۜ۬ۦ۬ۜۗۥ۫ۨۘۖۘۦۘۖۙۦۥۘ۬ۧۡۦۡۘۧۨۥۦۘۨۧۜۨۤۤۥۘۘۦۦۘۥۙۗۚۤۖۡۨ۫"

    move-object v1, v0

    goto :goto_8

    :sswitch_2c
    const-string v0, "ۛۜۜۘ۫ۗۥ۠ۦۥۛۗۦۙۧۘۚ۫ۨۘۨۗۥۘۗ۠ۘۦۘ۬ۖۡۛ"

    move-object v1, v0

    goto :goto_8

    :sswitch_30
    sget-object v6, Lpubgm/loader/activity/MainActivity;->instance:Lpubgm/loader/activity/MainActivity;

    const-string v0, "ۚ۟ۨۜۙ۠ۚۢۜۢۦۘۘۥۢۥۘۧۥۚ۬ۖۚۦۜۜۡۧۘۛ۟ۖۘ"

    move-object v1, v0

    goto :goto_8

    :sswitch_36
    const v1, 0x58946a55

    const-string v0, "ۖۤۘۘۛۡۙۡ۟ۘۦ۫ۡۘۘۥۡۘۜ۟ۨۡۦۡۘۥ۟۬۠ۖۛۜۥۦۘ"

    :goto_3b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v1

    sparse-switch v7, :sswitch_data_2d4

    goto :goto_3b

    :sswitch_44
    const v7, 0x5f1621c7

    const-string v0, "ۚۛۢۧۤۦۢۤۜ۬ۧۦۘۜۘۨۗۚۜۡۘۚۘ۬۟ۜۛۙۧۙ۠ۥۡۘ۟ۢۘۘ"

    :goto_49
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_2e6

    goto :goto_49

    :sswitch_52
    const-string v0, "ۨ۟ۧ۫ۘۖۧۚۙۚۛۤۦۥۘۜۘۡۗۘۘۛۚۥ۟ۢۛۤۥۗ۟۟ۖۘ۟ۚۡۘ"

    goto :goto_49

    :sswitch_55
    const-string v0, "۟ۧۧۤۘ۬ۡۙۢۙۛۙۛ۟ۧۡۥۘ۟ۢۚۨۛۖۘۜ۬ۚۢۛۦ"

    goto :goto_3b

    :cond_58
    const-string v0, "ۢۥ۫ۛۤۥۘۘۧۥۦۚۥۤۘۨۘۢۡۡ۫۟۫۠ۦۘۖۦۧ۫ۨۡۘ"

    goto :goto_49

    :sswitch_5b
    if-eqz v6, :cond_58

    const-string v0, "ۧ۬۟۠۬۫۬ۚۚۧۧۢۦۘۙۘۡ۟ۦۘۛۥۥۚۜۛۢۧۨۗۡۛۡۧۨۗۖۤۦ۬ۢۛۖ۫ۧ۫ۧۥۡۘۘۖ۠۠"

    goto :goto_49

    :sswitch_60
    const-string v0, "ۘۙۘۘۚ۬ۥۡۢۦ۠ۦۜۘ۟ۗۤۤۛۨۘۙ۫۠۬ۗۤۧۙۨۘۨۚۥ"

    goto :goto_3b

    :sswitch_63
    const-string v0, "ۖۚ۠ۙۨۖۘۧ۬ۨ۟۬۟ۧۡۜۛۛۘۥۜۘ۫۠ۥۘۖۡۡۘ۠ۘۤ"

    goto :goto_3b

    :sswitch_66
    const-string v0, "ۡ۟ۦۘۖۙۖ۬ۦۢ۫ۥۢۗۖۘۘۥ۟ۢۖۨ۠ۨۙۘۘۢۜۘۚۗۛۡۘ۠ۜ۫ۦۘۖۥۡۢۛ۬ۦۢۖ۬ۚۢۛۜ۟۬ۙ"

    move-object v1, v0

    goto :goto_8

    :sswitch_6a
    const v1, -0x48f12454

    const-string v0, "ۧ۟۠۫۟ۦۘۘۛۚ۠ۗۜۦ۫۫ۜۡۦ۟۫ۜۤۖۢ۟ۛۡ۟۟ۢۗۥۘۖۜۙ۟ۨۘۖۚۘۘ"

    :goto_6f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v1

    sparse-switch v7, :sswitch_data_2f8

    goto :goto_6f

    :sswitch_78
    const-string v0, "ۨۤۥۧۡۤۦۤۙۘۚۛۗۦۘۖۗۨۘ۬ۦۦۘ۠ۗۡۘۗۨۧۗ۫ۛ۠۟ۨۘۤ۫ۦۘ"

    move-object v1, v0

    goto :goto_8

    :sswitch_7c
    const-string v0, "ۤۘۢۡۥۡۘۜۚۛ۠ۜۛۗ۠ۙ۬ۙۨۤۜۘۙۛۗۢ۟۟۟۫ۡۦۖۙۘۧ"

    goto :goto_6f

    :sswitch_7f
    const v7, 0x538545b6

    const-string v0, "ۘ۠ۘۘ۫ۘۨۘۗ۟ۘۘۤۧۗۘۨۥۘۗۚۧ۟ۖۡۙۘۖ۠۟۬ۚۛۤۢۖۛۙ۟ۧ۫ۙۙ۟۠ۘۥۚ۟ۜۙۜۤۤۛۡۦ"

    :goto_84
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_30a

    goto :goto_84

    :sswitch_8d
    const-string v0, "۬ۙۥۢ۫ۙۜۡۡۘۛۤۦ۬ۤۥۘۖۖۖ۬۠۟ۙۥۖۘۙۥۥۘۛۖۖ۫۫ۚۚۖ۟ۥ۬ۙۘۤۗۚۦۛۚۚۢۦۘۖۘ۠ۖ۟"

    goto :goto_6f

    :cond_90
    const-string v0, "ۗ۟ۛۜۡۚ۠ۚۨۘۘ۠ۦۥۙۦ۠ۨۢۚۗۘۘۜۛ۟ۘۨۘۘۗۖۘ۟ۦۡۤۦۖۨ۟ۛۘۗ"

    goto :goto_84

    :sswitch_93
    invoke-virtual {v6}, Lpubgm/loader/activity/MainActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_90

    const-string v0, "۫ۡۘۧۚۜۘۢۡۙ۫ۗۚۨۢۚ۠ۚۘۘ۫ۧۘۘۧۧۘۘ۠ۖۜۙ۬ۦۗۦۤۤۢۥۚۥۥۜۡۜۧۥۨۘۘ۬ۢ"

    goto :goto_84

    :sswitch_9c
    const-string v0, "ۤۦۙۖۛۢۖۢۖ۬۟ۡۨ۬ۥۜۗۢۗۙ۬ۜۨۖۗ۠ۘۨ۬ۥۡۨ۫ۨۛ"

    goto :goto_84

    :sswitch_9f
    const-string v0, "ۘۙۜۚۤۜ۠ۥ۫ۗۡ۬ۢۢۙ۬ۖۙۢۘۘۤ۫ۨۖۥۥۘ۟۟ۢۙۛ۠ۙۖۧۘۛۙۘۘۥۡۗ"

    goto :goto_6f

    :sswitch_a2
    const v1, 0x89d638

    const-string v0, "ۥۗۨۜۘۚۘۥۘۛ۟ۥۡۗ۠ۦۡۨۘ۫۠ۘ۫ۨۜۘۙۙۥۘۤۥۛۘۥ۟۬۫۬۠ۗۢۨۦۡۘۦۗۖۘۨۨۧۛۧۜۘۧۚۥ"

    :goto_a7
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v1

    sparse-switch v7, :sswitch_data_31c

    goto :goto_a7

    :sswitch_b0
    const-string v0, "ۧۧۙۢۗۘۘۜۥۘۘۦۜۚۙ۫ۦۘ۫۬ۦۧۖ۠ۗۡ۫۠۬ۗۗۜۡۘۧۚۙۤ۫۬ۗۧۧۛۢۦۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_b5
    const-string v0, "۬۬ۡۦۛۦۘۡۥۜ۬۟ۦۛ۠۫۠ۗۡۘۛۡ۠ۤۥۡۙۦۘۖۜۛ"

    goto :goto_a7

    :sswitch_b8
    const v7, 0x4e105e62  # 6.0552614E8f

    const-string v0, "ۙ۫ۦۨۜۨۘۧۧ۟ۤ۟ۚۚۚۛۢۙۜ۫ۨۦۚۖۙۖۛۘۘۢۘۗۡۨۜۘۦۨۜۜۘۡۘ۬۠ۜۘۛۡۗۡۙۦۘ"

    :goto_bd
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_32e

    goto :goto_bd

    :sswitch_c6
    sget-object v0, Lpubgm/loader/activity/MainActivity;->instance:Lpubgm/loader/activity/MainActivity;

    invoke-virtual {v0}, Lpubgm/loader/activity/MainActivity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_d1

    const-string v0, "ۦۖۡۘۧۛۡۘۖۦۙ۠ۙۤۜۚۤ۠ۥۗۥ۫ۚۤۙۚ۫ۧۤۧۘۛۜۚۜۗۖ۫ۚۛ۫ۥۚۥ۟ۨۘۡ۠ۖ"

    goto :goto_bd

    :cond_d1
    const-string v0, "ۛۖۛۗۥۗ۟ۛۥۜ۟ۜۘۙ۬۟ۙۥۦۛۦۢۛۦۘۦ۠ۤۙ۫ۧ۟ۚ۠۫ۢۜۚۙۥۘ۠ۛ"

    goto :goto_bd

    :sswitch_d4
    const-string v0, "۬ۚۡۧ۬ۘۘ۫ۗۗۥ۟ۥۘ۬ۗۨۘۤۥۙ۠ۗۘۛۚ۬ۧۨۘۗۗۙ"

    goto :goto_bd

    :sswitch_d7
    const-string v0, "ۙ۬ۙۗۚۧۨ۠ۨۘۦۨۗۜۨ۠ۨۖۜۘۘۨۨۘ۟ۥۦۛ۟ۢۤۡۧۘ"

    goto :goto_a7

    :sswitch_da
    const-string v0, "۟۟ۜۘۙ۫۬ۦۛ۟ۗۤ۟ۦۜ۠۬۠ۘ۬ۤۜۥۖۘۖۨۚۢ۟ۖۘ۬ۚۖۘۤۜۥۤۧ۟ۡۡۖۥۘ۠ۘ۬۠"

    goto :goto_a7

    :sswitch_dd
    const v0, 0x7f090133

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "۠ۢۖۘۛ۬ۖۨۚ۫ۨۛۥۘۚ۫۠ۦۦۗۗۤۢ۬ۙۖۘۢۚ۫۠۟۬ۤۖ۠ۜۜۨۧۡۛ۟ۛۡۤۥۘۘۗۨۘۘ۫۠ۥ۫ۗۤ"

    move-object v5, v0

    goto/16 :goto_8

    :sswitch_eb
    const v0, 0x7f0901b6

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "ۦ۟۫۠۫ۦۘ۟ۢۜ۬ۥۙۙ۠ۨۢ۟ۙۖ۟ۨۘۡۜۧۘۗۦۧۤۙۥۘۜۙۨۘۦ۠ۖۘۢ۟۠۫ۡۢۡ۫۬۠ۦۡۘ"

    move-object v4, v0

    goto/16 :goto_8

    :sswitch_f9
    const v0, 0x7f09023b

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "ۘۙ۟ۜۡۧۜۤۨۘۧۙۧۗۗۨۘۙۙۜۘۖۧ۟ۤۜۡۛۗ۬ۜۤۧۚۧۨۘۛۘۡۘۛۜۘ۫ۧۥۡ۬ۦۘۥۛۡۘ"

    move-object v3, v0

    goto/16 :goto_8

    :sswitch_107
    const v0, 0x7f0902e5

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "ۤ۟ۨۘۥۡۥۘۛ۟ۧ۠ۚ۬ۜۢۡۦۛۘۘۥۙۢ۬ۘۢۜۥۦۘۧۨۗ۟۬ۡۤۡ۫ۨۤۙۡۖۘ"

    move-object v2, v0

    goto/16 :goto_8

    :sswitch_115
    const v1, 0x6387fff

    const-string v0, "ۙۡۛۜۦۜۘۥۧۖۤۢۘۘۛۡۖۡۙۛۛ۟ۤ۟ۖۧۘۙ۫ۘۨۨ۠۫ۨۛۥ۠ۧۨ۠ۚۦۧۗ۟ۜۤ۟ۨۨۘ۠۟ۖۘ"

    :goto_11a
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v1

    sparse-switch v7, :sswitch_data_340

    goto :goto_11a

    :sswitch_123
    const-string v0, "ۖ۬ۡۘ۫۬ۖۘۖۦۛۦۘۨۘۘۢۡۘۢۗۜۘۡ۠ۥۘۨۧۤۜۙۨۥۤۘۨۚۙ۫۟۟ۛۤۛۢۧ۠ۦۚۛۗۡ"

    goto :goto_11a

    :sswitch_126
    const-string v0, "ۦۘۧۘۢۗۗۚۖۦۘۨۘۢ۬ۥۢۜۢ۟ۜۡۚۘ۟ۨۘۗۙۜۘۜ۟ۤۡۖۜۘۢۢۨۘۗۙۨۚۧۨۘ"

    goto :goto_11a

    :sswitch_129
    const v7, -0x22564c83

    const-string v0, "ۨۚۜۘۙۨۖۘ۟ۦۥۘۧۦۥۖۜۡۘۙ۠ۡۢۙ۬ۜۗۜۘۜۢۤۖ۟۫ۜۢۦ۠ۧۥۚۤ۬ۢۚۤۛۤۦ۫۬"

    :goto_12e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_352

    goto :goto_12e

    :sswitch_137
    const-string v0, "ۜۧۧۦۘۖۗ۟ۦۜۚۢۨۗۖۘۜۜۧۢ۬۟ۧۥۖۘۙۨۧۚۦۥۘ"

    goto :goto_11a

    :cond_13a
    const-string v0, "۠ۡۗۜۧۙۦۥۧۡ۫ۡۘۤ۟ۧۚ۫ۙۗۜۧۡۦ۠ۘۘ۬ۤۡۦۙۚۧۘ۟ۗۗۥۢۡ۫ۘۘۦ۠ۖۘ۠ۦ۬"

    goto :goto_12e

    :sswitch_13d
    if-eqz v5, :cond_13a

    const-string v0, "ۚۢۥۘۧ۫۫۫ۢۖۘۘۙۛۗ۠ۦ۬ۧۛ۬ۨۡ۟۫ۗۦۧۖۘ۫ۖ۬ۚ۬ۤۛۛۡۦۖۜۘۛ۬ۜ"

    goto :goto_12e

    :sswitch_142
    const-string v0, "ۦ۬ۨۘ۟ۢۗۖ۟۠ۗۦۖۨۡۤۢۤۤۗۜ۠ۢۘۧۘۧۧۘۘۢۛۚ"

    goto :goto_12e

    :sswitch_145
    const-string v0, "۠ۛۘۘ۫ۗۥۘۖۜۘۘ۠ۛۜۚۘۨۘۡۛۢۗۙۘۚۘۜۧۛۧۢۛۘۡۘۘۢۨ۬ۦ۬ۜۢۜۤۗۤۘۘۖۘۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_14a
    const-wide v0, -0xd32ae3e3c3a53bdL  # -1.0009699059103877E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    aput-object v8, v1, v7

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "۟ۛۖۘ۬ۜۦۜۚۦۘ۠۫ۥۖ۫ۤۨ۬ۗۛۜ۠ۨۨ۠ۚ۟ۦۘۚۖۥۘ۬ۥۨۘۦۢۡۜ۠ۧۨۤۦۜۥۦۘۥۘۘ۬ۗۚۚۙ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_169
    const v1, -0x654687ba

    const-string v0, "ۖۢۡۨۖۙۢۨۤۡۘۖۘۡ۫ۛۧۧ۬ۢۡۥ۟۫ۡ۟۟ۤۦۖۛۗۦۥ۫۫ۗۚ۬ۧۛۚۡۘ"

    :goto_16e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v1

    sparse-switch v7, :sswitch_data_364

    goto :goto_16e

    :sswitch_177
    const v7, 0xae6ba44

    const-string v0, "ۡ۠ۘ۠ۨۘۘۥۛۗۧۖ۬۬۟ۨۘۧۨۡۘۧ۫۫ۡۗۦۜۢۘۧۢ۠ۧ۟ۤ"

    :goto_17c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_376

    goto :goto_17c

    :sswitch_185
    const-string v0, "ۘۧۙ۟ۛۘۡۖۖۘۤ۬ۨۗۚۖۘۗۤۢۢۘۘۦۗۡۢۧۥ۟ۗۗۨۧۧۥ۠ۙ"

    goto :goto_17c

    :sswitch_188
    const-string v0, "ۗ۫ۡۜۙۗۘۤۜۗۗۦۛۚۛۙۦۦۚۢ۟ۘۘ۠ۤۜۢۨۦ"

    goto :goto_16e

    :cond_18b
    const-string v0, "ۘۜۚۥۦ۫ۨۜۦۦۖۧ۠۟۫ۜۥۚۛۘۘ۫ۥۗۢۦ۟۠۫۠ۥۚۡۛۗۨۤۙۨۘۘۗۡ"

    goto :goto_17c

    :sswitch_18e
    if-eqz v4, :cond_18b

    const-string v0, "ۗۗۨۨۧ۠ۤۡۡۦ۫ۗۥۢۦۘۦۤۚۖۤۢۢ۟ۥۘۤ۫ۥۘۦۜۨۘ۫ۖۘۘۙۛۢۨ۬ۘۜۥۘۘ۫ۧۥۢ۬ۥ"

    goto :goto_17c

    :sswitch_193
    const-string v0, "ۧ۟ۡ۠ۦۦۨۡۘۘۛ۟ۥۘۤۚۥ۬ۤۦۘۢۨۥۥۢۘۘۢۘۢ۠۬ۧۗۛۦۙۙۡۘۦ۠ۜ۬ۦۘۙۙۛ۠ۡۘۘۘۜۦۜۚۖ"

    goto :goto_16e

    :sswitch_196
    const-string v0, "ۤۚ۠ۖۧۧۨۘۗۢۛ۠ۤۚۡۚ۬ۖۚ۟ۜۙۘ۟ۧۘۗۨ۟ۢۚ۬ۤۚۘۨۚ۫۬۠ۤۚۜۜ۫ۡۘۥۘۚۙۘ"

    goto :goto_16e

    :sswitch_199
    const-string v0, "ۢۜۧۘۨۗۥۘ۠ۗۧۨۨۦۘۡۜ۠ۚ۠ۡۘۡ۟۬ۙۨۜۖۖۙۤۜ۟ۥۢۥۘ۫ۧ۠۟ۗۥۘ۟ۚۡۡۘۨۗۘۢ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_19e
    const-wide v0, -0xd32ae213c3a53bdL  # -1.0009850131305872E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    aput-object v8, v1, v7

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۧ۬ۘۦۖ۫ۡ۠ۡۘۨ۬ۗ۬ۚۦۗۥۦۤۛۘۚۖۡۚۖۤۡۖۖ۬ۘۡۘۛ۠ۜۘ۠ۚۗۦۚ۟۫ۧۤ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_1bd
    const v1, 0x32b2ef9c

    const-string v0, "۟ۗۦۘۘۢۢۙ۠ۥۛۥۘۗۛۦۘۢۤۗۜۧۜ۬۬ۘۚۛۜۛۖۛ"

    :goto_1c2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v1

    sparse-switch v7, :sswitch_data_388

    goto :goto_1c2

    :sswitch_1cb
    const-string v0, "ۚۗۧۡۖۢ۬ۜۘ۟ۚۡۗ۬۬۫ۛۡۧۢۤۗۜۙۥۡۗۖۨۤۧۨۘ۫ۘۨ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_1d0
    const-string v0, "ۖۛۤۢۧۜۘ۫ۛۛ۬ۗۥۘۥۚۨ۠ۥۨۘۢۧۜۘ۠ۗۡ۟ۧۨۤۛ۟"

    goto :goto_1c2

    :sswitch_1d3
    const v7, 0x618e5c6c

    const-string v0, "ۨۨۡ۫ۦۧ۬۬ۘۘۦۢۜۛۦ۠ۦۨ۫ۙ۠۫ۡ۫ۛۨ۬ۨۘۥۡ۠"

    :goto_1d8
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_39a

    goto :goto_1d8

    :sswitch_1e1
    if-eqz v3, :cond_1e6

    const-string v0, "ۦۢۨۥۛۜ۫ۥۘۧۚۖۘۛۤۙۜۙۙۡۡۜۥۛۡۦ۫ۤۤۚۗۦ۟ۢۜۖۧۡۨۧۖ۫ۨۘ"

    goto :goto_1d8

    :cond_1e6
    const-string v0, "ۥۖۦۘ۬ۥۘۧۨۥۙۛۜۧۦۦ۬ۥۙۜۦۦ۬ۙۥۘۧۛۚۤۙۘ"

    goto :goto_1d8

    :sswitch_1e9
    const-string v0, "ۥۧۗۨ۫ۨۘۧۗۡۘۜۤۖۗ۬ۜ۫۫ۧۜۥۥۖ۠ۖۦۡ۠ۛ۟ۙۧ۫ۡۥۖۚۥۛۧۦۡۜۘ"

    goto :goto_1d8

    :sswitch_1ec
    const-string v0, "۠۠۬۬ۗۙ۫ۤۦۘۛۘ۠ۡۨۘ۠ۤ۫ۛۡ۫۬ۘ۟۠ۢۨۘۧۗۨ۬ۡ۟ۤۦۨۗۛۧۜۙ۫ۜ۫ۢۚۚۦۘ"

    goto :goto_1c2

    :sswitch_1ef
    const-string v0, "۫۫ۙۛۤۙۧۚۨۧۜۘۘۖ۠۟ۧ۠ۖۙۖۨۘۧ۫ۖۡۤۛۢۥۜۘۡۘۧۘ۫ۙۖۘ۠۟ۥۘۛۤۧ"

    goto :goto_1c2

    :sswitch_1f2
    const-wide v0, -0xd32ae243c3a53bdL  # -1.0009834503147045E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-static {p5, p6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    aput-object v8, v1, v7

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۧۦۨۤ۟ۧۢ۬ۚۤ۫ۥۘۧۨۧۘۧ۬ۨۘۧۦۨۘ۫ۚۡۤۜۢۘۛۛۤۤۘۚۢۤۡۦۘۨۖ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_211
    const v1, -0x717a88c2

    const-string v0, "ۥۥۡۜ۫ۦۗۡۤۗۨۗۨۘۡۧۦۘۥۥۚۙ۠ۨۡ۬ۜۥۚۖۢ۬۫ۤۤۨۘۤۙۥۘۖۤ۠ۛۧ۠ۨ۬ۡ"

    :goto_216
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v1

    sparse-switch v7, :sswitch_data_3ac

    goto :goto_216

    :sswitch_21f
    const-string v0, "ۨۖ۫۫۬ۤۜۛۘۜۙۦۚۖۘۘۥۨۢۜۛۖۘۖ۬ۛۜۛۡۘۦۗۢۡ۠ۨۘ۬ۤۖ۫ۖۡۤۡۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_224
    const-string v0, "ۛۡۨۘۚ۟ۘۘۜۤۘۢۛ۟۫ۢۨۘۥۖۧۤۖۦۦ۬ۥۘ۠ۢۧۢۥۨۘۥۚۖۘ۟ۘ۠۫ۚ۬۬ۚۙ۟ۥ۟ۜ۫ۡۜۚ۠۠ۤۡۘ"

    goto :goto_216

    :sswitch_227
    const v7, -0x73759599

    const-string v0, "ۧ۟ۨۘۘۖۥۘۡۛۡۘۡۙۨۘ۬ۙۙۢۦ۬ۨۧۜۦۙۨۘۛۘۧۘ۬ۢۙۙۦۛۢۗۤۖۗ۠ۧۜ۟ۨ۠ۥۜۗۚۨۢۛ۠۟۬"

    :goto_22c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v8

    xor-int/2addr v8, v7

    sparse-switch v8, :sswitch_data_3be

    goto :goto_22c

    :sswitch_235
    const-string v0, "ۜۜۤۖ۟۠ۚۡۨۘۢ۫ۧۙ۟ۘۜۜۡۘۧۧ۫ۥۚۦۖۢۛۗۜ۠۫ۤ۬ۨۧۨۗۖۚۚۘۘ"

    goto :goto_216

    :cond_238
    const-string v0, "۬ۙۡۚ۟ۘۙۚۙۦۤۜۘۚۡۤ۠ۧۜۗۜۜۦۚۖۘۘۜ۠ۥۘۛۤۜۘ۠ۛۗۢۙۚۧۨۨۘۡۦۧۘ۬ۜۥۖۙۢۤۛ"

    goto :goto_22c

    :sswitch_23b
    if-eqz v2, :cond_238

    const-string v0, "ۘۖۥۘ۫ۖۥۢۥۘۘ۫ۤ۟ۚۦۖۘۡ۫ۘ۫ۧۖۤۗۦۘۗۧۧۚۜۘۘ"

    goto :goto_22c

    :sswitch_240
    const-string v0, "ۦۧۘۖۨۨۖۘۘۘۛۡۦۘ۫ۗۥ۬ۥۦۘۘۜۚۛۨۘۘۧ۟ۤۧۚۜۘۙۗۗۙۥ۟۬ۖۖۘ۫ۧ۬"

    goto :goto_22c

    :sswitch_243
    const-string v0, "ۡۚۗ۠ۖۨۤۤۚۗۘۜۡۥۡ۬ۜۡ۬ۖۡۥۢۙۧۤۚۚۚ۠ۗۦۤۛۦۘ۠ۗ۫ۚ۟ۡۘۨۛ۠۬ۛۦۘ"

    goto :goto_216

    :sswitch_246
    const-wide v0, -0xd32ae2f3c3a53bdL  # -1.0009777199898013E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-static/range {p7 .. p8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    aput-object v8, v1, v7

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۡۤ۠۟۫۫ۧۜ۬ۚۡۡۘ۬۟ۖۙۗۥۘۨ۠۟ۥ۠۫۫ۥۜ۬۟ۚۖۤ۠ۥۙۘۘ۠۠ۙۘ۟ۢۧۜۘۖۚۡۘۗۘۥ۬ۜۡۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_265
    const-string v0, "۟ۛۖۘ۬ۜۦۜۚۦۘ۠۫ۥۖ۫ۤۨ۬ۗۛۜ۠ۨۨ۠ۚ۟ۦۘۚۖۥۘ۬ۥۨۘۦۢۡۜ۠ۧۨۤۦۜۥۦۘۥۘۘ۬ۗۚۚۙ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_26a
    const-string v0, "ۧ۬ۘۦۖ۫ۡ۠ۡۘۨ۬ۗ۬ۚۦۗۥۦۤۛۘۚۖۡۚۖۤۡۖۖ۬ۘۡۘۛ۠ۜۘ۠ۚۗۦۚ۟۫ۧۤ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_26f
    const-string v0, "ۧۦۨۤ۟ۧۢ۬ۚۤ۫ۥۘۧۨۧۘۧ۬ۨۘۧۦۨۘ۫ۚۡۤۜۢۘۛۛۤۤۘۚۢۤۡۦۘۨۖ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_274
    const-string v0, "ۡۤ۠۟۫۫ۧۜ۬ۚۡۡۘ۬۟ۖۙۗۥۘۨ۠۟ۥ۠۫۫ۥۜ۬۟ۚۖۤ۠ۥۙۘۘ۠۠ۙۘ۟ۢۧۜۘۖۚۡۘۗۘۥ۬ۜۡۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_279
    return-void

    :sswitch_data_27a
    .sparse-switch
        -0x709854ea -> :sswitch_1c
        -0x6e2e81ca -> :sswitch_28
        -0x559c6925 -> :sswitch_dd
        -0x49862247 -> :sswitch_115
        -0x4457386a -> :sswitch_f9
        -0x3f631d8d -> :sswitch_279
        -0x283cb5d6 -> :sswitch_30
        -0x199f1265 -> :sswitch_a2
        -0xebea48c -> :sswitch_1f2
        -0x8f610fe -> :sswitch_2c
        -0x374e13b -> :sswitch_246
        0x21999b69 -> :sswitch_107
        0x30c5c2bf -> :sswitch_169
        0x3816084a -> :sswitch_6a
        0x3fcf5391 -> :sswitch_1bd
        0x49777764 -> :sswitch_19e
        0x49b44797 -> :sswitch_20
        0x62c7653b -> :sswitch_36
        0x6327aba3 -> :sswitch_24
        0x6f6e912f -> :sswitch_211
        0x74db4336 -> :sswitch_14a
        0x7529fa25 -> :sswitch_eb
    .end sparse-switch

    :sswitch_data_2d4
    .sparse-switch
        -0x6dcc5e23 -> :sswitch_63
        -0x62f2f81a -> :sswitch_66
        0x19fe898d -> :sswitch_274
        0x2689576f -> :sswitch_44
    .end sparse-switch

    :sswitch_data_2e6
    .sparse-switch
        -0x2e69b49c -> :sswitch_60
        0x1ed4cbd1 -> :sswitch_52
        0x3f85f650 -> :sswitch_5b
        0x57f60536 -> :sswitch_55
    .end sparse-switch

    :sswitch_data_2f8
    .sparse-switch
        -0x72a50026 -> :sswitch_7f
        -0x6e294aca -> :sswitch_274
        -0x22b50d69 -> :sswitch_9f
        0x581ce0e5 -> :sswitch_78
    .end sparse-switch

    :sswitch_data_30a
    .sparse-switch
        -0x477820e1 -> :sswitch_7c
        -0x1fa4ee3b -> :sswitch_9c
        0x764115e -> :sswitch_93
        0x582bc5a3 -> :sswitch_8d
    .end sparse-switch

    :sswitch_data_31c
    .sparse-switch
        -0xf68a67f -> :sswitch_b8
        0x11ad264a -> :sswitch_b0
        0x16a7e8e3 -> :sswitch_da
        0x60142519 -> :sswitch_274
    .end sparse-switch

    :sswitch_data_32e
    .sparse-switch
        -0x72dd49b7 -> :sswitch_d7
        -0x21f04887 -> :sswitch_b5
        0x862e765 -> :sswitch_c6
        0x72fb400d -> :sswitch_d4
    .end sparse-switch

    :sswitch_data_340
    .sparse-switch
        -0x6e8cac2a -> :sswitch_129
        -0x3461da37 -> :sswitch_265
        0x2bfcda15 -> :sswitch_123
        0x55c08b2d -> :sswitch_145
    .end sparse-switch

    :sswitch_data_352
    .sparse-switch
        -0x5aea9475 -> :sswitch_13d
        -0x1ccf98d3 -> :sswitch_142
        0x14c0a424 -> :sswitch_126
        0x240e4ab9 -> :sswitch_137
    .end sparse-switch

    :sswitch_data_364
    .sparse-switch
        -0x196408d0 -> :sswitch_196
        -0x10b2282 -> :sswitch_177
        0x1c01d0c -> :sswitch_199
        0x18f87eb9 -> :sswitch_26a
    .end sparse-switch

    :sswitch_data_376
    .sparse-switch
        -0x3ff2ace4 -> :sswitch_185
        -0x2964ced9 -> :sswitch_188
        0x6a0e35bc -> :sswitch_18e
        0x71a18b98 -> :sswitch_193
    .end sparse-switch

    :sswitch_data_388
    .sparse-switch
        -0x68a88585 -> :sswitch_1cb
        -0x5780ae52 -> :sswitch_1ef
        0x48b9a08e -> :sswitch_26f
        0x618d1ab1 -> :sswitch_1d3
    .end sparse-switch

    :sswitch_data_39a
    .sparse-switch
        -0x5f0e4bea -> :sswitch_1e1
        -0x1123f92f -> :sswitch_1ec
        0x4e7afe22 -> :sswitch_1d0
        0x62b05307 -> :sswitch_1e9
    .end sparse-switch

    :sswitch_data_3ac
    .sparse-switch
        -0x2acb078f -> :sswitch_274
        -0x1152cec3 -> :sswitch_227
        0x267d1fd9 -> :sswitch_21f
        0x2cabf0e2 -> :sswitch_243
    .end sparse-switch

    :sswitch_data_3be
    .sparse-switch
        -0x75618f9a -> :sswitch_224
        -0x6a379e19 -> :sswitch_240
        0x3d667caa -> :sswitch_23b
        0x76d68940 -> :sswitch_235
    .end sparse-switch
.end method


# virtual methods
.method public Exec(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v2, -0xd32a19c3c3a53bdL  # -1.002654621431945E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lpubgm/loader/activity/MainActivity;->ExecuteElf(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v2, -0xd32a1733c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lpubgm/loader/activity/MainActivity;->ExecuteElf(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v2, -0xd32a1743c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lpubgm/loader/activity/MainActivity;->ExecuteElf(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lpubgm/loader/activity/MainActivity;->ExecuteElf(Ljava/lang/String;)V

    const v0, 0x7f0700e4

    invoke-static {v0, p2}, Lpubgm/loader/activity/MainActivity;->toastImage(ILjava/lang/CharSequence;)V
    :try_end_8d
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8d} :catch_8e

    :goto_8d
    return-void

    :catch_8e
    move-exception v0

    goto :goto_8d
.end method

.method StartCountDown(Landroid/widget/TextView;)V
    .registers 6

    const-string v0, "۬۠ۚۛۤ۠ۧۛۤۘۡۜۙۜۗۡۙۦۚۖۘۘۚ۫ۚۧۜۜۦۧۘۢۨۥۚۥۧۦۘۤ۫ۛۗۜ۫۬ۗ۟ۡ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x1a7

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x3b9

    const/16 v2, 0x335

    const v3, -0x131db7e6

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_3c

    goto :goto_2

    :sswitch_16
    const-string v0, "ۖۢۚۙۙ۠ۜ۟ۙۦۘۨ۠ۖۚۘۦۘۛۘ۠ۚۦ۠ۖۗ۠ۜۥۖۘۢۥۥۛۧ۫ۦۡۡۘۙۢۘ"

    goto :goto_2

    :sswitch_19
    const-string v0, "۫ۨۢۙ۬ۡ۬ۜۙۥۢ۫۫ۗۡۤ۠ۖۦۘۦۗۤۗۛۨۚۗ"

    goto :goto_2

    :sswitch_1c
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lpubgm/loader/activity/MainActivity$5;

    invoke-direct {v1, p0, p1}, Lpubgm/loader/activity/MainActivity$5;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/TextView;)V

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const-string v0, "۬ۘۦ۠ۗ۬ۨۘۡۤۛۜۘۙ۠ۗۛۥۚۡۗۚۡ۬ۘۥ۬ۡۘ۬ۖۧۗۦۜۘۥ۟ۧ۬ۢۦ۬ۨۡۖ۬ۡۜ۬ۘ"

    goto :goto_2

    :sswitch_2e
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->handler2:Landroid/os/Handler;

    iget-object v1, p0, Lpubgm/loader/activity/MainActivity;->runnable:Ljava/lang/Runnable;

    const-wide/16 v2, 0x1770

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;J)Z

    const-string v0, "۠ۥۡۘۙۚ۠ۛ۠ۖۘۖۤ۟ۢۖۧۘۢۡۗۗۙ۫ۛ۟ۤۗۤۖۛۢۧ۟ۨۘۧۙۖۘ۠ۢۗۙۙۚۨۡۡۘۘۧۚ"

    goto :goto_2

    :sswitch_3a
    return-void

    nop

    :sswitch_data_3c
    .sparse-switch
        -0x3347fc04 -> :sswitch_3a
        -0x1df48232 -> :sswitch_19
        0x55268636 -> :sswitch_2e
        0x6e19d2cc -> :sswitch_16
        0x7aad7262 -> :sswitch_1c
    .end sparse-switch
.end method

.method public addAdditionalApp(ZLjava/lang/String;)V
    .registers 7

    const-string v0, "۠ۡ۠ۛ۠ۡۛ۟ۙۙۨۖۘ۫۟ۡ۬۠ۨۘۦۛۜۘۖۢ۬ۧۨۨۛۢۡۘ۟ۧۚۨۤۧۚۖۦۘ۠ۜۖۘۧۘۚۜۛۚ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x388

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x258

    const/16 v2, 0x374

    const v3, -0x6dc2bb62

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_34

    goto :goto_2

    :sswitch_16
    const-string v0, "ۢ۠ۥۘۘۚۨۗ۠ۜۘ۠ۙۢۤۜۥۘۜۛۖ۟ۢ۫ۖۤۥۘۤۗۦۘۦۖۙۤۖۧۜۚ۠ۖۙۙۡۜ۟"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۚۤ۬ۛۙۧۛۥۡۘۢۨۦۘۚۜۦۦۘ۫۫ۖۛۡۦۘۗۖۨ۟ۧۡۡۗۙ۫۟۟ۤۖۜۘۖۧۥۘ۫۫ۤۙۚۘ"

    goto :goto_2

    :sswitch_1c
    const-string v0, "ۚ۠ۤۛۢۡۘۚۘۧۤۨۜۥۢۥۘۘۦۖۜۙۢۛۙۡۦ۟ۘۘۛ۟ۚ۟ۘۧۘۦۡۨۘ"

    goto :goto_2

    :sswitch_1f
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lpubgm/loader/activity/MainActivity$6;

    invoke-direct {v1, p0, p2}, Lpubgm/loader/activity/MainActivity$6;-><init>(Lpubgm/loader/activity/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const-string v0, "ۨۨۧۡۙۦۘۢ۫ۥۘۤۜ۫ۡ۟ۛۚۚ۠۫ۘۘۨۨ۠۬ۦۘۤۗ۬ۜۢۡ۠ۗ۟ۤۚۡۗۗۧۛ۠ۥۜۛۗۦۧۖۗۘۤ"

    goto :goto_2

    :sswitch_33
    return-void

    :sswitch_data_34
    .sparse-switch
        -0x36248ace -> :sswitch_33
        -0xe8ccbb7 -> :sswitch_19
        -0x9564851 -> :sswitch_16
        0xd4e43ef -> :sswitch_1c
        0x1604771d -> :sswitch_1f
    .end sparse-switch
.end method

.method public devicecheck()V
    .registers 10

    const/16 v8, 0x8

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x0

    const-string v0, "ۦۗۦ۟ۙۥۘۦۚ۫۠۫ۦۜۧۘۘۧۧۚۗۤۢۦ۬ۘ۟۫ۦۦۧۨۘۦ۫ۘۜۦۧۧۘۡۜۗۥۘۙۤۥۖۜۡۡۢۦۘۥۦۡ"

    move-object v1, v0

    :goto_8
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v3, 0x1bc

    xor-int/2addr v0, v3

    xor-int/lit16 v0, v0, 0x1ca

    const/16 v3, 0x24a

    const v4, -0x29031de0

    xor-int/2addr v0, v3

    xor-int/2addr v0, v4

    sparse-switch v0, :sswitch_data_168

    goto :goto_8

    :sswitch_1c
    const-string v0, "ۛۨۦۘۧۘۨۗ۟ۗ۫ۙۘۦۤۦ۠ۘۡۢ۫ۖۚۤۤۡۗ۬۫ۡۧۘۦۚۥۘۘ۠ۛۥۢۜۘۜۛ۟"

    move-object v1, v0

    goto :goto_8

    :sswitch_20
    const v0, 0x7f090371

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lpubgm/loader/activity/MainActivity;->root:Landroid/widget/TextView;

    const-string v0, "ۗۚۧۜۢۘۢۜۦ۬ۗۨۘ۬ۛۛۚۥۘۚۢ۬۠ۧ۫ۗۘۖۘ۠ۢ۟ۦۥۢۗۤۡۘۚۚ۫ۨ۫ۜۘۗۙۤۥۘۙ"

    move-object v1, v0

    goto :goto_8

    :sswitch_2f
    const v0, 0x7f090122

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lpubgm/loader/activity/MainActivity;->container:Landroid/widget/LinearLayout;

    const-string v0, "ۗ۫ۦۚۦۨۜۧۥ۟ۧۘۢۚۥۘۢۢۘۛۙۧۖۨۙۖۘ۬ۜ۠ۛ۫ۚۤۖۘۨۛۛ۟ۥۤۦۢ۟ۥ۬ۡۜۡۥۘۥۘ"

    move-object v1, v0

    goto :goto_8

    :sswitch_3e
    const v0, 0x7f09022e

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    const-string v1, "ۡ۫ۥۘۙۙۢۚۘۡۦۥۖۘۜۜۘۤۜۙۦۜ۫ۨ۬ۤۖۥۘۡۗۖ"

    move-object v2, v0

    goto :goto_8

    :sswitch_4b
    const v1, -0x4c625c96

    const-string v0, "ۢۖۘۘۤۛۧ۟ۙ۬ۦۡۚۡۛ۟ۚۢۨۚۡۤۡۗۛۢۖ۫۠ۡۖۘۖۛۨۘۡۧۚ"

    :goto_50
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v1

    sparse-switch v3, :sswitch_data_1c6

    goto :goto_50

    :sswitch_59
    const-string v0, "ۢۖۦۘۧ۟ۖۤۡۗۦۦۘ۠۠ۥۙۡۜۡ۟ۨۨۦ۫۬ۖ۟۫ۚۦۖۘۨۛۦۥۘۖۘۦۛۚۛۢۢ۟ۥ"

    goto :goto_50

    :sswitch_5c
    const-string v0, "ۧۜۥۡۤۡۖۧۘۦۡۢۥۥۡۧۧۜ۠ۦۡۜ۠ۥۤۦۧۘۚۡۦۘ۟۟ۖۘ۠۬ۧۚۙۤ۬ۗۘ"

    goto :goto_50

    :sswitch_5f
    const v3, 0x5cc1a2d5

    const-string v0, "ۗ۫ۤۖۜۗۡۘۡۛۛ۟ۛۜۗۤ۫ۙ۫ۜۧۘ۠۫ۛۘ۬۬ۙ۫ۛۨ۬ۚۘۨۚۗۥۜ۟ۨۡۘۦۜۖۘۢ۟"

    :goto_64
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_1d8

    goto :goto_64

    :sswitch_6d
    const-string v0, "ۜۚۛۨۖ۠۫ۚۖۙۚۥۘ۠۟ۚۜۛۡۦۧۥۘۢۥۘۚۙ۬۠ۘۘ۠ۗ۬ۜۦۗۧۨۥۥۜۘ"

    goto :goto_50

    :cond_70
    const-string v0, "ۚ۟ۛۖۙ۠ۨۘۡۥۗ۬ۤۗۧ۟ۨۘۜۡۤۖۡۗۡۡۙۨۧۜۚۖۜۘۚۛ۠ۦۨۤۦۖۘ"

    goto :goto_64

    :sswitch_73
    invoke-static {}, Lcom/topjohnwu/superuser/Shell;->rootAccess()Z

    move-result v0

    if-eqz v0, :cond_70

    const-string v0, "ۗۢۘۙۘۦ۠ۡۜۚۙۥۘۘۖۖۘۚۤۤۛ۬ۖۛۦۛۦۘۚۤۤۜۤۜۘۥۨۦۘۢۘ۫ۜ"

    goto :goto_64

    :sswitch_7c
    const-string v0, "۠ۨ۬ۙ۫ۥۘۡۜ۫۟ۦۜۥۙۚ۫ۥۥۘۢۡۧۘۙۢۚ۫۠ۖۘۢۙۦۘۚۤۨۘۚۥۙ"

    goto :goto_64

    :sswitch_7f
    const-string v0, "ۘ۟۠ۚۧۖۚۢۡ۬۫۬ۘ۟ۘ۠ۜۘۘ۟ۡۖۘۤۖۧۛۨۘۚۡۦۙۛۗۖۤۗۥۙۘۡۚ"

    move-object v1, v0

    goto :goto_8

    :sswitch_83
    const-wide v0, -0xd32a04f3c3a53bdL

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lpubgm/loader/utils/FLog;->info(Ljava/lang/String;)V

    const-string v0, "ۛۧۥۘۚۜ۬ۛ۫ۗ۫ۥ۠ۧۥۥۚۛۢۛ۠ۦۘۨۤۛۥۥۨۘۡ۬ۨۘ۫ۤۗۧۢۨۘۖ۫۟۫ۨۡۖ۬ۗ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_94
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v4, -0xd32a03a3c3a53bdL

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lpubgm/loader/activity/MainActivity;->modeselect:Ljava/lang/String;

    const-string v0, "ۢۡۜۘ۬۬ۦۘۢ۠ۘۘۡۨۢۧۢۜۘۖۚ۟ۘۘۙۙۧۗۘۗ۫ۘ۫ۙۖ۠ۡۘۧۧۨ۫ۚۡۘۦ۬ۡۘۦۗۘۘۜۖۦۘۧ۠ۖۤۦۨ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_b7
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->root:Landroid/widget/TextView;

    const v1, 0x7f120101

    invoke-virtual {p0, v1}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۥۦۧۜۢ۬۫ۡۛۤۜۨۘۖۤۗۨۥۨۘۗۨۜۘ۠۟ۜۚۗ۫ۗۛۙ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_c8
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->container:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "۠۬ۧۡۖۘۘۥ۬ۚۡۨ۠ۖ۫ۖۘۤۥۚۢۙۖ۠ۦۡۘۡۗۘۛۥ۫ۢ۟۬ۗ۫ۡۘ۠ۚۘ۠ۥۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_d2
    invoke-virtual {v2, v6}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "۠ۗۙۡۛۦۘۡۘۗۘۢۖۨۙۢۜۚ۫ۙۥۖۘۡۚۙۧۘ۟ۧۛۥ۟ۤۘۘۛ۟۫ۙۡۘ۠۠ۜۤۢۨ۠ۙۧ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_da
    sput-boolean v7, Lpubgm/loader/activity/MainActivity;->Ischeck:Z

    const-string v0, "ۢ۠ۜۘۡۡۜۘۤ۠ۦۡۛۙۗ۫ۦۢۜۜۤۚۚۨۚۢۦ۫ۥۧ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_e1
    sput-boolean v7, Lpubgm/loader/activity/MainActivity;->noroot:Z

    const-string v0, "۟ۗۤۧۖۡ۟ۥۘۖۗ۟ۨ۫ۢۘ۟ۗۜۧۦۘۘۨۡۘۙۚ۫۟ۘۜۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_e8
    sput v7, Lpubgm/loader/activity/MainActivity;->device:I

    const-string v0, "ۤۜۨۘۖۙ۠ۤۗۦۙۢۥۥۙۢۘۥۖۘ۫ۙۥۨۙۙ۬ۘۧۘۜۤ۟ۖ۟ۚۢ۟ۚۛۜۨ۫ۜۘۥۖۥۙۘۢۘ۠ۛ۟ۦۖۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_ef
    const-wide v0, -0xd32a0283c3a53bdL

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lpubgm/loader/utils/FLog;->info(Ljava/lang/String;)V

    const-string v0, "۫۫ۤۤ۫۫ۗ۫۫۠ۚۜۘۖۘۡۘ۫ۤۜۘ۬ۛۖۤ۠۟۠ۧۘۘۗۢۜۘۙۙۦۘۢۡۖۘۜۘ۬۠ۧۧۨ۬ۛۧۧۗۡۙۜ۠ۘۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_100
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v4, -0xd32a01f3c3a53bdL

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lpubgm/loader/activity/MainActivity;->modeselect:Ljava/lang/String;

    const-string v0, "ۚ۟۬ۢۜۧ۫۬ۦۘۙۖۡۦۦۘۘۗۧۜ۟ۥۨ۫ۜۜۘۦۖۗۚۡۥۘۨ۬ۡۘۗۡۦۘۦۥۙ۬ۙۡۦ۟ۘۘۦۚ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_123
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->root:Landroid/widget/TextView;

    const v1, 0x7f1200e6

    invoke-virtual {p0, v1}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۚۙۦۚۢۢ۬ۖۗۘۧۖۘۥۥۦۘۚ۠ۛۡۛۚۜۨۚۡۚۡۘۛ۠ۘۘۙۤ۬ۢ۫ۜۥۤۛۡۦۨۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_134
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->doInitRecycler()V

    const-string v0, "ۢۤ۬ۢۦۘۘۦۧ۫ۥۧۖۘ۟ۗۦۘۜۧۘۘۨۥۥۖۘۖ۫ۛۜۘۧۜۧ۫ۙۧۗۛۜۘۗ۬۫ۚۜۚۥ۟ۗۙۥ۟"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_13c
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->container:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "ۖۗۗۗۗۚۙۗۜۖۚۜۘ۬ۚۤۜۤ۬ۦۦۚۗۦۘۤۖۢۡۖۛۜۧۘۙۥۜۘۖۥۗۘۧۦۘۗۨۤۚۙۨۘۨۘۜۘۛۛۡ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_146
    invoke-virtual {v2, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "۟ۜ۫ۤ۠ۖۦۜۖۙ۫ۤۢۤۧۘۜۧۘۢۛۡۚۤ۟ۡۧ۠ۖۥۘ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_14e
    sput-boolean v6, Lpubgm/loader/activity/MainActivity;->Ischeck:Z

    const-string v0, "ۨۚۦۘۘۤ۠۬۠ۚۢۥ۫ۜۡۦۘۤ۬ۥۘۥۙۘۢۙۜۘۘۦۦۘۧ۟ۨ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_155
    const/4 v0, 0x2

    sput v0, Lpubgm/loader/activity/MainActivity;->device:I

    const-string v0, "ۢۚۚۗۡۡۘۛۘۛۡۢۢ۫ۛۨۛ۠ۚۡ۬ۡۦۧۡۘۧۥۤ۫ۜۖ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_15d
    const-string v0, "ۢۗ۟ۛۗۢۚ۬ۙۗ۬۟ۙۦۖۘۖۘۥۜۚ۫ۤ۠ۡ۠۟ۧ۠ۗۥ۫ۦۘۥۛۨۘۧ۠۫ۨۨۚۗۜۧۘۡۢۨ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_162
    const-string v0, "ۢۚۚۗۡۡۘۛۘۛۡۢۢ۫ۛۨۛ۠ۚۡ۬ۡۦۧۡۘۧۥۤ۫ۜۖ"

    move-object v1, v0

    goto/16 :goto_8

    :sswitch_167
    return-void

    :sswitch_data_168
    .sparse-switch
        -0x6b089a13 -> :sswitch_123
        -0x6816ec71 -> :sswitch_da
        -0x62a02c70 -> :sswitch_13c
        -0x5fec061f -> :sswitch_1c
        -0x4b881d0f -> :sswitch_94
        -0x328c1968 -> :sswitch_134
        -0x31ece4a8 -> :sswitch_100
        -0x2fc7f08f -> :sswitch_83
        -0x24fb8695 -> :sswitch_20
        -0xbc5f61b -> :sswitch_ef
        -0x49a05b8 -> :sswitch_146
        0x2f2e7ee -> :sswitch_b7
        0x82f2764 -> :sswitch_14e
        0xc14a38b -> :sswitch_162
        0xcd73d56 -> :sswitch_167
        0xd640052 -> :sswitch_c8
        0x12f70dcb -> :sswitch_3e
        0x20bfc912 -> :sswitch_e1
        0x34d09cc1 -> :sswitch_155
        0x4823c524 -> :sswitch_e8
        0x5891d13b -> :sswitch_2f
        0x69798cfc -> :sswitch_d2
        0x78cbf576 -> :sswitch_4b
    .end sparse-switch

    :sswitch_data_1c6
    .sparse-switch
        -0x1da7f805 -> :sswitch_5f
        -0x170fdb8a -> :sswitch_59
        -0x12dee994 -> :sswitch_15d
        0x6b474032 -> :sswitch_7f
    .end sparse-switch

    :sswitch_data_1d8
    .sparse-switch
        -0x7b2ae553 -> :sswitch_6d
        -0x6c089abc -> :sswitch_5c
        -0x5722c71d -> :sswitch_7c
        0x248f2ed7 -> :sswitch_73
    .end sparse-switch
.end method

.method public doHideProgress()V
    .registers 6

    const/4 v1, 0x0

    const-string v0, "۬ۧۜۘۨۧۖۘۙ۬ۜۘ۫ۖۨۧ۬ۦۘۗۤۥۘ۫ۜۛ۟۬ۚۢۘۘۙۘ۫ۛ۠ۦۨۡۧۗۚۨۤ۟ۖ"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x3f

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0xd1

    const/16 v3, 0x30c

    const v4, 0x659702d3

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_68

    goto :goto_3

    :sswitch_17
    const-string v0, "۫ۖۜۘۙۥۜۗۤ۫ۜ۬ۧۛۙ۬ۡۡۙۖۚۗۤۢ۟۟۬ۘۘۘۨۙۢۜۨۢۙۤۛۚۜ۠ۙۘ۠ۤ۬ۥۗۚ"

    goto :goto_3

    :sswitch_1a
    iget-object v1, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const-string v0, "ۥ۟ۙۖۘۙۢۢۨۛۢۖۘۢ۠ۗۚ۠۬ۥۛۗۖۖۗۥ۫ۜ۫ۦۖۘ۠ۜۧۛۦۙ"

    goto :goto_3

    :sswitch_1f
    const v2, 0x5e12d49a

    const-string v0, "۠ۦۤۨۚۚۙۤۤۛۤۥۙۧۖۦۗۛ۬ۖ۠۠ۥۤۖ۫ۖۢۨۥۘۨ۟۫ۤۗۢ۬ۗ۟ۢۢۜ"

    :goto_24
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_86

    goto :goto_24

    :sswitch_2d
    const v3, -0x218602ba

    const-string v0, "ۜۦۡۧۘۖۘۗۖۛۨۨۛۘۧ۠ۥۘۘۖۘۥۘۥ۫۠۠ۙ۟۬ۛ۬ۤ۫۫ۨۗۥۘۘۛۜۥۘ"

    :goto_32
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_98

    goto :goto_32

    :sswitch_3b
    const-string v0, "ۘۥۚۗۙۜۖۚۧۗۡ۬ۥۙ۬ۢۧ۟ۡ۟ۘۘ۠ۢ۫ۗۦۚ۬ۘۘۘۚ۟ۜۗۡۘ"

    goto :goto_24

    :cond_3e
    const-string v0, "ۢۦ۟ۚۘۚۖۤۥۘۛۥۦۢۥۧۘ۫ۡۖ۬ۘۘ۟۬ۢ۠ۚۜۤۖۢۡۦۢ۫ۥ"

    goto :goto_32

    :sswitch_41
    if-nez v1, :cond_3e

    const-string v0, "ۡۢۨۦۥۢۢ۟۟ۖۚۖۘ۫ۧۜۙ۬ۗۘۤۦۘۘۚۨۘۙۤۖۗ۫۫ۛۧ۫ۨۤۦۘۚۢۦۚۧ۟ۧۦۖۘۖۘۛ۫۬ۚۤۤۢ"

    goto :goto_32

    :sswitch_46
    const-string v0, "ۙۧۡۡۤۘۘۢ۟ۚۖۛۜ۠ۜۚۙ۟ۜۘۦۙۜۘۚۜۦۘ۬ۧۦۗۧۗۙۢۥۦۧۘۧۙۗ۟ۘ"

    goto :goto_32

    :sswitch_49
    const-string v0, "۬ۢۥۘۥۛۨ۟ۙ۠ۖۛۗ۠ۘ۟ۗۤۜۖۛۗ۟ۢۖۗۢۦۗۘۘۡۦۤۛۛۚ۠۬ۤۛۘ۫"

    goto :goto_24

    :sswitch_4c
    const-string v0, "ۖ۟۟ۛ۠ۡۛۤۜۤۖۙۛۜۘۛۥۜ۬ۘۢۘۙ۫ۚ۟۬ۥۥۘۖ۠ۧۙۤۦۘۨۥۘۡۤ۬ۦ۫ۧۡ۟ۜۢۗۡۘۖۢۥۘ"

    goto :goto_24

    :sswitch_4f
    const-string v0, "ۚۛۙ۬ۢۜۛۦۨۦۦۘۨۦۘۤۗ۫ۙ۠ۜۘۡۚۥۘ۟ۤ۬ۥۤۢ"

    goto :goto_3

    :sswitch_52
    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setIndeterminate(Z)V

    const-string v0, "۫ۚ۠ۡۢۡۘ۬ۙۨۜۥۘۜۛۡۙۥۘۢۖۘۥۧ۫۬ۢۢ۫ۢۘۘۦۘۡ۬۬ۗ۟ۢۨ۬ۙۥ"

    goto :goto_3

    :sswitch_59
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const/16 v2, 0x8

    invoke-virtual {v0, v2}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setVisibility(I)V

    const-string v0, "ۤۙۙۜ۬ۖۡ۟ۨۘۖۖۛ۫ۢۢۥۛۡۘۢۖۗۜۗۙۧۢۡۘۜ۟ۨۘۗ۬ۡۘۛۖۥۘۙۢۤۖۘۦۤۖۥۨۚۜۘ"

    goto :goto_3

    :sswitch_63
    const-string v0, "ۦۤۡ۬ۙ۫ۜۡۧۘ۫ۤۛ۟ۚۧۥۙۡۘۥۧۤ۬ۥۢۥۙۘۘۡۥۧۙۤۘۘۙ۬ۗۛۘۜۘۢۥۜۘۖۚۚۚۛۖ"

    goto :goto_3

    :sswitch_66
    return-void

    nop

    :sswitch_data_68
    .sparse-switch
        -0x4f52467d -> :sswitch_59
        -0x20167440 -> :sswitch_66
        -0xfb9827d -> :sswitch_66
        0x317d677f -> :sswitch_52
        0x4ec693f3 -> :sswitch_1a
        0x4fbcbceb -> :sswitch_1f
        0x69a7148c -> :sswitch_17
    .end sparse-switch

    :sswitch_data_86
    .sparse-switch
        -0x52c2c355 -> :sswitch_63
        -0x21d41981 -> :sswitch_2d
        0x247da8ef -> :sswitch_4f
        0x76945e31 -> :sswitch_4c
    .end sparse-switch

    :sswitch_data_98
    .sparse-switch
        -0x746daa16 -> :sswitch_46
        -0x54856d7d -> :sswitch_41
        0x722c4f92 -> :sswitch_49
        0x7c9a2da8 -> :sswitch_3b
    .end sparse-switch
.end method

.method public doInitRecycler()V
    .registers 16

    const/4 v14, 0x1

    const/4 v7, 0x0

    invoke-virtual {p0, v14}, Lpubgm/loader/activity/MainActivity;->doShowProgress(Z)V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    const-wide v0, -0xd32a1ce3c3a53bdL

    :try_start_23
    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->loadJSONFromAsset(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-wide v8, -0xd32a1bb3c3a53bdL

    invoke-static {v8, v9}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v8

    move v1, v7

    :goto_3e
    const v9, -0x49a4efc

    const-string v0, "۟۫ۦۘۧۡۙ۬ۜ۫ۡ۫ۗۢ۬ۖۘۛۙۦۘۖۢ۟ۧۙۨ۬ۛۧۛۧۛۗۙ۠ۢ۠۫ۚۘۡۘۜ۠ۖۧۤۙۜۛ۠ۗۖ۬ۜ۫ۦۘ"

    :goto_43
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v10

    xor-int/2addr v10, v9

    sparse-switch v10, :sswitch_data_f2

    goto :goto_43

    :sswitch_4c
    invoke-virtual {v8, v1}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/json/JSONObject;

    const-wide v10, -0xd32a1a13c3a53bdL

    invoke-static {v10, v11}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-wide v10, -0xd32a1ab3c3a53bdL

    invoke-static {v10, v11}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-wide v12, -0xd32a1933c3a53bdL

    invoke-static {v12, v13}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-wide v12, -0xd32a19b3c3a53bdL

    invoke-static {v12, v13}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v12, Lpubgm/loader/Config;->GAME_LIST_ICON:[I

    aget v12, v12, v1

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_3e

    :sswitch_a1
    const-string v0, "۬ۙۙۦۛۦۥۢۡۘۥۨۙۙۘۖۖ۠ۤۨۖۜۥۜۗۡۢ۠۫۠ۚۜۘۤۧۚۗ۫ۚۜۘ۫ۖ"

    goto :goto_43

    :sswitch_a4
    const v10, 0x25762d9f

    const-string v0, "ۤ۬ۨۘۚۖ۫ۖۛۘۢۨۥۘۙۢۖۘ۬ۘۜۘۚۜۥ۬ۨۨۖۖۜۧۘۡۘۗۦۘ۬ۜۢۛۡۧ۫ۖۘ۟ۧۛ۠ۧۛ"

    :goto_a9
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v11

    xor-int/2addr v11, v10

    sparse-switch v11, :sswitch_data_104

    goto :goto_a9

    :sswitch_b2
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-ge v1, v0, :cond_bb

    const-string v0, "۟ۛۘۖۖۨۘۦۛ۫ۧۜۙۨۜ۫۟ۙۨۨۙۖۘۚۦۗ۠ۤۗۤ۠۬ۡۡۥۘۡۡۖ"

    goto :goto_a9

    :cond_bb
    const-string v0, "ۛۢ۫ۥۚۦۜۧۘۘۥۨۦۘۡۧۚۛۢۖۘۘۙۧۜ۬ۦۗۖۖۙۤۜۘ"

    goto :goto_a9

    :sswitch_be
    const-string v0, "۠ۧۗۚۧ۠ۢۖ۟ۙۦ۠ۙۛۘۦۤۚ۠ۥۡۗۖۜۚۖ۟۬ۨۘۨۨۤۧ۠ۡۘۙ۟ۡۖۤ"

    goto :goto_a9

    :sswitch_c1
    const-string v0, "ۥ۬ۛۜۘۖۘۢ۫ۖۘۨ۟ۖۘ۠ۥۦۜۖۛ۠۠ۤۗ۠ۨۘۘۗۨۧۘۜ۫۫ۘۘ۫ۛۜۘۚۢۦۘۡۗۥۘ"

    goto :goto_43

    :sswitch_c4
    const-string v0, "ۥۜۖۧۚۨۘۗ۫ۡۗۨ۠ۡۖ۠ۥۧۖۘۗۙۚ۟ۙۤۤۨۜۘ۠ۜۗۢۛۥۘۨۦۦ۫ۡۘۧۢۚ"
    :try_end_c6
    .catch Lorg/json/JSONException; {:try_start_23 .. :try_end_c6} :catch_ed
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_c6} :catch_c8

    goto/16 :goto_43

    :catch_c8
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_cc
    :sswitch_cc
    new-instance v0, Lpubgm/loader/adapter/RecyclerViewAdapter;

    move-object v1, p0

    invoke-direct/range {v0 .. v6}, Lpubgm/loader/adapter/RecyclerViewAdapter;-><init>(Lpubgm/loader/activity/MainActivity;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    const v1, 0x7f0902af

    invoke-virtual {p0, v1}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v14}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v7}, Landroidx/recyclerview/widget/LinearLayoutManager;->setOrientation(I)V

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    return-void

    :catch_ed
    move-exception v0

    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    goto :goto_cc

    :sswitch_data_f2
    .sparse-switch
        -0x69042604 -> :sswitch_c4
        -0x4c540a72 -> :sswitch_cc
        -0x20077a60 -> :sswitch_a4
        0x7a51eeff -> :sswitch_4c
    .end sparse-switch

    :sswitch_data_104
    .sparse-switch
        -0x7a1d7681 -> :sswitch_c1
        -0x6ade1ce0 -> :sswitch_be
        -0x54e3244a -> :sswitch_b2
        0x55fd3ec1 -> :sswitch_a1
    .end sparse-switch
.end method

.method public doShowProgress(Z)V
    .registers 8

    const/4 v5, 0x0

    const/4 v1, 0x0

    const-string v0, "ۧۚ۬ۛۜۖۖ۟ۖۘۛۘۚۨۨ۬ۦ۫ۡۚۙۦۤۦۢۜۘۜ۬۠ۡ۬ۡۘۤۖۤ۬ۚ۟۬ۜۦۥ۟ۢۚ۟ۢۥۡۘۧۙۘ"

    :goto_4
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x3ad

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x183

    const/16 v3, 0x1dd

    const v4, -0xcfacd62

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_f0

    goto :goto_4

    :sswitch_18
    const-string v0, "ۤۙۡ۫ۗۛۛۨۖۘۜ۬ۜۘۚۙۡۘۤۦ۠ۤۦۘۘۙۛۛۢۚۙۛ۠ۦۘۚۚۨۘۖۗۤ"

    goto :goto_4

    :sswitch_1b
    const-string v0, "ۙۦ۟۠ۖۢۡ۫ۜۘ۠ۗ۠ۖۢۖۘۜۗۜۘۛۦۛۦۖۛ۫ۦ۫ۛ۠"

    goto :goto_4

    :sswitch_1e
    iget-object v1, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const-string v0, "ۨۖۥۘۡۛ۠ۙۖۢۘۥۧۦۥۘۡ۟ۡۘۤ۟۠ۧۢۡۘۗ۫۬ۙۜۨ"

    goto :goto_4

    :sswitch_23
    const v2, -0x732181d6

    const-string v0, "ۙۢۦۙۡ۟ۢۖۜۘۖۤۘ۬۠ۨۧۛ۟ۛ۫ۖۛۛۥۗۤۘۖۖۢۙۜ۠ۥ۬۟ۥۙۜۘۨۢۦۘۛۤ۠ۗۛۜۤۘۚ۟ۡۥۘ"

    :goto_28
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_122

    goto :goto_28

    :sswitch_31
    const v3, -0x277e3bb6

    const-string v0, "۟ۜ۟۟۠ۦۘۚۡۨۘۜۘۘ۫ۦ۠ۨۜۡۛۛۥۘ۠ۜۥۘ۫ۚۘ۠ۡۥۤۢۨ۟۠ۨ"

    :goto_36
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_134

    goto :goto_36

    :sswitch_3f
    const-string v0, "ۨۖۨۗۧ۫ۗۘۥۘۧۜۖۘۘۦۦۘۖۦۨۦۤ۫ۢۧۖۘۜۚۛۙۢۧ"

    goto :goto_28

    :sswitch_42
    const-string v0, "ۢ۟ۦۚۛ۠ۛۦۡۘۦ۫ۧۦۦۡۘ۫ۖۜۘۤۖۜۡۘ۫ۘۦۡۥ۠ۧ۠ۗۡۨۡۘ۠ۥۖۦۦۡۘۧۦۧۘۦۥۥۘ"

    goto :goto_28

    :cond_45
    const-string v0, "ۙۤۢۨۥۥۛۢۡۜۢۦۡۦۖ۫ۨۘۘ۫ۙۗۛۢ۟ۦۥۘۨ۠ۨ۬ۚۧ۟ۘۗ"

    goto :goto_36

    :sswitch_48
    if-nez v1, :cond_45

    const-string v0, "ۚۨۦۘۛۘ۠ۧ۠ۘۨۨۘۢۖۡۘ۠ۤۙۖۦ۫ۧۨۙۘ۟ۖۘۢ۬ۖۘۡۖۘۢۘۧ۬ۢۡۘۚۢۥۡۜۦۘۡۧ۫"

    goto :goto_36

    :sswitch_4d
    const-string v0, "ۚۜۚۛ۠ۡۖۖۘۘۖۥۘۘۥۜۗۥۚۦۘۗۜۧۘ۫ۚۖۘۡۚۨۦ۠ۜۘۖۦۥۘۤۛۘۘ۠ۗۖۤ۬ۨۘۛ۠ۨۨ۠۟"

    goto :goto_36

    :sswitch_50
    const-string v0, "ۧ۠۫ۖۛۨۖۦۚۤۡۦ۬۫ۨۘ۠۬ۖۙ۬ۧ۬ۢ۫ۖ۟۫ۛ۬۬ۖۢۚۧۚۨۘۘۥ۠ۙۦۧ"

    goto :goto_28

    :sswitch_53
    const-string v0, "ۘۚۡۜۖ۠۟ۨۢۖۖۦۛۗ۫۫ۘۡۘۗۤۥۘ۟ۦۦۦ۬ۥۘۙۘۥۘۨ۬ۨۘۗۘ۬ۗۡۘۜ۫ۜۘۜۢ۫ۗۛ۟"

    goto :goto_4

    :sswitch_56
    invoke-virtual {v1, v5}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setVisibility(I)V

    const-string v0, "ۦ۬ۘۘۥۥۚۡۖۥۛۗۡۨ۠ۦۧۤ۟ۖۧۖۗۖۖۥ۫ۨۘۢۘۥۘۥۤ۟ۨ۠ۚۚۖۥۘۤۙۚ"

    goto :goto_4

    :sswitch_5c
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    invoke-virtual {v0, p1}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setIndeterminate(Z)V

    const-string v0, "۫۠ۤۚۛۧ۠ۥۢۚۦۚۧۚ۠۟۠ۡۘۧۛۨۘۙۧۧۥۙۖۥۗۘۘۘۡۦۘۡۙۙ"

    goto :goto_4

    :sswitch_64
    const v2, 0x476e39b8

    const-string v0, "ۨۥۙۢۨ۬ۥۜۙۙۦۡۡ۠ۡۥۡۘۡۙۘۙ۠ۡۚۥۥۜ۬ۚۢۡ۟ۚۚۖۗ۬ۢۦۦ"

    :goto_69
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_146

    goto :goto_69

    :sswitch_72
    const-string v0, "ۘ۟ۖۘۙۨۚۦۛۧۢۨۤۤۙۥۤۦۖۢۨ۫ۦۖۦۘۧۛۖۘۡۙۛۖۖۖۖۖۥۘۚۨۘ۫ۜۖۘ"

    goto :goto_4

    :sswitch_75
    const-string v0, "ۦۢۨۚۖ۬ۙۧۦۘۡۤۨ۬ۗۦۧۨۡۘ۟۠ۡۢ۫۠ۜۢۚ۟ۜۢۖۢۥۦۗۡۙ۠ۖۘۧۨۜ۬۟ۗۗۘۡ"

    goto :goto_69

    :sswitch_78
    const v3, 0x72bac481

    const-string v0, "ۡۙ۠ۨۥ۠ۤۤۨۘۧ۫ۜۗۦ۫ۥ۬۟۠ۛۛ۬ۡۢۗ۬ۦۘ۫۟ۡۘ"

    :goto_7d
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_158

    goto :goto_7d

    :sswitch_86
    const-string v0, "ۢۛۜۙۦۧۘۢۘۨۘ۬۬ۦۘۡۙ۠۬ۡۘ۫ۙۨۘۖۜۖۛۛۧۢۗۦ"

    goto :goto_69

    :cond_89
    const-string v0, "۠ۧۨۘۥۧۢۨۦۦۢۜۦۗۘۙۢۙۡۘ۠ۘ۫۟۬ۧ۠۠ۘۤۖۥۘۙۜۘۧۦ۫۟ۜۜۘۖۛۛ"

    goto :goto_7d

    :sswitch_8c
    if-nez p1, :cond_89

    const-string v0, "ۧ۟ۖۘۢۚۛۚ۬ۥۘۚۧۧۦۨۥۙ۟ۗۨ۟ۡۤۚۖۢۗۛۘۥۘۚۨ۬ۢ۟۬ۚۗۖۚ۬ۖۖۘۗۙ۬ۘۢۡۙۡۛ"

    goto :goto_7d

    :sswitch_91
    const-string v0, "ۛۙ۬ۨۨۖۘۖۘۖۖ۬۠ۘۥۘۗۡۤۦۧۖ۟ۢۖۘۗۢۡۚۧۚۦۘۘۢۡۘۦۜۦۗۦۢۦ۟۠ۘۥ"

    goto :goto_7d

    :sswitch_94
    const-string v0, "ۤۨۧۘۘۢۖۛۦ۟ۡۡۧۚ۫ۘۘۜۗۜۘۧۢۘۘۚۨۖۧ۫ۗۗۥ۠ۨۗۙۥۘۡ۟ۘۡۘۖ۠ۥ"

    goto :goto_69

    :sswitch_97
    const v2, 0x7be53ec7

    const-string v0, "ۡۙۦۙ۠ۗۛۡۨۢۧۡۤۢۜ۠ۗۙۗۡۘۙۗۘۥۤۧۙۘۦۘۡۚۨۡۡۘۘ"

    :goto_9c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_16a

    goto :goto_9c

    :sswitch_a5
    const-string v0, "ۗۖۧ۟ۚۖۘۧۧۙۗۘۛۦ۠ۢ۠ۜ۟ۘۛۡۧۛ۫ۤۙۥۚ۫۫ۜۙۛۧۡۖۘۗ۬ۚۚ۫ۧۖۜۤۖۤۢۛ۬ۜ۫۟۠"

    goto/16 :goto_4

    :sswitch_a9
    const-string v0, "ۤ۟ۤۥۛۜ۫ۡۦۥ۠ۥۘۗۦۙۘۙۜۘۡۥۧۘۥۢۙۜۘۥۘۨۚۖ"

    goto :goto_9c

    :sswitch_ac
    const v3, -0x6da3a58a

    const-string v0, "ۨۧۨۘ۬ۚۢ۠ۤۘۘۜ۟ۖۘۚۨۨۘۜۖ۠ۥۨ۫ۜۡۡۘۨ۟ۛ۠ۛۨۡۖۘ۫ۧۜۘ۫ۤۢ۠۟۬ۛۗۛۜ۬ۤۜۜۜۥۖۡ"

    :goto_b1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_17c

    goto :goto_b1

    :sswitch_ba
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    if-lt v0, v4, :cond_c3

    const-string v0, "ۧۘۘۚۙۖۜۚۦۘۢۡۧۘ۫ۖۙ۟ۛۖ۬ۨ۟ۢۘۧۧ۬ۦۧۚۚ۫۬ۖۘۢۦۡۘ۫ۢۜۘۤۡۛ"

    goto :goto_b1

    :cond_c3
    const-string v0, "ۖۢۚۢۨ۠ۙۤۘۘۗۥ۠۫ۨۥۚۨۥۢۡ۟ۘۚۤۖۙۙۢۦۜ۟ۖۨۘۛۜۧ۠ۥۘۘ۠ۘۦۧۤۧۚۛۘۦۥۢۢۥ۟"

    goto :goto_b1

    :sswitch_c6
    const-string v0, "ۨۘ۫ۚ۟ۦۘۘۡ۬ۤۗۧ۫ۚۛۡۜۜۡۜۡ۠ۥۘۤۡۨۘ۬۠ۦ"

    goto :goto_b1

    :sswitch_c9
    const-string v0, "ۚۘۦۗۢ۠ۗۜۘ۬۫ۦۖ۠ۡۘۚۛۜۚۚۥۘۜۚۨۘۤۥ۠ۘۦ۫ۛ۠ۥۘۨۖۨۦۖ۫ۤۛۙ۠ۨۡۥۚۥۘۥۨۗۛۙ"

    goto :goto_9c

    :sswitch_cc
    const-string v0, "ۙ۫۠۬ۙۖۘ۬ۧۖۗۢۚۙۘۦۘۤۥۥۘ۫ۤۜۘۢۘ۟۠ۢۡۘۦۚۤۛۖۨۜۖۜ"

    goto :goto_9c

    :sswitch_cf
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    invoke-virtual {v0, v5}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setMin(I)V

    const-string v0, "ۚۨ۟ۙۢۡۘ۫ۨۚ۟ۦ۠ۦۙۦۘ۬ۙۥۜۗۜۘۨ۬ۛۘۗۧۢ۬ۦۘۘۥۢ۫ۡ۟ۗۖۙ۟ۜۘ"

    goto/16 :goto_4

    :sswitch_d8
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const/16 v2, 0x64

    invoke-virtual {v0, v2}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setMax(I)V

    const-string v0, "ۖۧ۫۫ۤۘۗۛۜۛۗ۟ۙۘۙ۬ۘۘۘۤۚۡۨۢۖۘۙۖۙۙۥ۠ۘۥۥۡۘۧۘۜ۬ۛۖۚۡۘۘۥۛۜۨۘۧۢۦۘۚۦۥۘ"

    goto/16 :goto_4

    :sswitch_e3
    const-string v0, "۟ۘۡۦۘۛۦۗۜۡۤۤۘۢۥۙۘ۫۠۠ۨۘۦۛ۫۫ۡۛۛۦۤۦۦۢۘۖۘۥۗۡۢۥۨ۫ۨۨۘ۠ۤۨۘ۫ۘ۫ۥۖۚ"

    goto/16 :goto_4

    :sswitch_e7
    const-string v0, "ۚۨ۟ۙۢۡۘ۫ۨۚ۟ۦ۠ۦۙۦۘ۬ۙۥۜۗۜۘۨ۬ۛۘۗۧۢ۬ۦۘۘۥۢ۫ۡ۟ۗۖۙ۟ۜۘ"

    goto/16 :goto_4

    :sswitch_eb
    const-string v0, "ۖۧ۫۫ۤۘۗۛۜۛۗ۟ۙۘۙ۬ۘۘۘۤۚۡۨۢۖۘۙۖۙۙۥ۠ۘۥۥۡۘۧۘۜ۬ۛۖۚۡۘۘۥۛۜۨۘۧۢۦۘۚۦۥۘ"

    goto/16 :goto_4

    :sswitch_ef
    return-void

    :sswitch_data_f0
    .sparse-switch
        -0x53b5a5ae -> :sswitch_d8
        -0x431661ff -> :sswitch_56
        -0x3b89756d -> :sswitch_cf
        -0x2ef01d83 -> :sswitch_23
        -0x2d9d04f5 -> :sswitch_5c
        0x4e0ac2e -> :sswitch_ef
        0x1268a0a1 -> :sswitch_1e
        0x28a23225 -> :sswitch_1b
        0x33f92114 -> :sswitch_ef
        0x4135b261 -> :sswitch_97
        0x4727ef07 -> :sswitch_64
        0x58774492 -> :sswitch_18
    .end sparse-switch

    :sswitch_data_122
    .sparse-switch
        -0x59dd0947 -> :sswitch_53
        -0x301b0060 -> :sswitch_e3
        0x2c3c26a3 -> :sswitch_50
        0x2f4859fc -> :sswitch_31
    .end sparse-switch

    :sswitch_data_134
    .sparse-switch
        -0x64d36843 -> :sswitch_3f
        -0x5e0e6878 -> :sswitch_42
        0xa3c8f18 -> :sswitch_48
        0x74a6687c -> :sswitch_4d
    .end sparse-switch

    :sswitch_data_146
    .sparse-switch
        -0x40f11d6b -> :sswitch_72
        -0xe5bf5db -> :sswitch_eb
        0x2daa922f -> :sswitch_78
        0x381816d0 -> :sswitch_94
    .end sparse-switch

    :sswitch_data_158
    .sparse-switch
        -0x4a32526e -> :sswitch_91
        0x5ec5ac9 -> :sswitch_8c
        0xd596083 -> :sswitch_86
        0x6aa44c48 -> :sswitch_75
    .end sparse-switch

    :sswitch_data_16a
    .sparse-switch
        -0x1e67f55b -> :sswitch_cc
        0xe525209 -> :sswitch_a5
        0x377a0125 -> :sswitch_ac
        0x79c99633 -> :sswitch_e7
    .end sparse-switch

    :sswitch_data_17c
    .sparse-switch
        -0x7048e9f5 -> :sswitch_c6
        -0x483fc1d8 -> :sswitch_a9
        0x21efc2e3 -> :sswitch_ba
        0x34e50996 -> :sswitch_c9
    .end sparse-switch
.end method

.method gameversion(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V
    .registers 11

    const v4, 0x7f070097

    const-string v0, "۬ۙۗ۬ۡۖۘ۬ۧۖۘ۬ۢ۬ۖ۟ۧۨۧۜۘۖۛۡۘۜۧ۟ۘۗۘ۟ۤۗۖۜۡۘۙ۫ۦۘ۠ۡۡۘۧ۬ۘۘۡۖۢۤۤۦ"

    :goto_5
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x21d

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x239

    const/16 v2, 0x265

    const v3, -0x28fe87be

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_4e

    goto :goto_5

    :sswitch_19
    const-string v0, "ۥۨۜۘۥ۠ۖۙۦۡۘۚۗۘۘۚۨۘۘۚۡۥۢ۫ۧۤۛۖۡۧۧۙ۫"

    goto :goto_5

    :sswitch_1c
    const-string v0, "ۘۙۡۘۤۧۡۘۖۗ۟ۧۢ۟ۘۘۘ۫ۡ۬ۚ۬ۧۖۘۗ۠ۨۡۙۜ۟ۤۖۨ۟ۤۡۘ"

    goto :goto_5

    :sswitch_1f
    const-string v0, "ۡۥ۫ۙ۟ۤۛۛۗۜۥۗۦۜ۠ۚۥۗۢۤۤۢۤۡۢ۟ۦۘۡۧۖۘۗۤۗۨۡۘۘ۫ۛۥۘۖ۬ۘۘ"

    goto :goto_5

    :sswitch_22
    const-string v0, "ۤۖ۟ۨۥۡۘۥ۫ۨۘ۟ۢۘۘۨ۠ۥۘ۟۬۬۟ۚۦۘ۫ۛۤ۠ۘۘۧۙۖۦۖۗ۠ۡۘ۫۫ۛۜ"

    goto :goto_5

    :sswitch_25
    const-string v0, "ۤۨۖۘۤۙۘۘۙ۟ۙ۫۬ۖۘۨۧۖۘۧ۫ۛۦۜ۟ۙۜۡۢ۬ۛۚۨۚۜۙۢۦۘۘۡ۠ۘ۫ۚۗۗۧۦۘۢۘ۠"

    goto :goto_5

    :sswitch_28
    const-string v0, "۠ۤ۫ۗۖۦۘۨۤۡۗ۫ۘۖ۫ۨۘ۬۫ۥۘۙۨ۟ۦۙۗ۟ۡۗۚۦ۫ۗۖۢۘۨۡۘۗۚۥۘۜۡۤۥۜۧۢ۠۟"

    goto :goto_5

    :sswitch_2b
    const v0, 0x7f070094

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    const-string v0, "۬ۥۖۘۢۖۦۧۛۨۚۜۦۘۡ۠ۤ۬ۥۡ۬ۤۡۛۖۦۨۤۦۜ۠۠"

    goto :goto_5

    :sswitch_34
    invoke-virtual {p2, v4}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    const-string v0, "۠۬ۖۧ۫۬۟ۚ۠ۙۧۙۦۗۛۤۥۛۥۚۥۘۙۨۗۜۖۗۤۦۨۘۙ۬ۡ۫ۜۖۖۡۥۘۖۚۥۜۡ۫ۜۤۚ"

    goto :goto_5

    :sswitch_3a
    invoke-virtual {p3, v4}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    const-string v0, "ۜۡۨۘۗۦۜۘۦۧۘۜ۬ۨۧۜۙ۠ۡۧ۟ۚۡۦۜۘ۟ۙۦۤۖ۟ۛۛ۠ۡۘۧۙۢ۫ۡ۫ۥۨۦۘ۠ۧۧۗۘۥۜ۠ۦ"

    goto :goto_5

    :sswitch_40
    invoke-virtual {p4, v4}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    const-string v0, "ۗۧ۬ۨۢۘۘۦۦۧۘۜ۟ۢۨۜۘۛۛۚۗۛۥۘ۬ۜۗۢ۫ۡۘۜ۫ۖۘۖۥ۫ۡۛۡ"

    goto :goto_5

    :sswitch_46
    invoke-virtual {p5, v4}, Landroid/widget/LinearLayout;->setBackgroundResource(I)V

    const-string v0, "۬ۚۗ۬ۖۦۘ۬ۚۡ۠ۤۡۛۜۖۥ۟ۥۛۨۖۧ۟ۥۦۘۨۘ۟ۛۤ۬ۜۘۢۗۜۛۤ۠ۨۥ۬ۚۦۡۘ۫ۖ۫ۜ۠ۚۡۥۜ"

    goto :goto_5

    :sswitch_4c
    return-void

    nop

    :sswitch_data_4e
    .sparse-switch
        -0x6d3aebb2 -> :sswitch_28
        -0x680d77c6 -> :sswitch_1f
        -0x55001195 -> :sswitch_34
        -0x511ef304 -> :sswitch_1c
        -0x2bfcfe23 -> :sswitch_46
        -0x2513fd8a -> :sswitch_3a
        -0x1e46b598 -> :sswitch_4c
        -0x3e088bf -> :sswitch_25
        0x30d6a8bb -> :sswitch_22
        0x56049b5f -> :sswitch_2b
        0x5df67904 -> :sswitch_19
        0x74459b8e -> :sswitch_40
    .end sparse-switch
.end method

.method public getProgresBar()Lcom/google/android/material/progressindicator/LinearProgressIndicator;
    .registers 5

    const-string v0, "ۥۡۗ۠۫ۗ۬ۗۜۘۘۚۧ۟ۜۘۛۦۡۦ۫ۘۦ۫ۥۘۧۙۜۥ۠۟ۧۙۡۚۚۥ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x19

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x1a2

    const/16 v2, 0x16e

    const v3, 0x5b27fd40

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_62

    goto :goto_2

    :sswitch_16
    const-string v0, "ۘ۬ۨۢۨ۟ۦۨۖۧۥۤۛۗۗ۠ۙۗ۫ۦۘۛ۠ۖۘۜ۠۟ۛ۫ۧۢ۫ۢ۠۬ۡ"

    goto :goto_2

    :sswitch_19
    const v1, -0x45d3fe33

    const-string v0, "۠ۗۛۧۢۡۘۤۡ۠ۢ۟ۨۚۜۥۘۛ۟ۜ۬ۧۜۘۙۗۥۜۛۢۖۥۦۜ۬ۦۧۙ"

    :goto_1e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_74

    goto :goto_1e

    :sswitch_27
    const-string v0, "ۜۤۢۘۖۦۘۚۘۙۘ۫ۚۜ۟ۛۤۘۧۘۤ۬ۦۘۖۥ۠۬ۥۙۨ۟۟ۨۨۥۚ۬ۥۦۡۗۦۖۚ۟ۨۘ۟ۦۡۘۚۛۨۧۗۡ"

    goto :goto_2

    :sswitch_2a
    const-string v0, "ۢۘۙۖۖۨۘۖۛۦۨ۫ۗۜۙ۠۠ۜ۬ۨۤۢۘۖۘۗۤۖۘ۫ۖۧۘۗۛۦۘۡ۟ۦۘۥۡۡۘۜۗۢ۫۠ۡۤۛۙ۟ۚ۠ۨۛ۠"

    goto :goto_1e

    :sswitch_2d
    const v2, -0xb259cc

    const-string v0, "ۗۨۡۜۚۤۖۧۗۤۧۘ۠ۛۧۜ۠ۦۜ۟ۤۘۧۧۡۧۥۦۤۥۜۢۜۘ۟۫۟ۗ۫ۡۘۦۥۜ۬ۤۡۤۜۗۦۥۙ۫ۚ۠"

    :goto_32
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_86

    goto :goto_32

    :sswitch_3b
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    if-nez v0, :cond_42

    const-string v0, "۟۟۟ۤۖۖۙۥ۠ۖ۫ۧۗ۬ۚۖ۠ۥۦۨۚۥۛۡ۬ۙۗۖۖ۫ۗۖۦۚۨۢ۠۫ۧۧۡۥۦۚ۟ۤۙۦۡۗۤۨۦ"

    goto :goto_32

    :cond_42
    const-string v0, "ۗۛۥۡۖۨۘۢۙۙۧ۠ۗۘۧۖۘۜ۫ۜۙۜۥۘۜۜۧۘۦۖۘۖۨۘۘ۠ۤ۠ۡ۬ۙۘۜۖۦۘۘۧۨۥۘ۟ۡۘۜۗۢۛۤۜۘ"

    goto :goto_32

    :sswitch_45
    const-string v0, "ۘۧۛۥۙۨۘۤ۟ۢۨۤۚۗۘۘۘۛۦۘۢۘۥۧۨ۟ۤ۬ۨۘۗۙۥۘ۠ۙ۬ۥ۬ۘۗۥۗۚۢ"

    goto :goto_32

    :sswitch_48
    const-string v0, "ۜۦۥۡۤۜۨۦۧۙۤۢۛۙۙۢ۬ۧۢۤۥۜۛۛۙۧۗ۠ۡۘۘۖۡۚ۫ۜۘۨۨ۠ۜۘ۟ۨۨۜۘۜ۠ۚ"

    goto :goto_1e

    :sswitch_4b
    const-string v0, "ۜۙۦۜۛۖۘۡۢۦۚۖۘۚ۫ۤۙۧۥۘۡۗۢ۟۟ۜۘۡۡۧۘۙ۟ۨۘۥۧۜۘۙۘ"

    goto :goto_1e

    :sswitch_4e
    const-string v0, "ۙۢۖۖ۫ۖۢۖۦۘۤۙۘۛ۠ۜۘۤۥ۟ۜۢۨۘۨۙۨۥ۬۬ۛۤۖۛۜۨ۬ۢۡۘ۟ۥۛۨۖۘ۟ۨۗۡۥ۫ۢۨۡۘۗۦ۟"

    goto :goto_2

    :sswitch_51
    const v0, 0x7f090298

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    iput-object v0, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const-string v0, "ۜۤۢۘۖۦۘۚۘۙۘ۫ۚۜ۟ۛۤۘۧۘۤ۬ۦۘۖۥ۠۬ۥۙۨ۟۟ۨۨۥۚ۬ۥۦۡۗۦۖۚ۟ۨۘ۟ۦۡۘۚۛۨۧۗۡ"

    goto :goto_2

    :sswitch_5f
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->progres:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    return-object v0

    :sswitch_data_62
    .sparse-switch
        -0x7eacaa49 -> :sswitch_19
        0x327a1f93 -> :sswitch_51
        0x452fe2f6 -> :sswitch_5f
        0x54568546 -> :sswitch_16
    .end sparse-switch

    :sswitch_data_74
    .sparse-switch
        -0x5c5bc649 -> :sswitch_27
        -0x384ba7af -> :sswitch_4b
        0x1fb9f7d4 -> :sswitch_4e
        0x555e8fc4 -> :sswitch_2d
    .end sparse-switch

    :sswitch_data_86
    .sparse-switch
        -0x4f43f8a3 -> :sswitch_2a
        -0x2409a7ba -> :sswitch_48
        0x9a4d09c -> :sswitch_3b
        0x10711849 -> :sswitch_45
    .end sparse-switch
.end method

.method init()V
    .registers 8

    const/4 v3, 0x0

    const-string v0, "ۖۜۦۘۨ۟ۜۖۧۖۘۧۦ۬ۢۦۘۘۥۦۜۖۢۦۘۗ۟ۧۘ۬ۜۘۡ۟ۢۘ۟ۜۘۡۦۗ۬ۢ۠ۧ۬ۧ"

    move-object v1, v0

    move-object v2, v3

    move-object v4, v3

    move-object v5, v3

    :goto_7
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v3, 0x3b5

    xor-int/2addr v0, v3

    xor-int/lit16 v0, v0, 0x26f

    const/16 v3, 0x121

    const v6, -0x22eb7a9b

    xor-int/2addr v0, v3

    xor-int/2addr v0, v6

    sparse-switch v0, :sswitch_data_6e

    goto :goto_7

    :sswitch_1b
    const-string v0, "ۧۗۦۘۛۗۘ۟۟ۙ۟۠ۥۢۘۤ۠ۙۜۦۘۗۢۦۘ۫ۡۤ۠ۡۘۖۥۥۘۛۥ۫"

    move-object v1, v0

    goto :goto_7

    :sswitch_1f
    const v0, 0x7f0900f5

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    const-string v1, "ۛۙۥۘ۠ۜۧ۫ۛۥۘۘۙۡۘۧۢۦۘۘۖۛۦۡ۠ۜۗۛۤ۬ۜۨ۠ۢ۫۬ۘۖ۠"

    move-object v5, v0

    goto :goto_7

    :sswitch_2c
    const v0, 0x7f0901c1

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    const-string v1, "ۗ۟ۖۗ۠ۡ۫۫۟ۜۢۦۧۧۡۘۦۦۛۢۡۡۧۤۥۜۖۖۘ۠ۖۘۙ۟۠ۦ۟ۙۦۜۡۘۗ۠ۦۘ"

    move-object v4, v0

    goto :goto_7

    :sswitch_39
    const v0, 0x7f0901c2

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    const-string v1, "ۡۛۘۘۢۤ۫ۖۘۖۘۢۦۘۘۜۨۢۚ۬ۤۘۡۙۡۙۥ۬ۤ۬ۧۨۧۥۨۥۘۥۜ۟۬۬ۦۘۗۜۘ"

    move-object v2, v0

    goto :goto_7

    :sswitch_46
    const/4 v0, 0x0

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "۠ۙۥۘ۬ۤۡۘ۟ۛۦ۟ۤۦۘۖۤۜۘۜ۠ۢۖۖۚۛۛۨۧۚۤۨۜۤ۟ۥۘ۟ۦۢۜ۫ۨۘۙ۠۫"

    move-object v1, v0

    goto :goto_7

    :sswitch_4e
    const/16 v0, 0x8

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "ۗ۟ۥۘ۬ۜۘۘۚۤۥ۫۬ۙۢۛۛۥۘۦۢۤۡۜۡۚۛۢۗۙۘۚۜۖۘۨۛۛۗۢۦۘۧۗۨ"

    move-object v1, v0

    goto :goto_7

    :sswitch_57
    new-instance v0, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, v5, v4, v2}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda1;-><init>(Lpubgm/loader/activity/MainActivity;Lcom/google/android/material/bottomnavigation/BottomNavigationView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-virtual {v5, v0}, Lcom/google/android/material/bottomnavigation/BottomNavigationView;->setOnItemSelectedListener(Lcom/google/android/material/navigation/NavigationBarView$OnItemSelectedListener;)V

    const-string v0, "ۧۗ۠ۥۙ۠۠۬ۖۧۛۜۘۘۙۛۤۢ۬ۦۢۨۛۢۘۘ۠ۖۜۘ۬ۗۘۦ۬ۗۚۚۖۦۛۨۘۧۥۘۡۜ۠ۥۘۦۘ"

    move-object v1, v0

    goto :goto_7

    :sswitch_63
    const v0, 0x7f09025f

    invoke-virtual {v5, v0}, Lcom/google/android/material/bottomnavigation/BottomNavigationView;->setSelectedItemId(I)V

    const-string v0, "ۧۜۛۖۧۗۘۜۖۦۢۥ۫ۦ۫۟ۙ۠ۤۖۘۧ۫۬ۙۛۖۥ۟ۖ۠ۛۡۖ۬ۥۘۖۛۨۘۗۗۡۘ"

    move-object v1, v0

    goto :goto_7

    :sswitch_6d
    return-void

    :sswitch_data_6e
    .sparse-switch
        -0x6e3cad17 -> :sswitch_57
        -0x46ecd481 -> :sswitch_4e
        -0x45b21c46 -> :sswitch_6d
        -0x17691096 -> :sswitch_63
        -0x157aa3f5 -> :sswitch_39
        -0x3e24b6d -> :sswitch_1f
        0x1a2775ab -> :sswitch_2c
        0x267d3814 -> :sswitch_1b
        0x4248b10f -> :sswitch_46
    .end sparse-switch
.end method

.method initMenu1()V
    .registers 28

    const/16 v17, 0x0

    const/16 v16, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v15, 0x0

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v12, 0x0

    const-string v3, "ۖۡۧۘۧ۬ۚ۬ۘۤ۫ۨ۬ۨۖۖۢۘۖۘ۬ۖۡۛ۬۬ۛۤۚۤۧۜۘۚۙۖۘ۬ۛ۠ۖۙۤۙ۠ۛ"

    move-object v4, v3

    move-object/from16 v21, v12

    move-object/from16 v22, v13

    move-object/from16 v23, v14

    move-object/from16 v24, v15

    move-object/from16 v25, v16

    move-object/from16 v26, v17

    :goto_1e
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v3

    const/16 v12, 0xf1

    xor-int/2addr v3, v12

    xor-int/lit16 v3, v3, 0x15f

    const/16 v12, 0x1a1

    const v13, -0x6cd5e130

    xor-int/2addr v3, v12

    xor-int/2addr v3, v13

    sparse-switch v3, :sswitch_data_244

    goto :goto_1e

    :sswitch_32
    const-string v3, "ۡۤۜۘۤۙۘ۬ۙۘ۟۬۬ۥۘۛۥ۫ۜۘۡۦۘۗ۫ۢ۬ۖۙۦۨۘۘۥۖۘۧۙۜ"

    move-object v4, v3

    goto :goto_1e

    :sswitch_36
    const v3, 0x7f09033f

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    const-string v4, "۬۠ۙۚۥۗۖۦۦۤۡۦۗ۠ۙۨ۫ۡۡۘۙ۬ۥۙۜۢۧۛۘ۠ۧ۫ۦۖۙۤۜۗۜۘ۫۫ۥۘۗۨۖۘۘۘ"

    move-object/from16 v26, v3

    goto :goto_1e

    :sswitch_46
    const v3, 0x7f090344

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    const-string v4, "۫۠ۦۘۚۨۥۘۛۨۤۚۦۛۜۚۨ۟ۖ۬ۙۖۜۘۧۧۨۘۙۥۖۘ۫ۧۙۡۥۥۥۢ۬"

    move-object/from16 v25, v3

    goto :goto_1e

    :sswitch_56
    const v3, 0x7f09019d

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v4, "ۜ۬۟ۥ۬ۢۡۡۦ۬۟ۜۤۢۗۡۧۤۡۡۖۤ۠ۗۖۘ۠ۘۨۙ۫ۙۘ۟ۜۥۚ۟ۡۙ۫ۙۥۡۘۘۡۗۡۘۚۘ۟ۡۨۙ"

    move-object v5, v3

    goto :goto_1e

    :sswitch_65
    const v3, 0x7f0901f2

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v4, "۬ۦۙۤۥۚۤۛۥۘ۟۟ۗۧۤ۫ۡۙۖۘۖۘۤ۟۟۟ۡۘۘ۟ۥۘۘۢۙۜۤۙۡۘ۫۫ۘ۠ۥۘ"

    move-object v6, v3

    goto :goto_1e

    :sswitch_74
    const v3, 0x7f0903b1

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v4, "ۨۢۖۦ۫ۜۘۛۚۚۙۡۘ۟ۤۘۘ۠ۘۧ۟ۜۢۖۨۢۧ۫۟ۘۚۤۜۙۜ۠ۦ۫ۙۙۨۗۘ۫ۧ۫۠ۜۜۖۘ"

    move-object v7, v3

    goto :goto_1e

    :sswitch_83
    const v3, 0x7f09035b

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v4, "ۧۦۢ۟ۨۜۘۚۤۙۢۜۨ۬ۡۦۦۧ۫ۥۘۘۙۙ۠ۤۨۥۘۤۢۦۘۖۘۢۚ۫ۨۧۡۡ۠ۢۡۘ۠ۤۜۘ۬ۢۗ"

    move-object v8, v3

    goto :goto_1e

    :sswitch_92
    const v3, 0x7f0901cf

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v4, "ۘۥۜۖۢۘۘۗۘۧۗۛۡۛ۟۟ۥ۫ۡۡۡۢ۫۟ۘۦ۠۫ۨۗ"

    move-object v9, v3

    goto/16 :goto_1e

    :sswitch_a2
    const v3, 0x7f0901fc

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v3, "ۘۗۢۦۨۗ۫ۚۨۖۘ۟ۤۙۦۗۛۜۧۚۖۚۛۦۘۨۢ۟ۢۧۡۘۢۛۦۘۚ۫۫ۦۧ۟"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_b2
    const v3, 0x7f090236

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v4, "ۦ۫ۖۘۧ۟ۤۖۤۤۖۦۡۗۘ۟ۜ۬ۥۘۚۤ۫ۥۙۥۚۘۡۤۡۦۘۛۜۦۢۖۧۘۖ۬ۢۢۢۢ۫ۦ۬ۥ۠۟ۖۨ۟ۧۡ"

    move-object/from16 v24, v3

    goto/16 :goto_1e

    :sswitch_c3
    const v3, 0x7f09029e

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const-string v4, "۠ۥۨۘۖ۫ۖۛۛۥۘۤۘۨۤ۠ۗۙ۠ۜۘ۟ۘ۫ۘ۟ۧۧۦۚۥۦۢ۟ۗۙ۫ۖۤ"

    move-object/from16 v23, v3

    goto/16 :goto_1e

    :sswitch_d4
    const v3, 0x7f090373

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const-string v4, "ۖ۫ۖ۫ۢ۟ۨۙ۟۬ۧۤۜۚۧ۫ۙ۟ۚ۟ۡۘۤۜۚۛۡ۬ۛۡۘۤۥۗ۠۠ۦۘ"

    move-object v10, v3

    goto/16 :goto_1e

    :sswitch_e4
    const v3, 0x7f0901c3

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    const-string v4, "۬ۨۥۘۧ۬۫ۡۖۤۙ۟ۢۤۛۦ۫ۖۦۛ۬ۗۤۙ۟ۜ۠ۜۦۜۘۤۛ۟ۖۛۖۥۡ۫ۤۢ۬"

    move-object v11, v3

    goto/16 :goto_1e

    :sswitch_f4
    const v3, 0x7f0901a5

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/RadioGroup;

    const-string v4, "ۡۙۘۛ۫۠ۥۨۘۧ۠ۧۙۨۚۥۥۦۘۡۗۜۖۧۜ۟ۖۙۛۗ"

    move-object/from16 v22, v3

    goto/16 :goto_1e

    :sswitch_105
    const v3, 0x7f0901a3

    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/RadioGroup;

    const-string v4, "ۡ۫ۛ۟ۧۤ۬ۢۜۘۧۖۡ۠ۗۥۙۧ۟ۘۛۡ۫ۢۨۘۢۡۚۘ۫ۖ"

    move-object/from16 v21, v3

    goto/16 :goto_1e

    :sswitch_116
    const v4, 0x8142780

    const-string v3, "۬ۡۘۖۧ۠ۥۖۖۛۙۙۡۛۨۧ۠ۜۘۥۧۦۘۦ۟ۜۧۥۖۘۜۜۢۗۜۢۨ۬ۡۖۨۡۖۥۡ۬ۘۖۘۘ۟ۛ"

    :goto_11b
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v12

    xor-int/2addr v12, v4

    sparse-switch v12, :sswitch_data_2be

    goto :goto_11b

    :sswitch_124
    const-string v3, "ۧۘۜۘۗۗ۫ۧۦۨۧۙۢۦ۟ۛۛۤۘ۫ۖۢۥۥۖۖۖۥۗۥۖۗۗۡ۬۟۟ۚۛۨۢۖ۫ۤ۫ۨۡۦۥۘ"

    goto :goto_11b

    :sswitch_127
    const-string v3, "ۢۤۛۨ۟ۢۡۘۜۘۗ۬ۗ۬ۨۗۚ۟ۢ۟ۜۗۢ۟ۜۚ۠ۧ۫ۜۘۧۖۢۨۦۘ۠۟ۨۙۥۘ۬۬ۨۦۤۦۘ"

    goto :goto_11b

    :sswitch_12a
    const v12, 0x6291b509

    const-string v3, "ۜۖۡۚ۬۠ۥۦۖۜۨۖ۟ۨۘۜۦۚۧۙۗۤۗۚۛۧۚۖۥ۠۠ۖۘۘۦ"

    :goto_12f
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v13

    xor-int/2addr v13, v12

    sparse-switch v13, :sswitch_data_2d0

    goto :goto_12f

    :sswitch_138
    const-string v3, "ۗ۟ۨۘ۬۟ۨۘۦۧۖۡۛۜۦۤ۫۬ۢۜۜۘۜ۠ۦۘۗۦۤ۠ۛۨۖۧۚۧ۬ۜۘ"

    goto :goto_12f

    :cond_13b
    const-string v3, "۫ۖۨۘۧۜۘۤۖۨ۠ۨۘۨۥۨۤۘ۠ۦۧۜۢ۫ۢ۬ۚۦۘۚ۠ۨۘ"

    goto :goto_12f

    :sswitch_13e
    invoke-static {}, Lcom/topjohnwu/superuser/Shell;->rootAccess()Z

    move-result v3

    if-nez v3, :cond_13b

    const-string v3, "ۥۦۗۜۖ۟۠ۢۦۘۜۦۚ۟ۙ۬ۡۖۦۘ۟ۡ۬ۗۗۛۢۘۢۢۢۢۛۡ۬ۥۗۡ۬۫ۨۙۛ۫ۥۘ۬ۗۨ۟ۢۦۡۡۖ"

    goto :goto_12f

    :sswitch_147
    const-string v3, "ۙ۠۬ۨۥ۬ۜۦۥۜۖۘۛۗۛۙۧۛۡۚۘۛۤۜۘۚۥۚ۫ۡۢ۬۬ۗۡۜۦۗ۬۫ۗۛۖۘ۫ۛ۟ۧۤۜ"

    goto :goto_11b

    :sswitch_14a
    const-string v3, "ۖۨۧۗۦۖۖۚۜۛۨۦۢۤۖۘۥۚۤۛۨۜۘ۠۟ۤۢ۫ۖۖۧۗۘۚۦ۟ۚۧ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_14f
    const/16 v3, 0x8

    move-object/from16 v0, v24

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v3, "ۜۙ۠ۜۧۧۛۖۧۚۗۛ۫ۖۙۘۜۧۘۖۛۜۘ۫ۥۧۗ۫ۗۢۧۚ۫ۨۡ۠۠ۖۘ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_15b
    const/4 v3, 0x0

    move-object/from16 v0, v24

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v3, "ۨۤۢ۠ۡۦۘۨۤ۠۫ۛۧۤ۠ۦۚۥۦۘ۬ۡۧۘ۟ۘۨۘۗۛ۠ۛۖۚۙۜۗ۟۫ۨ۟ۡۜۘۗ۬ۜۚ۟ۗ۟ۜۡۛۧۗۗ۟ۡۘ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_166
    new-instance v3, Lpubgm/loader/activity/MainActivity$1;

    move-object/from16 v0, p0

    invoke-direct {v3, v0}, Lpubgm/loader/activity/MainActivity$1;-><init>(Lpubgm/loader/activity/MainActivity;)V

    move-object/from16 v0, v23

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "ۤ۫۠۠۬۫ۨۜۥۦۡۚۜۖۘۙۡۨۘۦۙۡۤۚۡۨۥ۠۫ۗۗ۬ۡۤۧۜۗ۠ۢ۠ۥۤ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_177
    new-instance v3, Lpubgm/loader/activity/MainActivity$2;

    move-object/from16 v0, p0

    invoke-direct {v3, v0}, Lpubgm/loader/activity/MainActivity$2;-><init>(Lpubgm/loader/activity/MainActivity;)V

    move-object/from16 v0, v22

    invoke-virtual {v0, v3}, Landroid/widget/RadioGroup;->setOnCheckedChangeListener(Landroid/widget/RadioGroup$OnCheckedChangeListener;)V

    const-string v3, "۫۟ۛۘ۠۟ۧۤۗۙۢۡۘۘ۫ۨ۠ۜۖۘ۠۟۫ۗ۟ۥۘۦۘ۠ۤۘۘۗ۫ۜۙۛۦۛۢۨۥۡۚ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_188
    new-instance v3, Lpubgm/loader/activity/MainActivity$3;

    move-object/from16 v0, p0

    invoke-direct {v3, v0}, Lpubgm/loader/activity/MainActivity$3;-><init>(Lpubgm/loader/activity/MainActivity;)V

    move-object/from16 v0, v21

    invoke-virtual {v0, v3}, Landroid/widget/RadioGroup;->setOnCheckedChangeListener(Landroid/widget/RadioGroup$OnCheckedChangeListener;)V

    const-string v3, "۬ۜۨ۠ۤۗۥۜۜۦ۫۠۫ۜۛۘۙۜۘۛۖۜ۬ۖۧ۫ۗۛۢۦۦۦ۟ۤۦۥۡ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_199
    new-instance v3, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda4;

    move-object/from16 v0, p0

    move-object/from16 v1, v26

    move-object/from16 v2, v25

    invoke-direct {v3, v0, v1, v2}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda4;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/ImageView;Landroid/widget/ImageView;)V

    move-object/from16 v0, v26

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "ۜۜ۫۬ۖۡۧۖۘۙۖۖۗۖۖۚۛ۠ۗۗ۫۬ۜۦۥۥۘ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_1ae
    new-instance v3, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda5;

    move-object/from16 v0, p0

    move-object/from16 v1, v26

    move-object/from16 v2, v25

    invoke-direct {v3, v0, v1, v2}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda5;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/ImageView;Landroid/widget/ImageView;)V

    move-object/from16 v0, v25

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "ۧۥۥۡۜۢۛ۫ۙ۟ۜۡۘۡۙۨۜۗۙۗ۟۠۬۠ۥۜۥۘۖۡۨۨۙ۠ۖۜۥ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_1c3
    new-instance v3, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda6;

    move-object/from16 v4, p0

    invoke-direct/range {v3 .. v11}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda6;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/ImageView;)V

    invoke-virtual {v5, v3}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "ۤۙۜۡۨۧۘۧۘۜۗ۫ۗۥ۬ۤۢۡۘۛۤۜۚۥۧۘۙۢۙۚۖۢۛ۟۠ۙ۟۫ۤۛۤۨ۠ۖۨۘۛۦۦۡ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_1d2
    new-instance v12, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda7;

    move-object/from16 v13, p0

    move-object v14, v6

    move-object v15, v5

    move-object/from16 v16, v7

    move-object/from16 v17, v8

    move-object/from16 v18, v9

    move-object/from16 v19, v10

    move-object/from16 v20, v11

    invoke-direct/range {v12 .. v20}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda7;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/ImageView;)V

    invoke-virtual {v6, v12}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "ۧۚۦۥۙۥۘ۫ۜ۬ۜ۠ۨۘ۠۟ۖۥۚ۠ۢ۬ۖ۟ۧۨۦۗۡۙۜۨۘۘۖ۬ۗۗۦۘۥۢۡۘۚۥۘ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_1ed
    new-instance v12, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda8;

    move-object/from16 v13, p0

    move-object v14, v7

    move-object v15, v6

    move-object/from16 v16, v5

    move-object/from16 v17, v8

    move-object/from16 v18, v9

    move-object/from16 v19, v10

    invoke-direct/range {v12 .. v19}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda8;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    invoke-virtual {v7, v12}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "ۥ۬۬ۚ۟ۛ۫ۜۖۢۧۡۧۘۨۦۡۥۘ۫۟ۘۚۥۨۘۜۖۦۘۢ۫ۗۙۢۨۘۖۘۧۘ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_206
    new-instance v12, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda9;

    move-object/from16 v13, p0

    move-object v14, v8

    move-object v15, v6

    move-object/from16 v16, v7

    move-object/from16 v17, v5

    move-object/from16 v18, v9

    move-object/from16 v19, v10

    invoke-direct/range {v12 .. v19}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda9;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    invoke-virtual {v8, v12}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "ۙۤۦۘ۬ۢۚۤۨ۠ۚۦۙ۟۫ۖۘۡ۫ۜۘۙۥۛۙۡۙۚۜۘۚۖۦۘ۫۟ۤۡۢ۠ۚ۬۬ۦۖۨۘ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_21f
    new-instance v12, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda10;

    move-object/from16 v13, p0

    move-object v14, v9

    move-object v15, v6

    move-object/from16 v16, v7

    move-object/from16 v17, v8

    move-object/from16 v18, v5

    move-object/from16 v19, v10

    invoke-direct/range {v12 .. v19}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda10;-><init>(Lpubgm/loader/activity/MainActivity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    invoke-virtual {v9, v12}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v3, "۠ۚ۠ۗ۫ۨ۟ۙۛۤ۠ۦۘۡۥۥۘ۟ۗۤۗۘۘۘۤۚۘۘۡۡۖۘۜۘۖۘۥۛۤۤۖ۠ۨۡ۬ۖۢۙ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_238
    const-string v3, "ۤۧۥۘ۟ۖۖۡۖ۠ۘ۫۟ۜۖۖۢ۠ۖۘ۟ۛۗۙۜۦۖ۠ۜ۠ۗۗ۫ۨ۟۫ۚۥ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_23d
    const-string v3, "ۨۤۢ۠ۡۦۘۨۤ۠۫ۛۧۤ۠ۦۚۥۦۘ۬ۡۧۘ۟ۘۨۘۗۛ۠ۛۖۚۙۜۗ۟۫ۨ۟ۡۜۘۗ۬ۜۚ۟ۗ۟ۜۡۛۧۗۗ۟ۡۘ"

    move-object v4, v3

    goto/16 :goto_1e

    :sswitch_242
    return-void

    nop

    :sswitch_data_244
    .sparse-switch
        -0x7d5e9246 -> :sswitch_242
        -0x5a71ea58 -> :sswitch_74
        -0x4d3f0d8e -> :sswitch_188
        -0x48f3ba0d -> :sswitch_83
        -0x35ee5baa -> :sswitch_1ae
        -0x2fbb6b83 -> :sswitch_1d2
        -0x28c8a9e8 -> :sswitch_36
        -0x25ce619d -> :sswitch_199
        -0x22bf16f6 -> :sswitch_21f
        -0x1d535586 -> :sswitch_14f
        -0x1c1ee845 -> :sswitch_46
        -0x13849c00 -> :sswitch_1ed
        -0x1112c31b -> :sswitch_92
        -0xd24ff24 -> :sswitch_177
        -0x7b0a505 -> :sswitch_166
        0x15936bf -> :sswitch_e4
        0x2170d8a -> :sswitch_d4
        0x125bcdb3 -> :sswitch_a2
        0x14796ac8 -> :sswitch_b2
        0x17a9a3ba -> :sswitch_105
        0x18f04478 -> :sswitch_65
        0x316ec6fd -> :sswitch_1c3
        0x3b59016a -> :sswitch_c3
        0x3bbb09f6 -> :sswitch_56
        0x3e6a105f -> :sswitch_23d
        0x441d8dea -> :sswitch_116
        0x62dbc258 -> :sswitch_32
        0x697694b9 -> :sswitch_f4
        0x75426123 -> :sswitch_15b
        0x7bad3cb3 -> :sswitch_206
    .end sparse-switch

    :sswitch_data_2be
    .sparse-switch
        -0x5d2a8a11 -> :sswitch_12a
        0x29d246a -> :sswitch_14a
        0x9e6a444 -> :sswitch_238
        0x5738c892 -> :sswitch_124
    .end sparse-switch

    :sswitch_data_2d0
    .sparse-switch
        -0x386b0ea2 -> :sswitch_127
        0x1c3fd548 -> :sswitch_138
        0x28c710c7 -> :sswitch_13e
        0x62316956 -> :sswitch_147
    .end sparse-switch
.end method

.method initMenu2()V
    .registers 15

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x0

    const-string v0, "۬ۜۨۙۙۥۘ۟ۗ۠ۚۦۦ۫ۦۘۘ۠ۖۢۛ۠ۧۦۗۜۘۚۗۦۘۚۧۜۘ"

    move-object v1, v0

    :goto_d
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v12, 0x1ad

    xor-int/2addr v0, v12

    xor-int/lit16 v0, v0, 0x155

    const/16 v12, 0x391

    const v13, -0x5348d8a2

    xor-int/2addr v0, v12

    xor-int/2addr v0, v13

    sparse-switch v0, :sswitch_data_1d8

    goto :goto_d

    :sswitch_21
    const-string v0, "ۡۖۢۧۙۤۛۗۚ۠ۗۦۛۙۢۤۛۜۧ۠ۥۡ۫۠ۡۖۧۡۡۛۡۛۙ۠ۗۧۘۗۨۘۖۡۗۦۦۘۥۡ۬"

    move-object v1, v0

    goto :goto_d

    :sswitch_25
    const v0, 0x7f0901fb

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    const-string v0, "۠ۧۨۦۢۡۘۨۢۨۘ۬ۘۙۤۛۜۘۡ۬ۡ۟ۢۙۤۜۤۛۤۖۙۧ۫ۦۖۘۥۘۨۘۜ۫ۦۘۨۢۢ"

    move-object v1, v0

    goto :goto_d

    :sswitch_32
    const v0, 0x7f0903a7

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "ۘۘ۫۠ۙۤۡۜۖ۟ۖۛ۬ۘۨۙۦۗۜۨۘۘۧۙۡۙۡۦ۫۠ۙۛ۠ۥۘ۟۟ۥۘ"

    move-object v11, v0

    goto :goto_d

    :sswitch_3f
    const v0, 0x7f0902b5

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "ۥ۠ۖۘۘۗۦۘۦۚ۫ۥۧۨۘۜ۬ۦ۠ۤۥۡۚۥۖۥۦ۬ۨۘ۫ۜۜۘۜۡۗ۬ۥ"

    move-object v10, v0

    goto :goto_d

    :sswitch_4c
    const v0, 0x7f09013f

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "ۘۛۧۖۙۦ۠ۜۜۘۙۖۖۡ۫ۧۧۧ۟۟۟ۦۘ۠ۦۢۥۗۜۚۛۦۥۖۢۜ۟ۡۧۙۘ۠ۗۘ۠ۚ۟ۘۥۛ"

    move-object v9, v0

    goto :goto_d

    :sswitch_59
    const v0, 0x7f09027b

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "ۡ۫ۥۦۚ۬ۢۥ۟ۚ۠ۖۘۤ۬۬ۛۗۨۢۡ۠ۧۦۥۘۢ۫۬ۨۥۡۘۚۜۧۘ۬ۥۖ۠ۛۖ۬ۚۧۘۚۖۘۗۚۗ۫ۤ۫"

    move-object v8, v0

    goto :goto_d

    :sswitch_66
    const v0, 0x7f0901f1

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "۫۠ۙ۬ۢۥۘۛۛۙۨۜۦ۫ۦۧۚ۠ۘ۠ۜۖۙۙۖۜ۟ۨۤ۬ۢۦ۫ۤ۟ۚۨۧۘۧ۟ۖۘۢۦ۠۟ۥۘ"

    move-object v7, v0

    goto :goto_d

    :sswitch_73
    sget-object v6, Lpubgm/loader/activity/LoginActivity;->USERKEY:Ljava/lang/String;

    const-string v0, "ۤۥۧۘۖۧۥۘۥۨۚۦۧۘۜۤۨ۫ۖۘۡۖۛۨ۟ۖ۫۟ۨۘ۟ۜۘۘۙۘۢۛۦۘ۟ۚۦۘۢۙۦ۬ۖۡۘۛۥۘ"

    move-object v1, v0

    goto :goto_d

    :sswitch_79
    const-string v0, "ۙۧۦۘۢۥۧۘۧ۟۠ۤ۠۫ۚۧ۠ۜۤۥۚۗ۫ۜۘ۠ۨۜ۠ۜۤ۫ۤۦۘۦ۠ۢۦۖۜۚۥۘۘ۠۠ۖ۟ۦۖۘ"

    move-object v1, v0

    move-object v5, v6

    goto :goto_d

    :sswitch_7e
    const v1, -0x556a2c6b

    const-string v0, "ۤۨۧۘ۫۫ۙۢۢۖۘۚۧۤۚۜۡۡۡۙۘۤۥۘۧۜۨۙ۠ۚۡۧۦۘ۫ۥۤۡۘۘۚۡۘۚ۟ۜۘ"

    :goto_83
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v12

    xor-int/2addr v12, v1

    sparse-switch v12, :sswitch_data_24a

    goto :goto_83

    :sswitch_8c
    const-string v0, "ۢۧ۬ۦۙۘۘۦۘۖۨۘۘۢۛۜۘۥۥ۠۬ۚۘۘۤۖۖۘۦۨۘ۠ۧۚۨۜۚۨۢۧۘ۬۬ۘۛۤ۫ۢۛ۬۫"

    goto :goto_83

    :sswitch_8f
    const-string v0, "ۧۖۗۡۤۜۘۙۢۛۘ۫۬ۨۖۘۧۡۗۡۗۛۥۢۥۘۛۧۖۥۙۖۘ۫ۚۘۘ۠ۜۜۘۜۜۡۘۘۛۛ"

    goto :goto_83

    :sswitch_92
    const v12, 0x3c5273f2

    const-string v0, "ۚۧ۟ۨ۟ۘۡۛۚۡۦۦۘۨۨۖۘۥۘۨۘۦۨ۫ۧۡۛۡۧ۫۠ۤۤۜۦۛۛۥۦ"

    :goto_97
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v13

    xor-int/2addr v13, v12

    sparse-switch v13, :sswitch_data_25c

    goto :goto_97

    :sswitch_a0
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v13, 0x2

    if-le v0, v13, :cond_aa

    const-string v0, "ۖۜۗ۬ۚۛۚۘۨۧۢۜۘۙۧۢۘۨۘۜۘۦ۫ۡۘۧۢ۠ۛ۠ۡۦۨۖۘۛ۠ۜۘۢۥۦۘۜ۠ۦ۟۠ۦۘۥۚۖۘ۠۟ۦ۠ۖۚ"

    goto :goto_97

    :cond_aa
    const-string v0, "ۗ۟۠۬ۨۜۘۢ۠ۙ۬ۛ۫ۡۧۚۢۡۘۘۙۢ۫۠ۧ۠ۡۦۖۘ۬۟ۜۘۢۖۜۘۙۢۦۘۖۨۚۦۤۖۘ"

    goto :goto_97

    :sswitch_ad
    const-string v0, "ۨۛۖۘ۠۠ۦۘۦۙ۬ۘۗۧۧۦۜ۫ۘۜۥۛۦۖۗۛۚ۫ۖۚۧۡۘۤ۬ۖۘۚۗۛ۟ۙۨۘۛۨۛۧ۠ۚۙۘ۬"

    goto :goto_97

    :sswitch_b0
    const-string v0, "ۨۗۘۘۢۙۥۜۥۡۘ۬ۤۖۘۨۘۖۛۥۨۙۤۘۧۢۛۙۜۜۖ۟ۡۘۘۙ۟ۖۗۧۡۘۥ"

    goto :goto_83

    :sswitch_b3
    const-string v0, "ۖ۫ۜۘۚۢ۟ۗ۠ۜۘۗۥۘۘۛۘۗ۬ۚۘۚۙۧۛۡۘۨۦۦۘۥۡۦ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_b8
    const/4 v0, 0x0

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x4

    invoke-virtual {v6, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const-string v0, "ۧۘ۬ۢۗۡۘۜۜۘۘۖۨ۟۫ۙ۟ۤۤۖۘۛۨۖۛۦ۠ۥۨۘۜۧۧۦۛۜۧۙۦ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_c8
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-wide v12, -0xd32a1f03c3a53bdL

    invoke-static {v12, v13}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v0, "ۜۥۥۡۗۤۙۗۨۧۨۚۤۜۜۘۤ۟ۛۡۘۘۘۖۘۖۘۙ۬ۛۡۢۘۘۥۡ۟ۥ۠ۙۨۙۤۡۙۖۧۗۧۙۢ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_e7
    const-string v0, "ۤۛۖۘۙ۬ۙۥۗۖۘۚۖۡۘ۬۬ۜۘۘ۠ۤۨۤۛۧۜۗۡۘۨۚ۠ۗۖۥۧۥ"

    move-object v1, v0

    move-object v5, v3

    goto/16 :goto_d

    :sswitch_ed
    invoke-virtual {v11, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۘ۠ۥۡ۠ۗۨ۠ۚۥ۟ۤۙۙ۠ۗۦۘۨ۫ۡۘۚۥ۠۟۠ۘ۬ۚۥۘۛۥۦۖۗۢ۟ۘۥ۫۠۫"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_f5
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "۫۟ۖۡۡ۫۠ۧۨ۫۠ۖۥۛۧۥۚۢۦۥ۬ۦۘۜۜۧۘۚۧۖۘۦۙۤۚۙ۟۠ۚۧ۟۠"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_ff
    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۧۦۨۘ۫ۗ۬ۛۨۨۘۨۡۘۗۨۖۘ۠۠ۖۘۖۢۦۜ۬ۨۘۘۙۦ۟ۨ۫ۖ۟۫ۤۦ۫۫ۡۙۡۥۡۘO۟ۛۦۘ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_109
    const-wide v0, -0xd32a1fb3c3a53bdL  # -1.002605132262326E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "۠ۦۙۦۡۙۜۡۨۦۤ۬ۘۗۡۖ۠ۢۜۖۖۘ۬ۡ۬ۤۛۤۢۥۤ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_11e
    invoke-virtual {p0, v10}, Lpubgm/loader/activity/MainActivity;->StartCountDown(Landroid/widget/TextView;)V

    const-string v0, "ۢ۠ۛۘ۫ۘۘۖۗۘۘ۬ۨۛۘ۫ۖ۠ۖۘۛۘ۟ۛۥۘ۫ۥۜۘۜۗۨۘۤۨ۠ۘۥۙ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_126
    const v0, 0x7f0903a0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda0;-><init>(Lpubgm/loader/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v0, "ۛۚ۬ۤۤۜ۟ۛۖۙۥۦۥۡۡۡۦۙۡۨۚۚۡۦۥۜۨۘۧ۫ۤۙۖۢۧ۫ۨۧۛۥۘ۟۬ۛۙ۠ۧۤۛۧ۠ۙ۟ۦۘ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_13a
    const v0, 0x7f0903a0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda11;-><init>(Lpubgm/loader/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const-string v0, "ۥ۠ۙۙ۫۟۬ۚۤۤۗۡۘۖۦۜۨۨۡۘۥۛ۫ۥ۫ۖۘۗۢۡۘۦۤۗۥۛۨۘ۟۬ۨۘ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_14e
    const v0, 0x7f090171

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda12;

    invoke-direct {v1, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda12;-><init>(Lpubgm/loader/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v0, "ۨۚ۠ۡۙۘۜۧۘۚۖۦۨۧۦۡ۠ۛ۫ۦۙۙۥۧۘۧ۠ۗۨۧۛ۬ۢۖۜ۫ۤ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_162
    const v0, 0x7f090171

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda13;

    invoke-direct {v1, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda13;-><init>(Lpubgm/loader/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const-string v0, "ۜۖۥۘ۠۠ۨۘۧۖ۟ۢۜۘ۠ۗۡۨۤ۟ۖۙۖۛۥۘۥۚۚ۬۟ۨۘۡۘۥۘۙۗۥۘۘۨۧۘ۠ۤۨۤۦ۠۬ۦ۟ۤ۫ۥۤۦ۠"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_176
    const v0, 0x7f0901d2

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda14;

    invoke-direct {v1, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda14;-><init>(Lpubgm/loader/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v0, "ۜۖۡۦۚۡۘ۟۬ۦۘۧۙۦۘۦۙۡۗۥۨۗۛۖۤۛۘۢۘۧ۬ۦۘۡۥۚۥۗۚۨۡۦۘۚۨۛۨۗۥ۠ۚۡ۠ۘۛۡۦۖ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_18a
    const v0, 0x7f0901d2

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda15;

    invoke-direct {v1, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda15;-><init>(Lpubgm/loader/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const-string v0, "ۜۨ۟ۙۘۦ۠ۥۘۧۚۗۢۘ۫ۡۘۢۦ۟۬ۙۖۘۦۡ۬۬ۛ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_19e
    const v0, 0x7f0901af

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ToggleButton;

    const-string v1, "ۙۚۡۧۦۢۨ۟ۗ۫ۚۥ۟ۖۖۖ۟ۤ۫۫ۡۘۡۗۗۙ۟۟ۤ۟ۤۙۨ۬ۜۖۤۥۡۘۘۜ۫ۘۘ"

    move-object v2, v0

    goto/16 :goto_d

    :sswitch_1ac
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getPref()Lpubgm/loader/utils/FPrefs;

    move-result-object v0

    const-wide v12, -0xd32a1e03c3a53bdL

    invoke-static {v12, v13}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lpubgm/loader/utils/FPrefs;->readBoolean(Ljava/lang/String;)Z

    move-result v0

    invoke-virtual {v2, v0}, Landroid/widget/ToggleButton;->setChecked(Z)V

    const-string v0, "ۗۡۥۘۙۢۧ۬ۛۦ۫ۛ۫ۗۛۦۘ۟ۖۜۘ۬ۛۖۘ۬ۜ۟ۘ۬ۦۖۢۙ۫۫۬۬ۚۥ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_1c5
    new-instance v0, Lpubgm/loader/activity/MainActivity$4;

    invoke-direct {v0, p0}, Lpubgm/loader/activity/MainActivity$4;-><init>(Lpubgm/loader/activity/MainActivity;)V

    invoke-virtual {v2, v0}, Landroid/widget/ToggleButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const-string v0, "ۘۛۚۙۛۥۖۙۙۖۙۢۧۢ۠۫۫ۡ۟ۤۘۘۙۥۨۡۨ۟ۡۖۜ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_1d2
    const-string v0, "ۤۛۖۘۙ۬ۙۥۗۖۘۚۖۡۘ۬۬ۜۘۘ۠ۤۨۤۛۧۜۗۡۘۨۚ۠ۗۖۥۧۥ"

    move-object v1, v0

    goto/16 :goto_d

    :sswitch_1d7
    return-void

    :sswitch_data_1d8
    .sparse-switch
        -0x7f5864f1 -> :sswitch_f5
        -0x7e608f03 -> :sswitch_126
        -0x7a164d16 -> :sswitch_1ac
        -0x75358c7c -> :sswitch_21
        -0x731e1dc6 -> :sswitch_c8
        -0x71757bae -> :sswitch_ff
        -0x65083190 -> :sswitch_b8
        -0x52dabccc -> :sswitch_11e
        -0x4ddd2c93 -> :sswitch_25
        -0x4654d2a3 -> :sswitch_162
        -0x443cd07b -> :sswitch_59
        -0x3ff8b300 -> :sswitch_109
        -0x1b82a7fc -> :sswitch_4c
        -0x1ae619c5 -> :sswitch_73
        -0x1846939b -> :sswitch_18a
        0x9c0d1 -> :sswitch_176
        0x263fe685 -> :sswitch_79
        0x27f99dca -> :sswitch_3f
        0x2cadc882 -> :sswitch_1d7
        0x2d35629b -> :sswitch_7e
        0x2e7dab80 -> :sswitch_66
        0x41b2d461 -> :sswitch_32
        0x581f0fa0 -> :sswitch_e7
        0x5a4686d8 -> :sswitch_13a
        0x61e3adeb -> :sswitch_ed
        0x78dbc86a -> :sswitch_19e
        0x79ea2cf8 -> :sswitch_14e
        0x7ec51241 -> :sswitch_1c5
    .end sparse-switch

    :sswitch_data_24a
    .sparse-switch
        -0x6bea211c -> :sswitch_8c
        -0x62013c74 -> :sswitch_92
        -0x7d60f6e -> :sswitch_b3
        0x1ee5e27b -> :sswitch_1d2
    .end sparse-switch

    :sswitch_data_25c
    .sparse-switch
        -0x567228e7 -> :sswitch_a0
        -0x462ed37f -> :sswitch_b0
        0x1e9152d5 -> :sswitch_ad
        0x7929fd7c -> :sswitch_8f
    .end sparse-switch
.end method

.method synthetic lambda$init$19$pubgm-loader-activity-MainActivity(Lcom/google/android/material/bottomnavigation/BottomNavigationView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/view/MenuItem;)Z
    .registers 14

    const/16 v8, 0x8

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v0, "۫۫ۦۧ۟ۜۘۙۜۖۘۛۚ۫۠۠۠۫ۚۜۘۜۤۘ۫ۘۘۥۚۜۘۤۚۛۥۥۛۦۗۨۘۙ۠ۘ۬۫ۡۡۖۧۨۨۙۤ۟۠۬ۖ۬"

    move v1, v2

    :goto_8
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v6, 0x2f1

    xor-int/2addr v5, v6

    xor-int/lit16 v5, v5, 0x115

    const/16 v6, 0x247

    const v7, -0x4d058550

    xor-int/2addr v5, v6

    xor-int/2addr v5, v7

    sparse-switch v5, :sswitch_data_110

    goto :goto_8

    :sswitch_1c
    const-string v0, "ۖۤۢۛۘۘۨۚۚ۟ۢ۫ۧۗۙۜۡۙۛۨۦۘۦ۠ۡۘۡۛ۫ۦ۬ۖ۟ۙۤۛۡۚۨۡۦۗۛ۟ۜۛۖۨۙۡۘ"

    goto :goto_8

    :sswitch_1f
    const-string v0, "ۦ۬ۥۘۚ۫ۙۨۨۥ۠ۦۗۗۢۧۜۡۘ۬ۥۜۘۘۨ۟۬ۤۜ۠ۗ۟۬ۢۤ۠ۗۜ۟ۛ۠۬ۗۛۗۢ۟ۥۦۘ"

    goto :goto_8

    :sswitch_22
    const-string v0, "ۘ۬۫ۘۦۗۡۡۧۘۘۖۧۜۤۨۘۘۜۧۤ۬ۨۘۗۙۨۥۘۜۚ"

    goto :goto_8

    :sswitch_25
    const-string v0, "ۢۗ۠ۥۗۙۦۤۘۦۡۜۘۤۡ۫ۖۘۨۘ۟ۘ۟ۦۢۦۡۙۛۙۨۡۜۘۦۘۗۧ۫۠ۨ۠ۜۤۘۘ"

    goto :goto_8

    :sswitch_28
    const-string v0, "ۚۦۢۧۙ۟ۚۖۘۡۛۖۘۧ۬ۦۚۦۡۘ۫ۜۙۛۥۡۡۜۗۢۜ۟ۤۛۚ۫ۛۦۙ۬ۥۥۛۡۢۨۘ"

    goto :goto_8

    :sswitch_2b
    invoke-interface {p4}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/google/android/material/bottomnavigation/BottomNavigationView;->findViewById(I)Landroid/view/View;

    move-result-object v3

    const-string v0, "ۦۧۖۤۗ۫۟ۧۦ۟۠۫ۡۛۥۗۧۡۨۢۚۢۤۜۘ۫ۡۖۘۢۨۦۨۚۖۘ۟ۨ۠ۧۥۦۦۦ۬ۚۜۢۛۦۧ"

    goto :goto_8

    :sswitch_36
    const v5, 0x17f7835e

    const-string v0, "ۦۚۗۥ۟ۖۘۘۧۜۜۡ۟ۢۧ۫ۙۛۢۚۘۡۘۥۚۦۘۡۢۖۚۡۜۘۚۖ۫ۙۨۦۘۖۨۚۡۗۨۘ۠ۛ۫ۡۜۦۢۘ۫ۜ۬ۚ"

    :goto_3b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_15a

    goto :goto_3b

    :sswitch_44
    const-string v0, "۬ۜۥۘۗ۬ۥۘۖۚۘۦۛۗ۟۠ۦۗۜۡۢۙۥۜ۟ۚۢۖۘۘ۠ۧۤۜۛۙ۫ۦ"

    goto :goto_8

    :sswitch_47
    const-string v0, "ۖۜۖۤۜۙ۟ۡۨۧۡۙۗۤۨۨۡۜۘۦۥۥۨ۫ۥۧۙۨۛ۠ۧ"

    goto :goto_3b

    :sswitch_4a
    const v6, -0x65c4ea18

    const-string v0, "ۧۢۗ۟۠ۦۗۧۦ۫ۧۚۙۤۚۤ۫ۦۘۦ۠ۡۗۡۘۨۢ۬ۧۚۥۜۦۘۤۙۥۥ۬ۥۘ۬۟"

    :goto_4f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v6

    sparse-switch v7, :sswitch_data_16c

    goto :goto_4f

    :sswitch_58
    if-eqz v3, :cond_5d

    const-string v0, "۬۬ۤۜۖۦۘۚۖۤۦ۫ۚۛۙۨ۫ۤۥۧۢۗۨۤۥ۠ۥ۫۟ۤۥۧۡۗۙۛۨۢۘ۟ۦۥۘ"

    goto :goto_4f

    :cond_5d
    const-string v0, "ۜۢۧۜ۟ۖۚۡۧۧۖۦۘۡۡ۟۬ۜۧ۟ۦۥ۫ۖۜ۬ۤ۬ۦۖۦۘ"

    goto :goto_4f

    :sswitch_60
    const-string v0, "ۧ۬ۥۘۘۥۨۧۥۘۦۚۗ۫ۥۜ۟ۧۜۥۙۡۦۗۦۘۦۢۖۙۨۥۧۘۖۙ۠ۥۘۦۙۨ۟ۛۜ"

    goto :goto_4f

    :sswitch_63
    const-string v0, "ۗۚ۠ۛۦۤۘۧ۫ۚۘۜۘۛۚۖ۟۬ۛۤ۬ۡۘۙۗۥۘۢ۬۫ۗ۟ۧ"

    goto :goto_3b

    :sswitch_66
    const-string v0, "ۧۦۡۘۛۙ۬ۖۨۘۗ۫ۡۘۗۗ۟ۨۧۡ۟ۥۜۘۧۦۜۛۨۘۚ۠ۥۘ۠۠ۛۨ۫۬ۛ۬ۢۨۜۘۨۘۡۘۤ۟ۦ"

    goto :goto_3b

    :sswitch_69
    const-string v0, "ۡۦۧۨ۬ۛۤۙۡۘۥۤۙۢۗۛۚۡۚۡۚۙۖۤۖۘۢۥۥۘۥۙۨۖۛۛ۟ۚۙ"

    goto :goto_8

    :sswitch_6c
    invoke-direct {p0, v3}, Lpubgm/loader/activity/MainActivity;->animateNavItem(Landroid/view/View;)V

    const-string v0, "۬ۜۥۘۗ۬ۥۘۖۚۘۦۛۗ۟۠ۦۗۜۡۢۙۥۜ۟ۚۢۖۘۘ۠ۧۤۜۛۙ۫ۦ"

    goto :goto_8

    :sswitch_72
    invoke-interface {p4}, Landroid/view/MenuItem;->getItemId()I

    move-result v1

    const-string v0, "۟ۘۦۘۡۗۘۢ۟۟ۗۨۖۘۤۜۥۘۦۚۡۘۦۡۖۙۗۨۨۗ۟۠ۤ"

    goto :goto_8

    :sswitch_79
    const v5, 0x6bb23800

    const-string v0, "ۧۚۛۤ۬ۦۢۙۥۘۖۧۘۤۤۨۥۧۤۨۨۜ۟ۢ۬ۜ۠ۗۙۢۡ۠ۘۘ۬ۗ۟ۖۘۖۜ"

    :goto_7e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_17e

    goto :goto_7e

    :sswitch_87
    const v6, 0x7a232694

    const-string v0, "ۖۘۜ۬ۗ۬۠ۥ۫ۤۧۖۦ۟ۗۜۘۘۦۛۢۡ۫ۜ۟ۨۦۗۢۜۘۤۜۚۙۖۖۘ"

    :goto_8c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v6

    sparse-switch v7, :sswitch_data_190

    goto :goto_8c

    :sswitch_95
    const-string v0, "ۙۧۚ۟ۥۦ۠ۢۘ۟ۚۨۥۙ۠۠ۥ۠ۥۖ۫ۖۧۡۜۦۦۖ"

    goto :goto_7e

    :cond_98
    const-string v0, "ۨۡۡ۫ۡ۫ۚ۫ۛ۬ۤۗۢۖۦ۬ۜ۫ۨۖۥۚۤۤۛۢۤۘۦۗۘۖۜ۠ۜۚ۠ۡۨۤۥۥۘ"

    goto :goto_8c

    :sswitch_9b
    const v0, 0x7f09025f

    if-ne v1, v0, :cond_98

    const-string v0, "ۧۦ۟۠ۡۖۘۧۨۜۘۨۦۢ۟ۦۗۛۜۥۥۘ۬ۧۥۘۥۤۥۘۘۡۨۡۖۙۘۧۚۥۦ۫ۥۧۦۘۜۖۦۘۦۜۜۘ"

    goto :goto_8c

    :sswitch_a3
    const-string v0, "ۥ۟۬ۤۥۙۙۚ۫ۙۜۘۗۥۥۤ۬۠۠ۚۛۤۤۧۢ۫ۧۢۡۢۤۖۜ۫ۢۥۘ۟ۢۧۗۨ۫ۗۘۗۤۧۤۨ۬ۨۘ۠ۨۘ"

    goto :goto_8c

    :sswitch_a6
    const-string v0, "ۜۛۥۗۘۙۙۘ۬ۤۙۙۢۢ۫ۚۧ۠ۜۘۤۖ۫ۛۦۘۖۖۘۨ۫ۥۘۥ۫۫ۙۚ۠ۧ۠۬"

    goto :goto_7e

    :sswitch_a9
    const-string v0, "۟ۤۗ۟ۖۘۛۦۖۘۥۘۧۘۢۧۨۜۙۗۜۚۖۘۘۦۦۘۦۢۜۘۡ۟ۙۚۙۧۗۘۖۘ۠ۤۜۘۨۗۜ"

    goto :goto_7e

    :sswitch_ac
    const-string v0, "ۡۖۙۖ۟ۧۜۨ۬ۖۧۥ۠ۖۨۧ۟۟ۘۥۘ۫ۘ۠۟ۥۦۡۥۖۚۦۢۤۖۙۜۦۘۖۢۜۘ"

    goto/16 :goto_8

    :sswitch_b0
    invoke-virtual {p2, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "ۘ۫ۖۢۡۛ۬ۛۚۡ۠۬۫ۢ۬۫ۨۢۚۙۡ۫ۖۧۘۧۚۢ۫ۚۘ۬ۥۤۡۛۛ۫ۦۨۦۦۘۧۘۜۘ۬۬ۤۦۘۚۚۤۚ"

    goto/16 :goto_8

    :sswitch_b7
    invoke-virtual {p3, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "ۨۡۦۥۘۦۨۘۧۘۗۤۗۚۨۗۥۥۘ۬ۚۡۙ۟۫۬ۡ۬ۙۥۜۘۙۥۙۚۥۥۘ۬ۘ۟ۤ۟۟ۜ۬ۦۗۜ۠"

    goto/16 :goto_8

    :sswitch_be
    move v2, v4

    :goto_bf
    :sswitch_bf
    return v2

    :sswitch_c0
    const v5, 0x20fba77f

    const-string v0, "۠ۙۨۘ۫ۦۨۘۤ۠ۜۢۦ۬ۛ۟ۛ۬ۤۙۨۥۘ۟ۢۧۢۜۖۘ۠ۖۦ۫ۧۘۧۛۨۘ"

    :goto_c5
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    xor-int/2addr v6, v5

    sparse-switch v6, :sswitch_data_1a2

    goto :goto_c5

    :sswitch_ce
    const-string v0, "ۚۧۦ۟ۢۨۖۤۜۘۥ۠ۛۗۘۥ۫ۤۨ۫ۦۥۘۜۖۛۜۡ۫ۜۙۘۘۨۗۨ۬ۖ۬ۧۗۙۘۗۖۗۦۤۤ۬ۤ"

    goto/16 :goto_8

    :sswitch_d2
    const-string v0, "ۚ۠ۡۘۛ۠ۘۧۙ۟ۜۖۤ۬ۧۖۖۗۙۛ۠ۧۤۦۘۛۧۦۘۜۛۜ۟۫ۘۖۛۡۘۛۘۚۚۚۜۚۧۗ"

    goto :goto_c5

    :sswitch_d5
    const v6, -0x64e79abb

    const-string v0, "ۢۢۡ۟ۦۙۘۧۖۥ۫۟ۤۜۡۛۗۢۘۙۜۘۚۨۙۡ۠ۜۘۡۖۖۘۙۢۖۘۗۘۖۘۗۥ۫ۗۦۘ"

    :goto_da
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v7, v6

    sparse-switch v7, :sswitch_data_1b4

    goto :goto_da

    :sswitch_e3
    const-string v0, "۬ۘۨۘۧۢۚۜ۟ۧۤ۬ۚۘ۠۠ۤۜۛۗۡۡۘۖۥۘۘۤۡۘ۫ۛ"

    goto :goto_c5

    :cond_e6
    const-string v0, "۫ۜ۬ۘ۫ۦۦۨۦۦ۠ۖۘۙۤۤۙۛۖۘۦۡۗ۬ۜ۟ۥۦۡۘۤۘۦ۟ۜۛۛۗ۟۟ۨۡۘۦۖۜۘۤ۫ۘۗۜۜۘ"

    goto :goto_da

    :sswitch_e9
    const v0, 0x7f090268

    if-ne v1, v0, :cond_e6

    const-string v0, "ۖۘۥۘۨۗۡۘ۟ۘۢۦۜۖ۟۟۬۫ۙ۫ۦۢۨۘ۬۟ۘۗۜۦۧۗۦۚۤۗۡۥۛۖ۟ۨۘۦۤۥۘ"

    goto :goto_da

    :sswitch_f1
    const-string v0, "ۗۗۘۛۜ۟۟ۜۤۡۥۘۗۢۤۦ۠ۜۘۜۡۜۘۖۘۥۛۥۚۘۙۦۘۥۥۡۘ۟ۘ۬"

    goto :goto_da

    :sswitch_f4
    const-string v0, "۠ۦۤۚۥۦۦۥ۟ۦ۠ۢۨ۟ۜۘۙۘۤۢۤۤ۠ۙۚۗۘۘ۠ۤۡۤ۫ۙۦۛ۟"

    goto :goto_c5

    :sswitch_f7
    invoke-virtual {p2, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "ۚۜۘۘۖۨۘۡۧۖۘ۟ۚۖۘۚۤ۫ۗۧۦۨۥۘۘ۟۫۟۬ۖۡۡۗۡۘۥ۫ۘۥۙۘۨ۠ۨۥ۫ۗۜ۫ۨۘۢۜۛ"

    goto/16 :goto_8

    :sswitch_fe
    invoke-virtual {p3, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const-string v0, "ۛۚۧ۬ۤۙۥۤۙۥۤۡۤ۠ۛ۬۟ۦۘۗ۬ۨۘۡۧۗۘۨۛۨۡۦۘ"

    goto/16 :goto_8

    :sswitch_105
    move v2, v4

    goto :goto_bf

    :sswitch_107
    const-string v0, "ۧۛۦۘۜ۠ۥۢۙۘۘ۬ۗۡۘۡۙۘۘ۬ۘۖۥۥۘ۫ۡۖۘۛ۫ۜ۠ۥۨۘۢ۬۠ۘۢۧۡ۠۟ۗۛۘۘۡۤ۟ۙۙۨۡۛۥۘ۫۫ۦۘ"

    goto/16 :goto_8

    :sswitch_10b
    const-string v0, "۠۠۬ۤ۫ۜ۠ۥ۟ۧ۫ۢۙۛۨۘ۟ۙۨ۟ۜ۠۠۠ۢۚۛۡ۬ۤۚۢۚۘۘۖۦۥۘۥ۫ۙۛۦۡ"

    goto/16 :goto_8

    nop

    :sswitch_data_110
    .sparse-switch
        -0x7dd3d15e -> :sswitch_79
        -0x6bac323b -> :sswitch_1c
        -0x6adcdb8a -> :sswitch_72
        -0x65d4d748 -> :sswitch_2b
        -0x60fcd0f1 -> :sswitch_6c
        -0x5f768d37 -> :sswitch_25
        -0x58d9791f -> :sswitch_22
        -0x42e6f5f0 -> :sswitch_f7
        -0x3ee9757e -> :sswitch_28
        -0x2e218cf6 -> :sswitch_c0
        -0x2aa146ab -> :sswitch_be
        -0x954302 -> :sswitch_105
        0x1cd9955 -> :sswitch_1f
        0x33a30bd -> :sswitch_bf
        0x2b59e397 -> :sswitch_36
        0x31aa9322 -> :sswitch_b7
        0x40f79490 -> :sswitch_fe
        0x7ebc0e7b -> :sswitch_b0
    .end sparse-switch

    :sswitch_data_15a
    .sparse-switch
        -0xe379e06 -> :sswitch_4a
        -0x1c57530 -> :sswitch_44
        0x293e9a20 -> :sswitch_69
        0x72ef7a21 -> :sswitch_66
    .end sparse-switch

    :sswitch_data_16c
    .sparse-switch
        -0x5d0448c -> :sswitch_63
        0x6b1b7b4 -> :sswitch_47
        0x22da4497 -> :sswitch_60
        0x6f7a1485 -> :sswitch_58
    .end sparse-switch

    :sswitch_data_17e
    .sparse-switch
        -0x3b7280d1 -> :sswitch_87
        -0x219b93f6 -> :sswitch_107
        -0x40b0c54 -> :sswitch_a9
        0x5c3df2ee -> :sswitch_ac
    .end sparse-switch

    :sswitch_data_190
    .sparse-switch
        -0x2909b94b -> :sswitch_a3
        -0x219a0cb0 -> :sswitch_a6
        -0x1b0d10c0 -> :sswitch_9b
        0x12675995 -> :sswitch_95
    .end sparse-switch

    :sswitch_data_1a2
    .sparse-switch
        -0x64b87a5f -> :sswitch_10b
        -0x30f0a960 -> :sswitch_f4
        0x5469d975 -> :sswitch_ce
        0x57314da4 -> :sswitch_d5
    .end sparse-switch

    :sswitch_data_1b4
    .sparse-switch
        -0x56c16b06 -> :sswitch_e3
        0x666eacda -> :sswitch_f1
        0x6a92b91f -> :sswitch_e9
        0x7b9f598a -> :sswitch_d2
    .end sparse-switch
.end method

.method synthetic lambda$initMenu1$0$pubgm-loader-activity-MainActivity(Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/view/View;)V
    .registers 8

    const-string v0, "۟ۧۙۗۘۧۨۖۨ۠ۨۧۢۥ۟ۧۚۨۙۘ۫ۦۚۥۘۛۥۜۘۨۡۥۘ۟ۚۤۨ۬ۤۗۢۙ۬۟ۚ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x16a

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x10e

    const/16 v2, 0x354

    const v3, 0x3ee95115

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_48

    goto :goto_2

    :sswitch_16
    const-string v0, "ۖۖۤۨۦۖۥ۠ۤۚۙۤۖۥۘۢ۫۟ۙۡۜۧۥۖۘۥۚۨۘۘۤۜۙۥۥۘ۠ۤ۬۟ۗۡ۟ۥۦ۠ۖۗ۟ۜۦ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۖۙۗ۫۠ۜۘۨۢۤۖۗۨۖۖۡۥۗۖۘۨۙۦۘ۠۠ۜ۬ۜۗۗۡۤۛۛۦۨۚۘۘۦ۫ۘۘ۠ۖۙ۫ۜۥۘ۬ۨۡۖۢۚۨۦۥ"

    goto :goto_2

    :sswitch_1c
    const-string v0, "ۗ۠ۜۘۜۖ۟۬ۛۖۘۦۢۨۘۘۤۘۗۨ۟ۙۧۥۘۛ۫ۡۘۥۢۛۢۗۖۘۢۗۜۛ۟ۦۦ۟۫ۘۖۢ"

    goto :goto_2

    :sswitch_1f
    const-string v0, "۫ۢۨۥۗۛ۠ۢۡۗۙۖۜۜۘۜۚۨۛۨۜۘۛ۬ۘۛ۟ۤۖ۫۟"

    goto :goto_2

    :sswitch_22
    const v0, 0x7f0700e4

    const v1, 0x7f120117

    invoke-virtual {p0, v1}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lpubgm/loader/activity/MainActivity;->toastImage(ILjava/lang/CharSequence;)V

    const-string v0, "ۚۨۧۘۢۛۖۘۥۜۧۘۖۢۢۧ۬ۘۤۚۡۘۢ۠ۦۘۢۖۦۘۢ۟۫ۥ۫ۤ۫ۡۙۨۢۥۘۛۤۦۘۘۨ"

    goto :goto_2

    :sswitch_32
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->startPatcher()V

    const-string v0, "ۗۥۖۘۦۗۢ۬ۖۙۗ۟ۧۙ۠ۤۤ۠ۡۗ۫ۨۘۨۤۨۥۥۖۘۛۗۘۨۛۗ۟ۘۘ"

    goto :goto_2

    :sswitch_38
    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const-string v0, "ۙۘۗۦۖۦۛۜ۟ۛۧۡۦۢۗۤۦ۠ۚ۠ۦۘۨۤ۟ۥ۠ۦۧۦ۫۠۠ۖ۟ۧ۠۟ۗۚۧۧ۫۠ۛۦۜۛۗ"

    goto :goto_2

    :sswitch_40
    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const-string v0, "ۙۤۘۗۦۙۧ۠ۡۘۦۡۢۙۚۛ۟ۛۗۛ۟ۡ۬ۦۛ۟۬ۜۘۤۧۦۦۨۜۘۘۥۥۛۘۜۡۜۢۜۥۦۘ۠۬ۘۜ۠ۢۗ۬"

    goto :goto_2

    :sswitch_47
    return-void

    :sswitch_data_48
    .sparse-switch
        -0x6ffe4f74 -> :sswitch_47
        -0x347f9d8f -> :sswitch_19
        -0x2f0754c2 -> :sswitch_1f
        0x14d3bf43 -> :sswitch_38
        0x194eda49 -> :sswitch_40
        0x2b1aaac7 -> :sswitch_16
        0x305165ac -> :sswitch_22
        0x602dcd8c -> :sswitch_32
        0x744b177e -> :sswitch_1c
    .end sparse-switch
.end method

.method synthetic lambda$initMenu1$1$pubgm-loader-activity-MainActivity(Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/view/View;)V
    .registers 8

    const-string v0, "ۨۦۖۘ۬ۥۨۥۜۨۘۨۧ۟ۧۙۥۘۛۢ۟ۛ۠ۢۘۙۤۨۚۖۢۖۘۘۡۘۚۢۖۨۘۛۦۥۙ۬ۜۘ۬ۨۧۜ۫ۘۘۖۗۧۨ۬ۤ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xe5

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x3d2

    const/16 v2, 0x18a

    const v3, -0x6fd71c28

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_48

    goto :goto_2

    :sswitch_16
    const-string v0, "ۚۘ۬ۚۨۖۘۜ۫ۜۘۚۗۧ۫ۜۚۢۗۜۘۥۥ۬ۚۨۡۘ۬ۙۥۢ۟ۨۘۘۡۘۜۘۘ۠ۢۡۘۖۘۘۛۦۘۚۡ۠"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۜۖۧ۠۠ۡۥۤۘۘۥۤۡ۬ۚۚۛۚۛۤۘ۫ۛۗۗۛۚۚۘۘۘۚۤۦۥۥۥۘۜۤۙۦۨۥۙۚۧۚۘ"

    goto :goto_2

    :sswitch_1c
    const-string v0, "ۧۥۘۘ۟ۜۨۘۘۗ۫ۘ۫۬ۗۛۚۚۦۥۚ۫ۥۦۘۤ۬۬ۦۘ۫ۘۖۘ"

    goto :goto_2

    :sswitch_1f
    const-string v0, "۬ۨۨ۬۠ۛۛۧۛۖۖۜۢۖۘۛ۟ۙۢۤۢۡۜۘۘ۬۟۠ۦۤۛۙۨۦۤ۟"

    goto :goto_2

    :sswitch_22
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->stopPatcher()V

    const-string v0, "ۛۢۨۖۦۡۘ۠۫ۦۜۦۥۘۛ۬ۤۧۥۘ۬ۙۜۜۨۘۗۦۦۘۢۘۨۤۧ۬۬ۦۛ۫ۘ۟ۘۥ۟ۘۢۡۘۙۡ۟۠ۥۘۚۚ۫"

    goto :goto_2

    :sswitch_28
    const v0, 0x7f0700ee

    const v1, 0x7f120119

    invoke-virtual {p0, v1}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lpubgm/loader/activity/MainActivity;->toastImage(ILjava/lang/CharSequence;)V

    const-string v0, "ۧۗۡۘ۟۟۫ۘ۟ۨ۬۠۟ۗۡۚ۬ۚۢۛۗۥۢۦۡۘۥ۫ۧۙۡۦۘۧۦۥۨۨۧۘۚۚۦۜۖۚۛۙۥۢۜۘۛۨۗ"

    goto :goto_2

    :sswitch_38
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const-string v0, "ۥۢۧۜۚۥ۫ۜۘۘ۟ۦۡۖ۫ۡۘۨۨۘۤۨۘۧۙۤۜۤ۠ۘۖۨۘۘۙ۟ۗۛۥ"

    goto :goto_2

    :sswitch_3f
    const/16 v0, 0x8

    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const-string v0, "ۥۙۙۜۥۖ۬ۖۜۙۨۘۛۨۖۤۜۚۘ۫ۖ۬ۘۗۘۥۛۧۡۨۡۖۙۢۘۨۤۧۨۤ"

    goto :goto_2

    :sswitch_47
    return-void

    :sswitch_data_48
    .sparse-switch
        -0x783d0da4 -> :sswitch_28
        -0x77ebae1a -> :sswitch_1c
        -0x372211b2 -> :sswitch_3f
        0x150d12c -> :sswitch_16
        0x1bec888 -> :sswitch_47
        0x32598605 -> :sswitch_22
        0x38862b2a -> :sswitch_19
        0x4a90460e -> :sswitch_38
        0x540de61f -> :sswitch_1f
    .end sparse-switch
.end method

.method synthetic lambda$initMenu1$2$pubgm-loader-activity-MainActivity(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/view/View;)V
    .registers 15

    const v5, 0x7f0700cb

    const/4 v1, 0x0

    const-string v0, "ۤۚۧۦۦ۫ۦ۠۬۟ۚۙ۟ۦۦۘۚۚۥۘۤ۟ۢۡۗۜ۟ۡۧۘۨۧ۟ۘۜۦۘۜۗ۠"

    :goto_6
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x2bc

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x261

    const/16 v3, 0x252

    const v4, 0x15a4faf2

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_74

    goto :goto_6

    :sswitch_1a
    const-string v0, "ۗۙۡۘۖۜۘۘ۫ۙۨۚۧۦۨۗۜۘۙۦۘۜۨۖۘۦ۫ۘۘۧۛۙۧۢ۬ۘ۟ۦۘۡۤۢ"

    goto :goto_6

    :sswitch_1d
    const-string v0, "ۤۘۧۨ۫۫ۤۦۥۘۤ۬۟ۡۡۧۘۙۢۨ۠ۗۡۘۗۡۘۡۨۤۢۨ۠ۢۜۢۗۥۦۦۘۡۖ"

    goto :goto_6

    :sswitch_20
    const-string v0, "ۢۘۛ۫ۨۤۦ۫ۙۡۗۤۛۗ۟ۛۡۥۗۜۖ۫ۖۘۘۛ۠۫ۖۨۛۨ۠ۙ۠ۧ۬ۤۘ۟ۧ۠ۢ"

    goto :goto_6

    :sswitch_23
    const-string v0, "ۛۗ۠ۤۡۡۘۨۜۖۘ۫ۙۥۘۡۤۜۧۦۜۘ۫ۡۖۘۖۡۥ۫ۧۥۦۥ۟ۦۛ۟ۦۘۡۡۘۘۡ۠۟ۤۨۙۢ۫ۡۘ۠ۚۨۘ۫۟ۡۘ"

    goto :goto_6

    :sswitch_26
    const-string v0, "ۜۘۛۥۙ۟ۥۥۨۘۖۤ۬ۡۜۨۘ۬ۢۦۘۜۗۡۧۜۦۘۥۜ۫ۛۖ۫ۘۙۙۚۤۡۘۢۙۧۤۛۘۜۨۚۤۧ۠ۨ۫ۖۘۨۨۘۘ"

    goto :goto_6

    :sswitch_29
    const-string v0, "ۗۤۡۜۨۘۤۥۨۛۧۥۚۘۦۘ۬ۜۜۘۗۡۨۧۛۢۙۦۛۡۖۘۗۗ۬۬ۜۦۚۛۜۘۙۚۧ"

    goto :goto_6

    :sswitch_2c
    const-string v0, "ۙۙۦۘۢۜۘۘ۫ۢۘۦۤ۬ۧ۟ۡۘۨۨۢۘۜۥۘۚ۟ۜۘۛۘ۟ۤۘۥ"

    goto :goto_6

    :sswitch_2f
    const-string v0, "ۢ۠ۗۜۤۜۘۢۧ۠ۖۚۙۜۛۢۚ۟ۧ۟ۧۖ۠ۧ۫ۧۤۧۜۥۘۡۧۙ۫۫ۙۜۦۨۘۡۢ"

    goto :goto_6

    :sswitch_32
    const-string v0, "ۨۨۖۘۢۘۡۦ۬ۘۗۨۥۥ۫۠ۙۥۡۘ۠ۗۦۘۜۡۨۘ۬ۧۜۡۤۜۘۡ۟۬ۖۚۘۘ۠ۨۤۧۛ۠"

    goto :goto_6

    :sswitch_35
    invoke-virtual/range {p0 .. p5}, Lpubgm/loader/activity/MainActivity;->gameversion(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "ۗۚۡۘۥۨۦۘۗۚۡۘۦۢۦۘۜۥۢۤۥۥۘۦۙ۟ۛۦۨ۟ۛ۬ۘۖۘۡ۬۟ۧۚۨۘۧۤۡۘۧۥۥ۟ۖۧۗۢۜۘ"

    goto :goto_6

    :sswitch_3b
    const/4 v0, 0x1

    sput v0, Lpubgm/loader/activity/MainActivity;->gameint:I

    const-string v0, "۬۫ۘۘ۟ۗۚ۠ۢۜۘۛۚۥۜ۫ۦۘۘۡۨۘۙ۬ۢۡۖۛۗۜۘۡۢۡ۟۫ۜۧۚۡۘۖۛۡۘۙۧ۠"

    goto :goto_6

    :sswitch_41
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->packageapp:[Ljava/lang/String;

    const/4 v2, 0x0

    aget-object v0, v0, v2

    sput-object v0, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    const-string v0, "۫ۦۘۘۥ۬ۡۘ۟۫ۦۘۥۘۖۡۘ۠ۙ۠۬ۨۦۘ۟ۨۤ۟ۙۦۘۛۦۦۘۛۜ۟۫ۥۖۘۚۛۦۘۧۛۘ"

    goto :goto_6

    :sswitch_4b
    const v0, 0x7f1200f9

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v0, "۟ۤۜۧ۫ۙ۠ۗ۬ۛۤۙۗۨۘۘ۬ۙۘۘۤۤۨۖۖۡۘ۫۫۬ۥۨ۟ۡۚۢ۬ۡۙۛۦۡۘ۠ۘۨۘ"

    goto :goto_6

    :sswitch_55
    iput-object v1, p0, Lpubgm/loader/activity/MainActivity;->nameGame:Ljava/lang/String;

    const-string v0, "ۤۜۥۨ۟ۛۢۨۘ۠ۦۡۘۡ۫ۛۛۗۛ۟ۧ۟ۧۧۡۘۘ۫۟ۦۨۘ"

    goto :goto_6

    :sswitch_5a
    invoke-virtual {p6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "۬۟ۧۜۧۦۘۦۚۧۦۧۡۛۗۥۘۤۡۥۖۜۗۢ۬ۛ۠ۡۡۜۢۜۘ۬ۥۘۘۖۛۢۘۖۚۨۦ۟ۧۧۦ"

    goto :goto_6

    :sswitch_60
    invoke-virtual {p7, v5}, Landroid/widget/ImageView;->setBackgroundResource(I)V

    const-string v0, "۬ۙۜۘۡۤۙ۠ۨ۬۫۠ۖۚۡۢۗۛۖۘۙۛ۬ۡۧۧۨۤۛۡۡۜۤ۟ۖ۠۫ۚۧۦۢۖۨۧۘۘۗ۫۟ۥۗ"

    goto :goto_6

    :sswitch_66
    const v0, 0x7f12006a

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lpubgm/loader/activity/MainActivity;->toastImage(ILjava/lang/CharSequence;)V

    const-string v0, "۬ۧ۠ۦ۫ۘۘۗۘۤ۬ۘۧ۫ۜۗۛۗۖۘۦۗۛۛۦۡ۠ۥۚۤۨۘۥۙۥۘۤۡۡ۫ۨۘ۬۠۠"

    goto :goto_6

    :sswitch_73
    return-void

    :sswitch_data_74
    .sparse-switch
        -0x77b28c7e -> :sswitch_41
        -0x695fc652 -> :sswitch_1a
        -0x471c1577 -> :sswitch_2c
        -0x417a0a84 -> :sswitch_73
        -0x2b5daf31 -> :sswitch_35
        -0x18bada91 -> :sswitch_5a
        -0xeaadcc7 -> :sswitch_60
        -0x3db3e09 -> :sswitch_3b
        -0x19106ef -> :sswitch_66
        0x55a1358 -> :sswitch_1d
        0x10e09674 -> :sswitch_4b
        0x1c5929dc -> :sswitch_2f
        0x1dc15a34 -> :sswitch_23
        0x3508b22f -> :sswitch_26
        0x5182a7f7 -> :sswitch_29
        0x54a7d760 -> :sswitch_55
        0x593e0a2f -> :sswitch_32
        0x5cec632e -> :sswitch_20
    .end sparse-switch
.end method

.method synthetic lambda$initMenu1$3$pubgm-loader-activity-MainActivity(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/view/View;)V
    .registers 15

    const v5, 0x7f070110

    const/4 v1, 0x0

    const-string v0, "۫ۜۖۘ۫ۗۥۘ۫ۙۥ۠ۨۦۘۤ۠ۤۤۜ۟۟ۦۘۨۖۜۡ۬ۜۘۗۨ۟۫۠ۡۘۥۗ۫ۧۦۖ۟"

    :goto_6
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x267

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x25b

    const/16 v3, 0xe5

    const v4, 0x44138bb9

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_74

    goto :goto_6

    :sswitch_1a
    const-string v0, "۟ۥۡۘۖۡ۠ۤۤۥۛۥۦۙۤۜ۠ۦۙۚۛۗ۠ۦۘ۠ۗۗ۟ۗۥ۫ۛۖۘۥۙۘۘۦۖۥ۠ۥۚ"

    goto :goto_6

    :sswitch_1d
    const-string v0, "ۥۚۜۘۦۘ۫ۗۦۢۙۤۘۘۙۢۦۘۙۖۦۘۨۜۦۨۥ۟ۦۢۘۢۛ۫ۢۚۦۡۖۧۥ۫ۛۦۖۘۧۗۘۛۦۥۛ۠ۨۖۖۘ"

    goto :goto_6

    :sswitch_20
    const-string v0, "ۛۤۖۛۧ۫ۨۛۚ۬۟ۥۘۢۚۜۘۘۛۡۘ۫ۡۨۘ۬ۡۦۡۨۖۜۨۧۘ"

    goto :goto_6

    :sswitch_23
    const-string v0, "ۧۖۛ۟ۥۢۡۥۡۘۘۧۨۘ۟ۧۘۜۙۢۥۦۥۘ۠ۗ۫ۨۨۤۥۨۛۧۥ۬ۚۡ۫ۥۦۨۘۨۛۤۗۖۧۘۢۘۥ"

    goto :goto_6

    :sswitch_26
    const-string v0, "ۦۨ۟ۚۢۦۨۛ۬ۤۥۜۤ۠ۥۜۖۖۘ۟ۗۥۘ۬ۤۤۖۨۛ۟ۢۥۘۗ۟ۜۦۗ۟۟ۘۘۥۨۖۖۨۦ۠۫ۦۘۘۘۦ۬ۗۡۘ"

    goto :goto_6

    :sswitch_29
    const-string v0, "ۛۡۗۚۗۚۖۤۨۘۙۗۜ۬ۨ۫ۦ۫۫ۗۢۧۡۗۥۦۧۘۧۚۨۘۨۘۧۘۖۦۦ"

    goto :goto_6

    :sswitch_2c
    const-string v0, "ۤۢۤۦۚۙۛۧ۠ۙۙۛۨۛۦۘۗ۬ۧۖۗۧۡۙۘۘۖۙۚۧ۠ۘۘۜۤ۬ۨۡۘۘۤۙۢ۟ۗۚۘۛۨ۫ۦ"

    goto :goto_6

    :sswitch_2f
    const-string v0, "ۘۨۥۗۖۧ۠ۦۜۙۚۨۚۚۗۨۧۡۘ۠۠ۢۗۛۛۨ۠ۨۘۙۛۘۘ"

    goto :goto_6

    :sswitch_32
    const-string v0, "ۨۖۦۘۛ۟ۦۛۧۨۦۢ۟ۧ۟۟ۢۥۘۡۙۖۘۖۦۨۢ۠ۖ۠۠ۛۥ۠ۘۘۛۖۤۤ۟ۤۜ۬ۜۘ"

    goto :goto_6

    :sswitch_35
    invoke-virtual/range {p0 .. p5}, Lpubgm/loader/activity/MainActivity;->gameversion(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "۠۬ۡ۬ۤۡۚۖۥۤۗۜۘ۠ۥۙۡۦۧۘۧۖ۟ۤۢۘۧ۫ۡ۠ۗۥۢۤۤۡۨۚ"

    goto :goto_6

    :sswitch_3b
    const/4 v0, 0x2

    sput v0, Lpubgm/loader/activity/MainActivity;->gameint:I

    const-string v0, "ۨۚۖۘ۫ۤۜۛۛ۠ۙۙۗ۫ۖۢۚ۬ۚۢ۟ۘۖۘۚۨ۠ۗۗۘۛۢۙۛ۟ۥۘۥ۫ۥۢۡۦۘ۫ۧۚۤ۠ۡۘ"

    goto :goto_6

    :sswitch_41
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->packageapp:[Ljava/lang/String;

    const/4 v2, 0x1

    aget-object v0, v0, v2

    sput-object v0, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    const-string v0, "ۤ۠۫ۖۙ۫ۘۗۤۥ۠ۨۘۦۘ۠ۜۧۤ۟ۥۛۨۜۗۗۥ۠ۧ۬ۥ"

    goto :goto_6

    :sswitch_4b
    const v0, 0x7f1200fb

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v0, "ۚۗۤۘ۠ۨۘۙۚۖۘۘۘۢۜۦۡۘ۠ۥۜۖۥۘۘۦ۠ۥۘۙۜۡۘۘۧۥۘۧۨ۫ۜ۟ۥۖ۫ۛۙۙ"

    goto :goto_6

    :sswitch_55
    iput-object v1, p0, Lpubgm/loader/activity/MainActivity;->nameGame:Ljava/lang/String;

    const-string v0, "ۢ۠ۥۤۜۜ۬ۡۘۧۖۤۨۜۜۘۤۗۘۡۙۙۜۧ۫ۚۙۨۤۧۨۘۥۜۥۘۙۙۢ۫ۙۖۘۦۦۜۘۤ۟ۜ۠ۛۦ"

    goto :goto_6

    :sswitch_5a
    invoke-virtual {p6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۙۘۥۙۨ۫ۦۧۤۚۛۚۨ۬ۚۗ۬ۚۖۦۘۨۘۥۘ۬ۛۦۘ۬ۢۗ"

    goto :goto_6

    :sswitch_60
    invoke-virtual {p7, v5}, Landroid/widget/ImageView;->setBackgroundResource(I)V

    const-string v0, "۠ۙ۠ۥ۫ۖۘۛ۠۫ۚۥۥۖ۫ۗۖۦۘ۠ۥ۟۫ۢۡۢ۟ۡۘۛۗۦۘۤۥۜۚۦ۠ۗۚۡۥۥۗ۫ۛۘۘۡۨۥۘۖ۬ۢ۠۠ۙ"

    goto :goto_6

    :sswitch_66
    const v0, 0x7f120078

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lpubgm/loader/activity/MainActivity;->toastImage(ILjava/lang/CharSequence;)V

    const-string v0, "ۥۥۧۘۚۧۖۘ۟ۦۙ۟ۥۘ۟ۛۛۤ۬۫ۥۤ۟۠ۤۗۧۤۢۥۗ۠"

    goto :goto_6

    :sswitch_73
    return-void

    :sswitch_data_74
    .sparse-switch
        -0x6e6875e9 -> :sswitch_5a
        -0x6b88ca30 -> :sswitch_60
        -0x5d197dfc -> :sswitch_66
        -0x4c1ab927 -> :sswitch_2c
        -0x4b3f7020 -> :sswitch_55
        -0x468554b6 -> :sswitch_26
        -0x2535675b -> :sswitch_29
        -0xeebe1d6 -> :sswitch_23
        -0xdf23b00 -> :sswitch_1d
        0x37e507 -> :sswitch_2f
        0x98f0bc0 -> :sswitch_73
        0x99c7e84 -> :sswitch_20
        0x115e215e -> :sswitch_41
        0x2c56ab91 -> :sswitch_35
        0x6024cbde -> :sswitch_4b
        0x6719f4e9 -> :sswitch_1a
        0x6d676ca8 -> :sswitch_32
        0x7979e0b2 -> :sswitch_3b
    .end sparse-switch
.end method

.method synthetic lambda$initMenu1$4$pubgm-loader-activity-MainActivity(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/view/View;)V
    .registers 13

    const/4 v1, 0x0

    const-string v0, "ۛۤۘۘۚۧۡ۠ۙۚۙۢۦۘۢۛۛۦۗ۠۬ۥۖۘۚۥۦۙۜۙ۬۟ۛۤۚۥۥۖۧۘۘۧۦۘۘۘۛ"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x2ca

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x3e1

    const/16 v3, 0xc0

    const v4, 0x3f86fa5b

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_5c

    goto :goto_3

    :sswitch_17
    const-string v0, "ۦۗۖ۫ۚ۬ۢۦۨۖۖ۠۫ۜۘ۬ۦ۬ۨ۟ۤۚۙۘ۟ۦۧۘۚۚۖۘۧۨۘۘ۠ۧۘۧ۫ۜۘ۬ۖ۠"

    goto :goto_3

    :sswitch_1a
    const-string v0, "۬ۡ۟۠۠ۗۧۥۖۛۥۙ۠۬ۥۙ۬ۥ۠ۢۡ۫ۘۧۥۢ۟ۜ۫۟ۗ۠۟ۤۥۖۘۦۧۢۦۜۦ"

    goto :goto_3

    :sswitch_1d
    const-string v0, "ۜۨۦۡۤۘ۟ۖۨ۟ۢۢۛۛۘۡۧۥۢۤۦۥۘۧۘۢۦۖۘۥۤ۫ۥ۠ۖۥۜ۫ۦۙۚۘۛ۠ۦۙۦ۫ۦۜۘ"

    goto :goto_3

    :sswitch_20
    const-string v0, "۠ۨۛۨۗۖ۬۫ۘۘ۟ۙۥۛ۬۠ۘۧۛۚۘۨۘۡۤۜۥۢۛۧۢۜ"

    goto :goto_3

    :sswitch_23
    const-string v0, "ۙۛ۟ۜۚۘۘۥۖۜ۫ۧۧۚۢۖۚۦ۠ۤۢۥۦۧۢۗۨۘۚۤۙۗۧ۟ۗۧۢ"

    goto :goto_3

    :sswitch_26
    const-string v0, "۠ۚۢۤۧۧۗۨۘۘۘۜۖۘ۟ۥۜ۬ۢۥۘۜۦۧۚۘۖۘۤۜۙ۠ۛۜۧۚۨۘۙۤ۟"

    goto :goto_3

    :sswitch_29
    const-string v0, "ۛۨۨۦ۬ۢۨۨۖ۟۫ۘۘۥۧۜۘۖ۬ۥۙۨ۫ۡۨۡۚۙۦۥۨۦۘ۟ۘۧۘۥۧۗ"

    goto :goto_3

    :sswitch_2c
    const-string v0, "۠۫۠۬ۖۥۜۧۥۦۡۘ۟ۚۘ۟ۖ۟ۙۥۖۢۜۘۘ۬ۤۨۛۙۘۥۛ۠ۜۗۘۘ"

    goto :goto_3

    :sswitch_2f
    invoke-virtual/range {p0 .. p5}, Lpubgm/loader/activity/MainActivity;->gameversion(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "ۧۢۗۜۧۥۘ۫ۤۘۘۜ۠ۤۜۜ۠ۚ۠ۤۧۡۤ۠۠ۚۧۧۘۘ۫۟ۢۛۚۜۘۨ۬ۨ"

    goto :goto_3

    :sswitch_35
    const/4 v0, 0x3

    sput v0, Lpubgm/loader/activity/MainActivity;->gameint:I

    const-string v0, "ۢۚۨۘۨۖۨۚ۠ۙۗۡۖۗۥۖۘۢۙ۬ۤۢۢۦۤۙ۠ۛ۟ۡۦۘۘۖۘۘۧۡۢۙۧۡۘۘۡۘۘ"

    goto :goto_3

    :sswitch_3b
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->packageapp:[Ljava/lang/String;

    const/4 v2, 0x2

    aget-object v0, v0, v2

    sput-object v0, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    const-string v0, "ۖۥۧ۫ۧۦۘۥۨۦۘ۠ۦۖۘۗۗۥۘۧۤۖۨۘۥۘۨۨۚۦ۟ۙۡۨۨۘ"

    goto :goto_3

    :sswitch_45
    const v0, 0x7f1200fe

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v0, "ۖ۫ۡۘۨۢ۟ۥۘ۟ۤۛۘۘۚۜۦ۬ۨۨۘۥۨۘۥۘۥۥ۫ۨۘۙۛۨۤۥۥ۠۠ۡۘ۬ۨۨۧ۟۫"

    goto :goto_3

    :sswitch_4f
    iput-object v1, p0, Lpubgm/loader/activity/MainActivity;->nameGame:Ljava/lang/String;

    const-string v0, "ۤۜۜۙۨۧ۟ۚۜۧۚۘۘۢۚۥۗۛۥۗ۠ۗۢۦ۠ۤ۟ۙۧۙ۬"

    goto :goto_3

    :sswitch_54
    invoke-virtual {p6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "۟۬ۢۙۛۛۤۧ۬ۚۧ۬ۦۛۡۘۡۤۨۘ۬ۧۜۘۤۤ۟ۙۧۧۦۚۖۘۥۧۙۜۗۦۢۙۤ۠ۥۘۚۜۚۗۨۘۙ۟ۡۨۚۥۘ"

    goto :goto_3

    :sswitch_5a
    return-void

    nop

    :sswitch_data_5c
    .sparse-switch
        -0x5f273073 -> :sswitch_17
        -0x5e32dbd9 -> :sswitch_5a
        -0x5ce3d4c3 -> :sswitch_20
        -0x57015725 -> :sswitch_2f
        -0x5297454a -> :sswitch_26
        -0x505ad773 -> :sswitch_2c
        -0x410f5d52 -> :sswitch_54
        -0xa924db -> :sswitch_4f
        0xd8169f2 -> :sswitch_1d
        0x27772806 -> :sswitch_35
        0x2af48749 -> :sswitch_23
        0x4c9caf28 -> :sswitch_3b
        0x68b23c33 -> :sswitch_45
        0x74f09b70 -> :sswitch_29
        0x7d399b1b -> :sswitch_1a
    .end sparse-switch
.end method

.method synthetic lambda$initMenu1$5$pubgm-loader-activity-MainActivity(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/view/View;)V
    .registers 13

    const/4 v1, 0x0

    const-string v0, "ۖۡۧۚۤۨۘۧۖۥۘ۫ۙۥ۫ۡ۫ۛۖۘۡۚۨۘۧۛۜۗۥۦۘۡۖ۬"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x66

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x345

    const/16 v3, 0xeb

    const v4, -0x5374d15b

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_5c

    goto :goto_3

    :sswitch_17
    const-string v0, "ۘ۠ۦۨۚۨۘۦۥۜۚۘۖۡۨۤۖۗۤۥۘۘۘ۫۟ۘۜۖ۬ۧۖۨۦۨۘۥۤۨۘۚۥ۬ۧۦۘ"

    goto :goto_3

    :sswitch_1a
    const-string v0, "ۤۖۜۥ۫ۢ۠۠ۜۛ۫ۡۖ۫ۗۛ۬ۡ۬ۨ۟۬ۢۨۦۡۡۘۖۘ۬ۨۦۛۡۧۙۧ۫ۗ۠ۛ۠ۦۗۙۛۛۗ"

    goto :goto_3

    :sswitch_1d
    const-string v0, "ۦۘۢۢۤ۠ۥۨ۫ۙۧۨۨۘۛۢۢ۫ۡۜۦۜۨۛۨۖۘۙۡۧۚ۫ۥۘۦۘۖۨۚۘۜۡۗۦ۠ۜۥۥ"

    goto :goto_3

    :sswitch_20
    const-string v0, "۟۬ۡۘۖۚۥۢۜۘۡۡۧۥ۬ۨۜۛۦۦ۟۟۠ۚۖۘۚۥ۫۫ۘۘۘۜ۬ۥۘۢۗۦۤۦۚۤۡ۫"

    goto :goto_3

    :sswitch_23
    const-string v0, "ۥ۬۟ۡۤۖۘۢ۟ۨۘ۠ۙۨۖۜۨۚۙۦۘۛۜۧۘۙۙ۬ۗۨۢۜۚۘۨۡۘۗۙۦۖۧ۬ۗۙۘۗۢۧ۟ۙ۬"

    goto :goto_3

    :sswitch_26
    const-string v0, "۬ۘۡۘۦۚۙۧۥۨۘۧۦۧۘۜۚۘۧۦۡۜۨۙۛۧۘۨۛۘۙۨۤۥۛ۟ۖۚۥۜۤۛۘۧ"

    goto :goto_3

    :sswitch_29
    const-string v0, "ۢۦۧۘۡۢ۟ۢۛۡۙۖۧۘ۬۠ۧۢۚ۫۠ۖ۠ۖۥۦۦۨۗ۟۠۠ۧ۬ۛۥۗ۫ۡ۠ۢۛۦ"

    goto :goto_3

    :sswitch_2c
    const-string v0, "ۚۢۥۘۚۥ۠ۘۜۢۙۖۘ۟ۦۖۘۡۘۚۗۨۜۘ۫ۗۨۖ۟ۥ۫ۖۖۘۙ۫ۥۘۖۦۜ۫۠ۛۢۨۧۘ"

    goto :goto_3

    :sswitch_2f
    invoke-virtual/range {p0 .. p5}, Lpubgm/loader/activity/MainActivity;->gameversion(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "ۗۛۛۦۦ۫۠ۦۦۚۥۖۘۜۤۜۘۖۡۦ۬۫ۦۧۛۢۡۘۘۘۢ۬ۧ۫ۢۦۘۚ۟ۡۘ"

    goto :goto_3

    :sswitch_35
    const/4 v0, 0x4

    sput v0, Lpubgm/loader/activity/MainActivity;->gameint:I

    const-string v0, "ۘۡۡۖۧۦۜۖ۫ۜۛۘۡۙۢ۠ۛۤۡۜۘ۬ۗۨۘۨۧۥۘ۠ۨۡۥۘۘۚ۬ۗۦۙۖۤ۟۫ۧۢۦۘ"

    goto :goto_3

    :sswitch_3b
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->packageapp:[Ljava/lang/String;

    const/4 v2, 0x3

    aget-object v0, v0, v2

    sput-object v0, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    const-string v0, "ۨۢ۟ۖۧۥۚ۠ۜۢۥۘۘۤۨۨ۬ۥۨۙۡۦۘۚۖۘ۟۫ۛۘۦۖۘۙ۫ۢۗۧۜ۠ۛۦۡ۫ۥۘۦۙۚ۠ۧۢۘۙۥۘ"

    goto :goto_3

    :sswitch_45
    const v0, 0x7f1200fd

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v0, "ۦ۠۠۫ۧۨۘۢۨۖۘۢۙۡۨۥۙ۬ۘ۟ۨۙۚۜۦۡ۫ۙۜۦۡۖۙۚۤ۟ۛۘۘۡۢ۟ۖۨ۬۠۬ۛ۠ۛۤۙۥۘ۫۫ۤ"

    goto :goto_3

    :sswitch_4f
    iput-object v1, p0, Lpubgm/loader/activity/MainActivity;->nameGame:Ljava/lang/String;

    const-string v0, "ۜۛۗۡۖۜۛۢۡۙۘۨۨۘ۠ۘ۠۟۟۟ۙۦ۟ۘۢ۫۫ۚۡۘۘۘۙ۟ۧۢۥۘۚۘۧ۠ۡۛ"

    goto :goto_3

    :sswitch_54
    invoke-virtual {p6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۗۗ۫ۡ۬ۦۘۘۨۗ۬ۨۖ۫ۛۚۛۖۜۘۨ۫۫۠ۗۖۛ۬۠ۚۨۖۘۡۘ۠ۨۗۚ۬۠ۘۤۘۖۘۜۚۖۛۤۧۖۧۘۘۜۤۥۘ"

    goto :goto_3

    :sswitch_5a
    return-void

    nop

    :sswitch_data_5c
    .sparse-switch
        -0x7b24cab6 -> :sswitch_2c
        -0x6532e02e -> :sswitch_54
        -0x3a4b68ba -> :sswitch_1d
        -0x2fbd9dd5 -> :sswitch_35
        -0x8d9203b -> :sswitch_5a
        0xc73ceb -> :sswitch_1a
        0x1a5a9f3e -> :sswitch_29
        0x20165bef -> :sswitch_45
        0x20e18e40 -> :sswitch_3b
        0x24d6b6c2 -> :sswitch_20
        0x2b2777d2 -> :sswitch_17
        0x31583866 -> :sswitch_4f
        0x3cfa673e -> :sswitch_2f
        0x63d444e0 -> :sswitch_23
        0x6dac6c06 -> :sswitch_26
    .end sparse-switch
.end method

.method synthetic lambda$initMenu1$6$pubgm-loader-activity-MainActivity(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/view/View;)V
    .registers 13

    const/4 v1, 0x0

    const-string v0, "ۜۤۜۘۗۘ۫ۤ۠ۨۘۚۡ۫ۥ۟ۖۘۚۨۗۚۥۧۘۥ۬ۦۗۧۘۘۛ۫۠ۘۢۤۡ۟ۘۘۖۨ۠ۖۧۨ"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x34

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x84

    const/16 v3, 0x15e

    const v4, 0x18d41432

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_5c

    goto :goto_3

    :sswitch_17
    const-string v0, "ۙۧ۠ۖۥۥۛۙۢ۟ۨۧۧۘۡۘ۟ۚۡ۫۟ۖۙۙۢۤ۫۠۬ۥۧ"

    goto :goto_3

    :sswitch_1a
    const-string v0, "ۨۤۢ۫ۢۡ۫ۚۡۘۖۙۨۡۜۘۨ۬ۨۘۜۤۤۛ۟ۡۜ۬ۥۘۦۢۡۘ"

    goto :goto_3

    :sswitch_1d
    const-string v0, "ۖۗۖۛۡۘۛۨۨۙۛۦۗ۠۬ۘۨۥۘۧ۫ۥۤۙۡۘۢۗ۬ۛۜۡۘ"

    goto :goto_3

    :sswitch_20
    const-string v0, "۬ۡۧۘۨ۫ۜۘۢۗۖۘۙۛۤۤۚۙۦۨۧۘ۠ۢۨۨۨۥۘ۬ۙۗۘ۠ۡۦ۬ۧۢۢۜۘۦۗ۟ۧۨ۠"

    goto :goto_3

    :sswitch_23
    const-string v0, "ۗۡۨۘ۬ۖۜۘ۟ۧۘۘۡۜۡ۠ۙۖۜۥۙۨۘ۫ۙۖۜۘۡۘۘ۟"

    goto :goto_3

    :sswitch_26
    const-string v0, "ۚۨۡۛ۬ۙۦۗۦۘۙۛۥۘۗۢۦ۫ۤۨۦۜۚۘۥۜۙ۫ۗۥۤۦۘ۫ۧ۫ۦۦۡۘۗۧۚۗ۠ۢ"

    goto :goto_3

    :sswitch_29
    const-string v0, "ۙۖۢ۠ۚۦ۬ۢۥۚۙۖۘ۠ۘۛ۟ۚۘۨ۠ۘۘ۫۬ۡۘۤۨۨ۟ۥۜۜۧۧۤ۠ۡ"

    goto :goto_3

    :sswitch_2c
    const-string v0, "۠ۦۤ۬۠ۦۘ۠۬ۦۘۡۖۙۧۢ۟۠ۤ۠ۛ۫ۦۜۙۥۡۨ۟ۜۙۜۘ۟ۦ۬ۤۧۘۗۡ۟۠ۦۘ۫ۢۙ۫ۧۥ"

    goto :goto_3

    :sswitch_2f
    invoke-virtual/range {p0 .. p5}, Lpubgm/loader/activity/MainActivity;->gameversion(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "ۥ۫ۡۘ۬ۦۢۘۛۧۛۦۘ۬ۜۤۤۖۨۘۡۛۚ۠۬ۨ۬ۖۦۘۚۘ۬ۚۛۖۗۙۤۜۖ۠ۜ۬ۢ۬ۗۦۘۦ۬ۥۘ۠ۥۚ۟ۧ"

    goto :goto_3

    :sswitch_35
    const/4 v0, 0x5

    sput v0, Lpubgm/loader/activity/MainActivity;->gameint:I

    const-string v0, "ۚ۫ۢۜۗۨۘۙۦۡۘۛۥۥۡۡ۟۟ۨۧ۬ۜۦ۬ۛۤ۟ۗۗۧۜۧۘ۬ۡ۬ۖۖۖۜۦۜۢۤۜۘ"

    goto :goto_3

    :sswitch_3b
    iget-object v0, p0, Lpubgm/loader/activity/MainActivity;->packageapp:[Ljava/lang/String;

    const/4 v2, 0x4

    aget-object v0, v0, v2

    sput-object v0, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    const-string v0, "ۜۗۤۜ۬۫ۘۙۡۘۖۨۙۡۖ۬ۜۡۧۘ۠ۙۥ۠ۧۥۘۘۜ۟۟ۜۘ"

    goto :goto_3

    :sswitch_45
    const v0, 0x7f1200fa

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v0, "ۨ۠ۦۖۨۨۘ۟ۥۜۡۡۛۗۡۙۨۧ۫ۜۢۦۙۘۤۡۘۨۘۗۨ۬۬۠ۤۦۦۢۗ۠۟ۢۦۧ"

    goto :goto_3

    :sswitch_4f
    iput-object v1, p0, Lpubgm/loader/activity/MainActivity;->nameGame:Ljava/lang/String;

    const-string v0, "ۛ۠ۘۥۘۡۘۨۛۜۘۢۥۥۖۚۡۢۛۜۜۡۥۥۘۚۢۖۙۨۜۘۥۧۢ۫ۤۧۢۡۜۘۧۘۗ"

    goto :goto_3

    :sswitch_54
    invoke-virtual {p6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "ۛ۠ۥۘۢۨۘۨۖ۟ۦ۬ۗۨۜۦۙۛۖۘۖۥۗۢۤ۟ۗۘۥۘۢۤۥۧۥۧۤۚۢۧۡۥۘۖۡ"

    goto :goto_3

    :sswitch_5a
    return-void

    nop

    :sswitch_data_5c
    .sparse-switch
        -0x7058b29a -> :sswitch_35
        -0x6c0801cf -> :sswitch_1d
        -0x6bf8d3eb -> :sswitch_17
        -0x68a0094e -> :sswitch_2c
        -0x4b275f67 -> :sswitch_3b
        -0x32cea1b7 -> :sswitch_1a
        -0x2dcb22b6 -> :sswitch_45
        -0x1f5e7de9 -> :sswitch_29
        -0x1dacc040 -> :sswitch_4f
        -0x18861799 -> :sswitch_54
        0xbb59d5e -> :sswitch_20
        0x20a4218a -> :sswitch_23
        0x422069e5 -> :sswitch_2f
        0x424c999d -> :sswitch_26
        0x76b2ecc5 -> :sswitch_5a
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$10$pubgm-loader-activity-MainActivity(Landroid/view/View;)Z
    .registers 9

    const-string v0, "ۙۨ۬ۦۙ۫۬ۙۙۚ۟ۦۘۗۥۧۘۢۙۧۥۚۛۢۜۤۦۖۘۘۛۧۤ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x10a

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x2eb

    const/16 v2, 0x218

    const v3, 0x18e76b77

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_4a

    goto :goto_2

    :sswitch_16
    const-string v0, "ۤۤۨ۫ۜۥۥ۬ۛۤۧۘۘۘۙۖۥۚۜۦۖۧۧۚۜۡۚۜۘۜۧ۟ۗۚۜۧۤۦۨ۫۟ۧ۬ۧۛ۠۫ۚۘ۟"

    goto :goto_2

    :sswitch_19
    const-string v0, "۫ۦۜ۟ۙۥۘۢ۟ۖۘ۫ۤۨۘۜۧ۟ۙۧۦ۠ۨۘۨۧۙۥۤۡ۫ۚۦۘۖۦۛۗ۠ۥ۫ۗۜۘ۬ۜ۫۬ۨۙۤ۟ۤ"

    goto :goto_2

    :sswitch_1c
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f07010c

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const v0, 0x7f120044

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v0, 0x7f120131

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    new-instance v5, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda18;

    invoke-direct {v5, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda18;-><init>(Lpubgm/loader/activity/MainActivity;)V

    new-instance v6, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda19;

    invoke-direct {v6, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda19;-><init>(Lpubgm/loader/activity/MainActivity;)V

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Lpubgm/loader/activity/MainActivity;->showBottomSheetDialog(Landroid/graphics/drawable/Drawable;Ljava/lang/String;Ljava/lang/String;ZLandroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;)V

    const-string v0, "ۖۨۧۘۙۚۡۘۥ۠ۘۤ۠ۛۢۦۧۖۘۛۦۜۘ۫ۨۥۘۘۥۥۨۦ۬ۙۖۥۡ۫ۨۘۙۥۨۘۨۥۘۘۥۧۨۘۜۙۥ"

    goto :goto_2

    :sswitch_47
    const/4 v0, 0x1

    return v0

    nop

    :sswitch_data_4a
    .sparse-switch
        -0x79e7f35f -> :sswitch_1c
        -0x2e4a46cb -> :sswitch_16
        0x37419fcf -> :sswitch_19
        0x4d69495e -> :sswitch_47
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$11$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۤۨۡۘۡۤ۟ۖۥۦ۠۫ۛ۬ۡ۟ۛۙ۬ۥۛ۟ۘۘۛۦۤۛۘ۬ۦ۠ۡۜۛۚۥۜۡۜۘۙ۫ۖ۟ۢۢۥۨۦۘۛۧۦ۫ۥ۠"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x1d7

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x1c4

    const/16 v2, 0x274

    const v3, -0x6442fd22

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_34

    goto :goto_2

    :sswitch_16
    const-string v0, "ۤۢۚ۬ۨۙ۬۠ۛۥۨۤۚۖۚۛۤۖۘۗۚۤ۠ۙۙۢۛۙ۬ۢ۬ۘۨۘۖ۟ۦۘۙۛۚۚۘ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۨۢۢ۫۠ۘۤۙۥۡۨۦ۠ۖ۟ۡۙۥۨۚۢۘ۬ۜ۬ۡۘۜۤۢۥۨۘۨۧ۬ۧۤ۠ۚۘ۬"

    goto :goto_2

    :sswitch_1c
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->doShowProgress(Z)V

    const-string v0, "ۖۖۤۜۤ۬۟۠۫ۧۡۨۨۛۥۢۥۖۘۧۖۖۛۛۘۘۨۦۙۛ۫ۨۘۡۧۗ۬ۙۛۚۗۧۛۧۤۤۙ۫ۦۛۘۢۨ۫۬ۥۘ"

    goto :goto_2

    :sswitch_23
    const/4 v0, 0x0

    const-wide v2, -0xd32ad953c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lpubgm/loader/activity/MainActivity;->addAdditionalApp(ZLjava/lang/String;)V

    const-string v0, "ۢۢ۬ۚۡۘۚۤۡ۫ۙۦۗ۟ۙۛۦ۟ۙۖۘۦۦۨ۟ۚۜۨۥۡۘ"

    goto :goto_2

    :sswitch_33
    return-void

    :sswitch_data_34
    .sparse-switch
        -0x52ebb32c -> :sswitch_16
        -0x356416d1 -> :sswitch_19
        0x1b2159e6 -> :sswitch_33
        0x4a252de0 -> :sswitch_23
        0x68f661d9 -> :sswitch_1c
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$12$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "۬ۙۧۙۖۜۧۘۨۧ۟ۧ۫ۛۨۦۘۘۤۚۛ۬ۗۧ۟ۥ۠ۖۡۛ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xa6

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x0

    const/16 v2, 0x125

    const v3, 0x1a35851e

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_36

    goto :goto_2

    :sswitch_16
    const-string v0, "ۖۘ۠۟ۘۚ۫ۛۡۘۜۧۚۙۘۨۘۥۖۨۡۦۜ۠ۘۖۘۢۚۨۙۧ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۡۜۦۡ۠ۡ۫۟۠ۖۚۤۚ۬۬۟ۜ۬۠ۧ۠ۦۧ۠ۤۡۘۘۢۧ۠ۨۥۘۗۥ۠ۙ۠ۛۢۜۘۧۡ۬ۥۙۘ"

    goto :goto_2

    :sswitch_1c
    invoke-static {}, Lpubgm/loader/libhelper/ApkEnv;->getInstance()Lpubgm/loader/libhelper/ApkEnv;

    move-result-object v0

    const-wide v2, -0xd32ada93c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lpubgm/loader/libhelper/ApkEnv;->unInstallApp(Ljava/lang/String;)V

    const-string v0, "ۥۢۖۤۤۤۛ۫ۦۗۨۢ۟ۗ۟ۙۧۦۘۜۡۚۙۨۨۨۜۘۘۗ۬ۡۧۘۖۘ۠ۚ۟ۥ۟ۚۤۜۘۘۛ۬ۨۘۢۥۗۨۦۤ۟ۖۖ"

    goto :goto_2

    :sswitch_2f
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->dismissBottomSheetDialog()V

    const-string v0, "ۥۦۗۥۥۜۗۤۜۗۛۡۡۛ۫ۡۖۡۖ۠ۡۙۡۗۖۦۢۘۢۜۘ۫ۖۤ۫ۡۨۘ۠ۦۧۘۦۧۘۘۧۨ۬۫۠ۙۧۛۜۤۦۡۘ"

    goto :goto_2

    :sswitch_35
    return-void

    :sswitch_data_36
    .sparse-switch
        -0x63b6d67b -> :sswitch_16
        -0x1c0eac12 -> :sswitch_2f
        -0x18545aaa -> :sswitch_1c
        0x27a26d8d -> :sswitch_19
        0x4a7eaadf -> :sswitch_35
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$13$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۦ۠ۦۥۧۥۥۗۨ۠ۤۖۚۚۜۘۢۙۧۛۤ۬ۙۧۘۛۨۨۘۢۖ۬ۥۦۜۜۗۨ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x32f

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x2c8

    const/16 v2, 0x2d

    const v3, 0x7c4fdece

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_24

    goto :goto_2

    :sswitch_16
    const-string v0, "۠ۢۦۘ۟۠۬ۖۡۥ۠ۦۧۘۤۡۨۘۜۛۥۙۧۛۥۗ۬ۚۥۧ۫ۗ۫ۜۙۘ۬ۤۡۘ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۥ۟ۖۡۗۛۨ۠ۜۘۜ۫ۢ۬۬ۘۦۗۤۡۦۙۘ۬۫ۤۦۨۘۦۜ۠ۚۢۥۘۘۖۨۘۗۜۥۦ۬ۥۘۙۢۖۘۦ۠ۘۘۤۨۖۥۡ"

    goto :goto_2

    :sswitch_1c
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->dismissBottomSheetDialog()V

    const-string v0, "ۘۜۖۥۚۦۖۛۘۦ۟ۛۦۢۙۡۜۜۙۤۢۗۦۤۢۛۥ۫ۗۘۢ۬ۜۘۡۡۧۗۘۥۛۖۘۖ۬ۥۧۨۧۘ۫۫ۡۙۚۥۘ"

    goto :goto_2

    :sswitch_22
    return-void

    nop

    :sswitch_data_24
    .sparse-switch
        -0x4d621906 -> :sswitch_22
        -0x4a30e281 -> :sswitch_19
        -0x1c0a1287 -> :sswitch_1c
        0x38d9b581 -> :sswitch_16
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$14$pubgm-loader-activity-MainActivity(Landroid/view/View;)Z
    .registers 9

    const-string v0, "ۜۗ۬ۗ۫ۛۛۘۤۡۧۧ۟ۥۖۘ۬۫ۖۘۢۡۚۘۙۛۤۧۜۘۘۛۦۘۤۖۜۘ۠۟۟ۙۜۨۙۧۦ۟ۤۜۛۖۥۘۗۤۦۘ۠ۗۡ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x12c

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x192

    const/16 v2, 0x177

    const v3, 0x782215ba

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_4a

    goto :goto_2

    :sswitch_16
    const-string v0, "O۠ۙ۟ۛۗۜۘۢۤۡۜۧ۠ۖۡۚۦۢۖۦۘۧۘۦۧۗۚ۠ۖۘۗۡۥۡۦۗ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۜۢۨۨ۠ۡۘۜ۠ۘۤۡۘۨ۬ۡ۠۬۠ۗۗۦۧ۫۫ۡۨ۬ۜۜۘۡ۠ۗۚۦۨۛۡۘۦ۫ۦۖۛۜۘۢۙۦۘۜۖۥۦۡۘ"

    goto :goto_2

    :sswitch_1c
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f07010c

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const v0, 0x7f120044

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v0, 0x7f120131

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    new-instance v5, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda16;

    invoke-direct {v5, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda16;-><init>(Lpubgm/loader/activity/MainActivity;)V

    new-instance v6, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda17;

    invoke-direct {v6, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda17;-><init>(Lpubgm/loader/activity/MainActivity;)V

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Lpubgm/loader/activity/MainActivity;->showBottomSheetDialog(Landroid/graphics/drawable/Drawable;Ljava/lang/String;Ljava/lang/String;ZLandroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;)V

    const-string v0, "ۗۥۨۘۦۚۗۡۘۖ۠ۢۛۡۢۙ۟ۛۖ۫ۖۖۘۛۙ۟ۜۛۗۜۡ"

    goto :goto_2

    :sswitch_47
    const/4 v0, 0x1

    return v0

    nop

    :sswitch_data_4a
    .sparse-switch
        -0x697c457f -> :sswitch_1c
        -0x560724ef -> :sswitch_19
        0xb04f359 -> :sswitch_47
        0x63d9c40c -> :sswitch_16
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$15$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۜۡۨۘۘ۟ۘۘۖۚۘۘ۟ۖ۬ۦۛۙۨۥۡۗۘۘۘۙۙ۠ۢۥۘ۫ۚۖۦ۫۠ۡۡ۫ۖۨ۠ۦۙۥۤ۟ۡۜۤ۠"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x13a

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x1d

    const/16 v2, 0x326

    const v3, -0x4ca33367

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_34

    goto :goto_2

    :sswitch_16
    const-string v0, "ۙۥۖۡۛۗۦۘۦۘۛۖۖۘۘۢۨۘ۫۠ۖۘۡۤۡۤۧۨۘۨۚۜۘۥۜ۫"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۧۡۨۢۖۚۖۨۘۘۜۡۘۧۘۤ۬ۧۖۖۙۨۦ۫ۢۥ۟ۜۘ۠ۛۡۛۥۚۙۦۘۤۥۘۘۥۜ"

    goto :goto_2

    :sswitch_1c
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->doShowProgress(Z)V

    const-string v0, "۬ۘۦۘۘ۟ۜۛۧۘۡۘ۠ۜۥۘۖۛۛۨۦۘۘۥ۠ۨۘۢۗۨۘۥۧۚ۟ۛۨۘۙۛۙ"

    goto :goto_2

    :sswitch_23
    const/4 v0, 0x0

    const-wide v2, -0xd32adb83c3a53bdL  # -1.001039711686482E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lpubgm/loader/activity/MainActivity;->addAdditionalApp(ZLjava/lang/String;)V

    const-string v0, "۬ۥۙۖ۫ۛۘۘۛۡۜۦۘۚۤ۠ۨۖۖۘ۠ۜۨۘۜۢۤۙۜۗۘۖ۬"

    goto :goto_2

    :sswitch_33
    return-void

    :sswitch_data_34
    .sparse-switch
        -0x5fb149bc -> :sswitch_23
        -0x529387de -> :sswitch_1c
        -0x2362f79e -> :sswitch_19
        -0x1f87bce6 -> :sswitch_16
        -0x614d7f0 -> :sswitch_33
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$16$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۢۛ۬ۛۤۦ۫ۨۘ۟ۦۦۘۜۢ۠ۖۜۤۙۘۘ۠۠ۦۘۧ۠۠۟ۜۧۨ۬ۥۚۙۤ۫ۙۤ۬ۘۢۦ۟ۡۘۗۜۡۘ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xea

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x29c

    const/16 v2, 0x34b

    const v3, 0x63982769

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_36

    goto :goto_2

    :sswitch_16
    const-string v0, "ۙۨۗۢۨۦۡۡۘۧۡۡۘ۫ۗ۬۬ۛۖۘۡ۫ۦۖۤ۫ۧ۫۫ۖۚۧۤۥۦۘۘ۠۠"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۖۢۨۜۢۢۜ۠ۢ۠۟ۥۘۢۡۘۘۢۜۘ۟ۚۜۖۚۙۢۡۘۦۤ۬ۤۗۢۙۖ۟۟۠ۤۜ۠ۤ۫ۛۗۘۢۧ"

    goto :goto_2

    :sswitch_1c
    invoke-static {}, Lpubgm/loader/libhelper/ApkEnv;->getInstance()Lpubgm/loader/libhelper/ApkEnv;

    move-result-object v0

    const-wide v2, -0xd32adcf3c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lpubgm/loader/libhelper/ApkEnv;->unInstallApp(Ljava/lang/String;)V

    const-string v0, "۟ۛۘۘۖۧ۫ۡۜۜۘ۬ۦۜۗۢۜۘۤۦ۟ۦۚۛۚۡ۫ۛۖ۬ۗ۫ۚۢۖۤ۬ۡۚۡ۠۬ۘۙۛ"

    goto :goto_2

    :sswitch_2f
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->dismissBottomSheetDialog()V

    const-string v0, "ۡۜ۠ۥۡۚۚۦۘۘۧۦۦۥ۠ۨ۠ۧ۟ۖۡۦۧۚۥۤۘۥۘۧۢۖۙۡۖۥ۬ۡۡۢۜۢۡۦ"

    goto :goto_2

    :sswitch_35
    return-void

    :sswitch_data_36
    .sparse-switch
        -0x6285297c -> :sswitch_16
        0x199a84bc -> :sswitch_19
        0x3cde716a -> :sswitch_1c
        0x4d72c4a9 -> :sswitch_2f
        0x4f82f5fc -> :sswitch_35
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$17$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۜۛۧ۠ۤۚۛۧۧۘۧ۬ۜ۠ۜۘۤۤۜۘ۬ۛۛۨۧۜۘۖ۫ۢ۫ۡۛۘۧۦۦۘۧۧۖۘۢۨۘۚۗ۠۟ۜۧۤۛۘۘۢۛۨ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x2db

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x344

    const/16 v2, 0x385

    const v3, -0x5774be61

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_24

    goto :goto_2

    :sswitch_16
    const-string v0, "ۤۥۤۤ۬ۜۘۥ۬ۜۡۚۜ۠ۚۡۘۜۧۢۨۜۜۘ۠۬۬ۦۢۜۘۛ۫ۛۗۦ۫ۡۖۘ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۡ۬ۜۘ۟ۙۜ۠۟ۚۘۥۘ۬ۦ۠۬ۧۘ۬ۥۧۘ۠ۧۦۘۢۚۜۜۚۢۖۛۥۚۤۡۘۨۦۚۗ۫ۧ۫۬ۘۗۡۤ"

    goto :goto_2

    :sswitch_1c
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->dismissBottomSheetDialog()V

    const-string v0, "ۦ۫ۡ۫ۜۘۘۖۧۙۗۙۢۚۚۦۘۢۗۗۙۙ۠ۗۜ۫ۨۦۘۘۤۤۛۨ۬ۜۘۜۚۨۙۜۤۜۖ"

    goto :goto_2

    :sswitch_22
    return-void

    nop

    :sswitch_data_24
    .sparse-switch
        -0x56b0a482 -> :sswitch_19
        0x1e9da3f3 -> :sswitch_1c
        0x3d080b92 -> :sswitch_16
        0x7c4e0578 -> :sswitch_22
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$18$pubgm-loader-activity-MainActivity(Landroid/view/View;)Z
    .registers 9

    const-string v0, "ۗۨۨۘۜۚۖۖۢۥۘۤۡۦۢ۠ۖۡۙۨۘ۠ۚۘۘۛۦۧۘ۟ۦۧۘۚۨۚۘۚۦۘ۫ۜ۫ۢۗۥ۠ۢۥۘ۫۟ۛ۟ۚ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x371

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x390

    const/16 v2, 0x94

    const v3, -0x23329b46

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_4a

    goto :goto_2

    :sswitch_16
    const-string v0, "۟ۛ۫۬ۛۦۘۛۚۡۘۤۥ۫۟۬۟ۘ۠ۡۘۨۚۘۙۦ۟ۛۥۨ۠ۥۘۢۙۤۨۡ۬"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۜۗۦۖ۟ۚۨۢۡۛ۟ۡۘۦۡۖ۟ۡۥۘۚ۫ۜۨۙۡۢۤۛۖۚۡۘ۫۟ۧۤ۬۟"

    goto :goto_2

    :sswitch_1c
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f07010c

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const v0, 0x7f120044

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v0, 0x7f120131

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    new-instance v5, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v5, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda2;-><init>(Lpubgm/loader/activity/MainActivity;)V

    new-instance v6, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda3;

    invoke-direct {v6, p0}, Lpubgm/loader/activity/MainActivity$$ExternalSyntheticLambda3;-><init>(Lpubgm/loader/activity/MainActivity;)V

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Lpubgm/loader/activity/MainActivity;->showBottomSheetDialog(Landroid/graphics/drawable/Drawable;Ljava/lang/String;Ljava/lang/String;ZLandroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;)V

    const-string v0, "ۢۧ۫ۧ۫ۘۘۜۚۧۗۘۨۚۥۘۘ۟ۗۨۘۖۢۖۖۙۛۛۖۤۚ۫ۡۘ"

    goto :goto_2

    :sswitch_47
    const/4 v0, 0x1

    return v0

    nop

    :sswitch_data_4a
    .sparse-switch
        -0x48d25865 -> :sswitch_19
        0x7489ae7 -> :sswitch_47
        0x1108b17d -> :sswitch_16
        0x3f255fd0 -> :sswitch_1c
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$7$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۚۗۨۜۡ۬۫۬ۗۤۨۦۥۚۘۘ۠ۙۤۛ۫ۥ۠۟ۘۖۖۛۡۤۦۘۖۥ۫ۧ۠"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x253

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x1d9

    const/16 v2, 0xf6

    const v3, -0x377612b

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_34

    goto :goto_2

    :sswitch_16
    const-string v0, "ۗۥۘۘۖۜۜۘۙ۫ۨۧۡ۠ۘۥۨۖۤ۬ۤۘۡۘ۫ۘۚۘۡۥۨۘۜۘۦ۠ۜۘۖ۫ۚۢ۬ۨ۟ۛ۬"

    goto :goto_2

    :sswitch_19
    const-string v0, "۫ۥۛۖۚۖۨۜۢۦۧۘ۠ۛۥۘۜۦۘ۟ۜۖۧۨۙۖۖۢ۬ۤ۠ۨ۠ۦۡۦۦ"

    goto :goto_2

    :sswitch_1c
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->doShowProgress(Z)V

    const-string v0, "ۚۛۢۜۦۙۤۖ۠ۢۡۜۛۖۨۘۘ۟ۜۡۗ۬ۙۘ۠ۚ۠ۙۖۥۘۘ۠ۦۘۛۖۦۘۦۥۨۘۜۚۖۘ۠ۥۘۜۜۘ"

    goto :goto_2

    :sswitch_23
    const/4 v0, 0x0

    const-wide v2, -0xd32ad753c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lpubgm/loader/activity/MainActivity;->addAdditionalApp(ZLjava/lang/String;)V

    const-string v0, "ۚۜۨۨ۟ۗۖۧۨۜ۫۫ۛۥۜۚۤۢۙۘۚۜۨۦۘۤۨۖۙۙۡ۬ۤۦۘ۟ۙۖ"

    goto :goto_2

    :sswitch_33
    return-void

    :sswitch_data_34
    .sparse-switch
        0x1b5fa8f7 -> :sswitch_1c
        0x3dd20bc0 -> :sswitch_23
        0x5adeddb1 -> :sswitch_19
        0x5d46df46 -> :sswitch_33
        0x7a4d5e5e -> :sswitch_16
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$8$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۦۖۗۙۖۤ۠۫ۖۖ۬ۡۘۨۢۚۤۡ۬ۨۖۜۘۥۤۚ۬ۖۨۘۚۡۘۘۘۧۤۚ۟ۙۧۗۡۘ۬ۦ۬"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x1dc

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x273

    const/16 v2, 0xb5

    const v3, 0x7dd62385

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_36

    goto :goto_2

    :sswitch_16
    const-string v0, "۫۠۫۫۟ۜۘ۬ۙ۬ۦۖۥۘ۠ۖۖۛۡۘۧۢۜۘۥۖۤۧۧۦ۠۟ۨ"

    goto :goto_2

    :sswitch_19
    const-string v0, "۬ۦۥۘۗۨۜۘۥۦۦ۠ۚ۫ۤۗۚۜۖۘ۬۠ۥۘۖۢ۠ۧۖۦ۟ۥۧۜۥۘۘۙۛۢۗ۠ۖۛۧۦۘ"

    goto :goto_2

    :sswitch_1c
    invoke-static {}, Lpubgm/loader/libhelper/ApkEnv;->getInstance()Lpubgm/loader/libhelper/ApkEnv;

    move-result-object v0

    const-wide v2, -0xd32ad813c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lpubgm/loader/libhelper/ApkEnv;->unInstallApp(Ljava/lang/String;)V

    const-string v0, "ۨ۠ۡۚۥۛۙ۬ۙ۬ۨۖۥ۠۫ۙۚۢۢۨۧۧۖۦۘۚۜۧۘ۫ۦۘ۬ۛۜ۬ۖۘ۫ۥۦۘ۬ۧۦ"

    goto :goto_2

    :sswitch_2f
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->dismissBottomSheetDialog()V

    const-string v0, "ۖ۟ۚۢۥۚۜۨۢ۠۬ۤ۬۟ۘۘۘۤ۫ۜۘۖۧۜۧ۫ۚۦ۟ۡۛۘۛ۠ۙۥۛۜۖۡۦۘ۬۬ۖۘ۫۬ۥۘۥۘۘۘ۫۠ۦ"

    goto :goto_2

    :sswitch_35
    return-void

    :sswitch_data_36
    .sparse-switch
        -0x498162f2 -> :sswitch_19
        -0x3517c2e0 -> :sswitch_35
        -0x30115aa2 -> :sswitch_16
        0x1a7a0bb5 -> :sswitch_2f
        0x32558651 -> :sswitch_1c
    .end sparse-switch
.end method

.method synthetic lambda$initMenu2$9$pubgm-loader-activity-MainActivity(Landroid/view/View;)V
    .registers 6

    const-string v0, "ۧ۟ۧۙ۫ۨۘ۬ۡ۠ۥۜ۟۫ۢ۫ۨۜۗۛۡ۬ۗۜۘۗۡ۬ۜۧ۫"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xbb

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x8b

    const/16 v2, 0x1f5

    const v3, -0xe407856

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_24

    goto :goto_2

    :sswitch_16
    const-string v0, "۫ۚۘۘۚۢۧۥۚۚۜۘۨۡ۠ۘۚ۬ۨۛ۫ۧۚۨ۠ۤۧ۟ۗۘۘۤۨۨۘۛۡۛ۫ۖۨۘ۫ۛۡۧۚۢۛۚۙۢۚۦۘۧۘۜ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۤۛ۫ۜ۬ۜۤۘۨۘۧۥۧۘۖۚۚۗۧۥۘ۬ۡۘ۠ۛۥ۬ۛۢۙۛۡۘۛۘ۬۬ۨۥۘ۠ۨۦۘۙۜۤۧ۫ۗۗۖ۫۫۬ۛۦۢ"

    goto :goto_2

    :sswitch_1c
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->dismissBottomSheetDialog()V

    const-string v0, "۠ۚۤۦۛۖۘۥ۫ۜۘۜۨۜۘ۟۬ۛۥۘۘۛۡۙۡۡۧۘۤۨۥۘۚۙۖۘۡۢۗۨ۟ۨۤۙۘۘ۠ۗۛۨ۟ۨۙ۟ۢ"

    goto :goto_2

    :sswitch_22
    return-void

    nop

    :sswitch_data_24
    .sparse-switch
        -0x484fd916 -> :sswitch_22
        -0x351dc08e -> :sswitch_1c
        0x9986647 -> :sswitch_16
        0x3d3f6578 -> :sswitch_19
    .end sparse-switch
.end method

.method public launchbypass()V
    .registers 7

    const/4 v1, 0x0

    const-string v0, "ۥۛۦۘۡ۬۫۟۟ۖۘۤۜۛ۠ۙۜۘۚۗۘۨۘۖۡۦۢۦۛۙ۫۟"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x3bd

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x1f8

    const/16 v3, 0x235

    const v4, 0x6912361b

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_a0

    goto :goto_3

    :sswitch_17
    const-string v0, "ۧۢۨۡۨۥۘۛۜۜۘۛۖۗۨ۠ۜۖۦۥۛۜ۟۬ۜ۫ۥ۬ۤ۠۫۫ۙ۟ۘۘۚ۬ۖ"

    goto :goto_3

    :sswitch_1a
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    sget-object v1, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const-string v0, "ۖ۟ۘۘۦۜۡۧۖۖۘ۠ۛ۠ۙۨۜۘۖ۠ۖۢۜۘۡۘ۠ۙ۬ۧۦۢۛۚۘۘ۠۫ۜۘۢۗۚ۟ۖۢۨ۫ۛۖۨۜۘۧۨۥۘۢۥۨۘ"

    goto :goto_3

    :sswitch_27
    const v2, -0x7d284fc1

    const-string v0, "ۦۢ۟۟ۖۥۡۧۥۘۥۡۦۥ۟ۖۘ۠ۡۢۧۘۡۢۖۚۗ۫ۡۘۤۥۡۛۚ۟ۡۧۤ۬ۖۛۘۧ۟ۤ۟ۜ۟ۡۨۘ"

    :goto_2c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_c2

    goto :goto_2c

    :sswitch_35
    const-string v0, "ۨۗۖۗۛۦۘۘ۫ۢ۟ۢۦۙۥۥۚ۬۠ۡۘۦۗۗ۬ۢۙ۟ۙۤۛۦۥ۬ۥۧ"

    goto :goto_2c

    :sswitch_38
    const-string v0, "ۢ۫ۡۘۦ۠ۘۡۚۦۤۡ۟۬ۗۦۛۙۦۘۗۘۚۜۦۨۘۗ۟ۨۘۙ۠ۙۢۢۡۘۛۛۥ"

    goto :goto_2c

    :sswitch_3b
    const v3, -0x6532d5da

    const-string v0, "ۨۛۘۨۥۨ۠ۡۙۚۙۛۢۡۘۘۧۜۤ۫۬ۥۧۨۗۢۚۦ۠ۜۛ"

    :goto_40
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_d4

    goto :goto_40

    :sswitch_49
    const-string v0, "۟ۚ۠ۙ۫ۦۛۧۘۘۗۘۦۖۙۜۘۚۜۡۨۤۖۘۙۜۥ۟۫۬ۥ۬ۜۤۢۜۤۨۙۡۗۜۖۜۘۧۙ۠ۧۙۤ"

    goto :goto_2c

    :cond_4c
    const-string v0, "ۖ۠ۤۜۘۦۨ۟ۥۘ۠ۡ۬ۗ۠۟۫ۢۥۛ۟ۙ۫ۜ۠ۖۙۗۡۖۖ"

    goto :goto_40

    :sswitch_4f
    if-eqz v1, :cond_4c

    const-string v0, "ۧۤۨۛ۫ۘۖۖۢۚۚۜۘۦۗ۠ۘ۬ۨۘۚۨۥۘۢ۟ۜۖۘۖۘۨۨ۫ۥ۠ۙ۫ۖۤ۟۫ۨۘۛ۟ۜۜۥۘۘ۫ۜۧ"

    goto :goto_40

    :sswitch_54
    const-string v0, "ۛۜ۠۫ۧ۫ۧۗۦۛۥ۠ۙۘۘۖۦۧۘۜۖۜۤۨۤۤۡۘۨۗ۬ۗ۬ۦۘۤۡۙ۬ۛۧۧۛ"

    goto :goto_40

    :sswitch_57
    const-string v0, "ۤۛۜۘۡۙ۬ۡۦۢۨۢۜۗۚ۬۫ۡۧۘۤ۫ۥۘۚۜۗۙۤۘۙۘ۠ۡۜۧۗۤۨ۫ۢۘۘۙۢۥۘۘۛۦ۬ۖ۬ۢۘۘۘۥۜۧ"

    goto :goto_3

    :sswitch_5a
    invoke-virtual {p0, v1}, Lpubgm/loader/activity/MainActivity;->startActivity(Landroid/content/Intent;)V

    const-string v0, "ۨۨۘۘۘۢ۬ۥۦ۟ۥۘۨۘ۬ۥۜۤۙۢۛ۟ۖۘۘۦۡۘۜۙۤۙ۬ۛۛۙۤۨۥ۠ۗ۠۠ۚۗۨۘ۬ۥۙۖۥۜ"

    goto :goto_3

    :sswitch_60
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v2, Lpubgm/loader/activity/MainActivity$7;

    invoke-direct {v2, p0}, Lpubgm/loader/activity/MainActivity$7;-><init>(Lpubgm/loader/activity/MainActivity;)V

    const-wide/16 v4, 0xed8

    invoke-virtual {v0, v2, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const-string v0, "۟۬ۗۚۨۖۘۜ۬۬۫ۢۦۗۥۜ۠ۛۗۨۛۜۘۢۤۤۚۨۡۖۖ۫ۢۗۥ۟ۖۘۥ۫ۤۦۢ"

    goto :goto_3

    :sswitch_72
    const v0, 0x7f0700ee

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lpubgm/loader/activity/MainActivity;->game:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const v3, 0x7f1200e4

    invoke-virtual {p0, v3}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lpubgm/loader/activity/MainActivity;->toastImage(ILjava/lang/CharSequence;)V

    const-string v0, "ۛ۠ۤۛ۠ۨۦۛ۟۬ۦۗ۫۟ۤ۫۟ۦۧۥۘۗ۠ۨۘۛۘۖۘۦۜۦۘ۬ۘۦۡۖۤۙۛۤۡۛۡۘ"

    goto/16 :goto_3

    :sswitch_96
    const-string v0, "ۚ۠ۨۚۛۧۙۜ۬ۗ۫ۧۙۘۖ۬ۜۖۥ۟ۥۘۘۢۥۘۖۤۜۥ۬ۥ۫ۧۦۘۨۛۦۘ"

    goto/16 :goto_3

    :sswitch_9a
    const-string v0, "ۛ۠ۤۛ۠ۨۦۛ۟۬ۦۗ۫۟ۤ۫۟ۦۧۥۘۗ۠ۨۘۛۘۖۘۦۜۦۘ۬ۘۦۡۖۤۙۛۤۡۛۡۘ"

    goto/16 :goto_3

    :sswitch_9e
    return-void

    nop

    :sswitch_data_a0
    .sparse-switch
        -0x7e1fa491 -> :sswitch_17
        -0x48d4f6c2 -> :sswitch_1a
        -0x38e48b4c -> :sswitch_60
        -0x171e4f8e -> :sswitch_9a
        -0x1262aec1 -> :sswitch_5a
        0x58d7596 -> :sswitch_9e
        0x1151d621 -> :sswitch_72
        0x44202640 -> :sswitch_27
    .end sparse-switch

    :sswitch_data_c2
    .sparse-switch
        -0x3bfb72a5 -> :sswitch_57
        -0x1a22f690 -> :sswitch_96
        0x2ee45249 -> :sswitch_3b
        0x46cd3495 -> :sswitch_35
    .end sparse-switch

    :sswitch_data_d4
    .sparse-switch
        -0x762c491f -> :sswitch_54
        0x15cb45b6 -> :sswitch_38
        0x1f1718ef -> :sswitch_4f
        0x6b383e47 -> :sswitch_49
    .end sparse-switch
.end method

.method public loadAssets(Ljava/lang/String;)V
    .registers 6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-wide v2, -0xd32ae7d3c3a53bdL  # -1.0009370867768509E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lpubgm/loader/activity/MainActivity;->daemonPath:Ljava/lang/String;

    sput-object v0, Lpubgm/loader/activity/MainActivity;->socket:Ljava/lang/String;

    :try_start_2a
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v2, -0xd32ae633c3a53bdL  # -1.0009506311811677E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Lpubgm/loader/activity/MainActivity;->daemonPath:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;
    :try_end_4d
    .catch Ljava/io/IOException; {:try_start_2a .. :try_end_4d} :catch_4e

    :goto_4d
    return-void

    :catch_4e
    move-exception v0

    goto :goto_4d
.end method

.method public loadJSONFromAsset(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    :try_start_0
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/InputStream;->available()I

    move-result v1

    new-array v1, v1, [B

    invoke-virtual {v0, v1}, Ljava/io/InputStream;->read([B)I

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    new-instance v0, Ljava/lang/String;

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_1b
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_1b} :catch_1c

    :goto_1b
    return-object v0

    :catch_1c
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    const/4 v0, 0x0

    goto :goto_1b
.end method

.method public onBackPressed()V
    .registers 5

    const-string v0, "ۖ۬ۜۘۦ۟ۨۘۗۛۤۘۜۘۘ۟ۙۡۘۦۚۦ۬ۦۗۜۚۦۘۚۢ۬ۢۨۡۡۢۖۘۖۙۦۦ۟ۙۨۥ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x163

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x92

    const/16 v2, 0x2f4

    const v3, -0x574e02d8

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_32

    goto :goto_2

    :sswitch_16
    const-string v0, "ۨۖ۟ۚۧۥۘۜۥ۟ۙۧۚۢۤ۫۫۫ۡۘۛۙۨۘۚۘۥۧۧۦۘۡۚۦۗۛۜۜۡۘ"

    goto :goto_2

    :sswitch_19
    invoke-super {p0}, Lpubgm/loader/utils/ActivityCompat;->onBackPressed()V

    const-string v0, "۠ۨۚ۫ۖۥۢۘۛ۠ۡۘۢۚۜۘ۠ۥۨۘۧۙۚ۟ۛ۠ۥ۫ۨۧۙۘۘ۬ۡۧۘۦۖ۬ۚۡۥۜۘۖۘ۫ۤ۠۟ۚ۟"

    goto :goto_2

    :sswitch_1f
    const v0, 0x7f1200f2

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const-string v0, "ۖۚۘۘۘۧۦ۫ۢۖۘۦۙۖۘۦۚۨۘۚۢۨۘ۠۬ۜۚ۠ۜ۫۟ۛۛۗ"

    goto :goto_2

    :sswitch_31
    return-void

    :sswitch_data_32
    .sparse-switch
        -0x5511d03c -> :sswitch_16
        -0x47cde74b -> :sswitch_1f
        0x154ed54d -> :sswitch_31
        0x5b4c117b -> :sswitch_19
    .end sparse-switch
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 8

    const/4 v5, 0x1

    const/4 v4, 0x0

    const-string v0, "ۘۚۨ۟ۦۦۙ۟ۧۨۗۗۢۦۘۥ۟ۥۘۗۧۤۡۖ۟ۜۘۘۘۢ۫ۤ۬ۢۨۘ۬ۖۨۘ۫ۙۗۘ۟ۦۘۧ۫ۜۘ۬ۡۥۘ"

    :goto_4
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x32

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x34c

    const/16 v2, 0x7c

    const v3, -0x38a64739

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_1ae

    goto :goto_4

    :sswitch_18
    const-string v0, "ۢۚۘۘ۫۠۫ۥۘ۟ۚۢۜۛۧ۫۫ۡۧۘ۫ۖۡۘۗۧۨۘ۬ۗۘۖۦۨۛۤ۠ۧۤۧ"

    goto :goto_4

    :sswitch_1b
    const-string v0, "۬ۦۖ۠ۥۨۗۤۜۘۗۗۙۡۧۧۘۖۢۤۙۚۨ۠ۙۧۖۛۙۡ۟ۚۢۡۜۙ۬ۤۨۗ۟ۘۨۦۤ۫ۚۘۘ۠۬ۚۚۡۨۘ"

    goto :goto_4

    :sswitch_1e
    invoke-super {p0, p1}, Lpubgm/loader/utils/ActivityCompat;->onCreate(Landroid/os/Bundle;)V

    const-string v0, "ۥۥۢ۬ۗۤۖۜۤۗۘۘۧ۬ۢ۫ۘۧۘۜۚ۫ۢۡۛ۫ۖۘ۠۬ۧ"

    goto :goto_4

    :sswitch_24
    const v0, 0x7f0c0021

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->setContentView(I)V

    const-string v0, "ۙ۠ۚۚۙۙۗ۟ۗۘۚۜۛۢۖۘۨۥۨۘۧۗۨۘۘۨ۬۫ۗۖۛۨۙۨ۬ۧ۠ۜ۟ۘۘۖۖۥۘ۫ۗ۬۫ۙۧۙۙۡۤۨۥۘ"

    goto :goto_4

    :sswitch_2d
    new-instance v0, Lpubgm/loader/activity/CrashHandler;

    invoke-direct {v0, p0}, Lpubgm/loader/activity/CrashHandler;-><init>(Landroid/content/Context;)V

    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const-string v0, "ۛ۬ۜۘۜ۫۟ۛۦۚۢ۟ۧۚۖۦۘۘۘۗۧۚ۬۫ۤ۬ۨ۟۬۟۟۫۬۟۬۠ۘۘ۟ۧۢۖۛۙ"

    goto :goto_4

    :sswitch_38
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->init()V

    const-string v0, "ۙ۬ۙ۟۟ۦۥۥۘۖۖۨۘۡۦۧۘۡۨ۫ۥۥۚۗۡۙۘ۬ۡ۟۠ۖ۠ۛۙۤۖ۠۫ۢۦۨۥۘ"

    goto :goto_4

    :sswitch_3e
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->initMenu1()V

    const-string v0, "ۨۥۢۜۖۜ۬۠ۖۡۙۤۦۛۖۘۥ۬ۦۘۛۚۤ۠ۢۚۜۡ۟ۗۚ۫"

    goto :goto_4

    :sswitch_44
    const v1, 0x70127898

    const-string v0, "ۥ۟۟۟ۛۜۘۤۛۥۤۗۦۘۡۡۤۧۗۖۗ۠ۨۘۖۥۘۘۢۖۘۘۚۢۥ۫۫ۢ۟ۙ۟ۜۧۥۘۚۜۖۤۧۘۛ۬ۘۘۤۜۛۚۤۘۘ"

    :goto_49
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_214

    goto :goto_49

    :sswitch_52
    const-string v0, "ۙ۟ۦ۠ۘۡۤ۫ۗۨۖۥۡۖ۫ۧۗۨۦ۟ۙ۫ۦۘۘ۠ۦۘۡۘۜۘ"

    goto :goto_4

    :sswitch_55
    const-string v0, "ۨ۠ۥۥۡۤۦ۫ۜۛ۫ۙۨۙ۬ۡۛۖۘۗۙ۬۫ۦۜۘ۫۬ۧۡۙۚ"

    goto :goto_49

    :sswitch_58
    const v2, 0x431ba3a8

    const-string v0, "۬۠ۧۤۤۖۤۖۘۛ۠ۖۘۙۚۥۜۚۡۘۘۘۨ۟ۘۜ۟ۢۥۘۧۘۗۥۨۖۘ۫ۢ۟ۦۛۤۦۙۗ۬ۛۗ۫ۢ"

    :goto_5d
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_226

    goto :goto_5d

    :sswitch_66
    const-string v0, "ۦۡۡۧۦ۠ۗۖۧۘۛۨۧۘۧۦۘۙ۟ۢ۟ۨ۟ۚۚۜۥۤۗۘ"

    goto :goto_49

    :cond_69
    const-string v0, "ۢ۟ۡۘ۫ۚ۬ۤۢۚۖۛۗۖ۫۫ۖ۫ۖۨۗۥۘۥۦۜۖۦۥۘ۟۟۫ۥ۬ۚۡ۠ۘۘۨۢۥۚۤۥۘۖ۬ۥۘۜ۫ۡۘ"

    goto :goto_5d

    :sswitch_6c
    invoke-static {}, Lcom/topjohnwu/superuser/Shell;->rootAccess()Z

    move-result v0

    if-nez v0, :cond_69

    const-string v0, "ۡۥۛۚۡۘۜ۫ۢۨۛ۫ۢ۟ۦۘۛۢۧۜۢۦۘۘۡۚۨ۠ۥۘۤۛۗ۫۫۠ۜۚۦ"

    goto :goto_5d

    :sswitch_75
    const-string v0, "ۡ۠ۧۖۢ۬ۦۢۡۙۢ۟۠۫ۨۜۚۢۘۤۢۖۦۜۦۡ۬۫ۤۧۛۧۦۘۦ۬ۛ۬۟ۧۚ۬۫ۢۨۥۘ۫ۦۖۜ۠۟"

    goto :goto_5d

    :sswitch_78
    const-string v0, "۟ۦۧۘۙ۠ۚۨۛۚۘ۟ۙۦۚۖۘۛۖۘۘۨۥۦۘۡۗۘۘ۠ۖۗۨۙۥۘۥۤۢۚۛۡۥۛۨۘۚۤۨ"

    goto :goto_49

    :sswitch_7b
    const-string v0, "۟ۤۜۘۖۗۢۤ۬۫ۜۗۡۧ۠ۛۛۨۧ۫ۢ۟ۢۖۢ۠۟ۥۘۤ۠ۨ"

    goto :goto_4

    :sswitch_7e
    const v1, 0x42aa0187

    const-string v0, "ۨ۫۟ۖۗ۟ۦۖۧۛۜۖۜۥۢۢ۬ۖۤۢۘۢۜۘۙۜۘۦۦۥ۟ۦۘۥۚۥۘ"

    :goto_83
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_238

    goto :goto_83

    :sswitch_8c
    const-string v0, "ۘۢۤ۟ۘۘ۟ۡ۠۬ۜۜۖۢۦۨۨۘۦۚ۠۟ۗ۫ۤۢۙۙ۬ۦ"

    goto :goto_83

    :sswitch_8f
    const-string v0, "ۖ۫ۨۘۤۗۤۥۨۖۙ۬ۗۨۛ۟ۨ۫ۚۥ۟ۛۤۤ۫ۢۛۖ۬ۡۨۥ۫ۧۤۤۖۚۙۚۡۡۤ۫ۧۡۗۦۚۥ۬۫۫۠ۤ"

    goto :goto_83

    :sswitch_92
    const v2, 0x5b75ec28

    const-string v0, "ۙۧۖۢۥۜۘۥ۟ۙۚ۬ۛۚۙ۠ۢۘۨۘۗۤۘۥۛۘ۠ۗۧ۟ۡۦ"

    :goto_97
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_24a

    goto :goto_97

    :sswitch_a0
    const-string v0, "۫ۙۙۚۜۜۘۜۡۦۘۦ۬ۘۜ۟ۥۦۗۢۥۗۦۜۜۦۘ۟۟۬ۨۚ"

    goto :goto_97

    :cond_a3
    const-string v0, "ۥۙۛۤۜ۟ۖۛۦ۠ۨ۬ۨۤۡۨۘۤۙۗۤۢۧۘ۟ۨۖۥ۫"

    goto :goto_97

    :sswitch_a6
    invoke-static {}, Lnet_62v/external/MetaActivationManager;->getActivationStatus()Z

    move-result v0

    if-eqz v0, :cond_a3

    const-string v0, "ۧۨۧۘۜۗۚۤۤۖۢۗۨۖۜۙ۬ۚۜۘۛۦ۫ۖۨۖۢۢۛۖۧۦۤۢۜۨۘۖۘۧۘۧۢۚۜ۟ۢ۬ۧۡۘ"

    goto :goto_97

    :sswitch_af
    const-string v0, "ۡۦ۟ۘۜۚۛۘۚۘۖۘۛۧۢ۬ۡۥۚۥ۬ۖ۟۟ۥۥۘ۫ۖۦۘ۟ۧۘ۠ۦۛۛۘ۬ۢ۟ۖ۬ۛ۬ۨۤ۠ۡ۬ۦۘۖۛۙ"

    goto :goto_83

    :sswitch_b2
    const-string v0, "۟ۖۡۙۢۛۢ۟۫ۘۡۨۛۜۘۗ۟ۜۘۚ۬ۗۧۧۡۘۧۡۢۚ۠ۥۘۥۢۢۧۨۖۨۜۘۗۡ۠"

    goto/16 :goto_4

    :sswitch_b6
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-wide v2, -0xd32a08f3c3a53bdL  # -1.002794753922761E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const-string v0, "ۨۢۦۛ۬ۥۘۥۡۡۘۜۡۦۘۨ۬ۡۘ۬ۡۦۙۡۢۥۥۚۖۨۧۢۙۡ"

    goto/16 :goto_4

    :sswitch_ce
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-wide v2, -0xd32a0643c3a53bdL

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const-string v0, "ۙ۟ۦ۠ۘۡۤ۫ۗۨۖۥۡۖ۫ۧۗۨۦ۟ۙ۫ۦۘۘ۠ۦۘۡۘۜۘ"

    goto/16 :goto_4

    :sswitch_e6
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->initMenu2()V

    const-string v0, "۫۠۬ۧ۠ۜ۟ۦۖۗۧ۟۟ۡۥۤۜۥۤۡۜۛۥۦۘۡۧۗۨۨ۟ۥۗ۠ۖۖۤۘۛۧۦۙۜۘۤۢۧۜۙۙ۠ۛۛۘ۠۠"

    goto/16 :goto_4

    :sswitch_ed
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->Loadssets()V

    const-string v0, "۟۠ۗۘۙۖۘۡۜۥۘۘۛۡۜۗۥۨۥۨ۫۫۠ۡ۟ۧۘ۫ۛ۫ۘۖۖ۫ۨۢۦۘۙۖۡۘۧۚۘۘ۫ۡۦۘۘۘۖۙۛۜۘۙۡۧ"

    goto/16 :goto_4

    :sswitch_f4
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->devicecheck()V

    const-string v0, "ۡۙۜۘ۫ۧۜۘ۠۫ۡۘ۬ۢۖۖۚۘ۬ۦۙۦۨ۫ۡۗۥۖۥۨۘۛۖۜۧۛۦۗۡۘۙۧۗۜۤۧۗۚۨ۟۟۫"

    goto/16 :goto_4

    :sswitch_fb
    const-wide v0, -0xd32a05d3c3a53bdL

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->loadAssets(Ljava/lang/String;)V

    const-string v0, "ۥۛۖۘۖۥ۟۠ۘۥ۬۬ۖۖۘۖۗ۟ۡۘۨ۟ۦۘۖۜۥۘ۟ۖۛ۠ۤۚۙۘۘۛۦۧۘۚۨۗۦۥۥۙۡۧۘ۠ۜ۫۠ۥۦۘۚۦۧۘ"

    goto/16 :goto_4

    :sswitch_10b
    const v1, 0x731386c7

    const-string v0, "ۡۛۛ۬ۧۙۗۦ۫ۧۗ۫ۤۙۙ۟ۛۙۨۦۡۖ۠ۙ۬ۜۨۖۥۢۘۘ۠۫ۥۡۨ۟ۡۜۧۤۨ۫ۨۤۘۚ"

    :goto_110
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_25c

    goto :goto_110

    :sswitch_119
    const v2, 0x5517fe6e

    const-string v0, "ۙۨۘۘۙۗۨۗ۫۫ۨۖۢۢۤۖۘۤ۬ۜۘۛۛۖۘۘۛۨۤۗۦۢۙۜۘۧۜۥ۠ۛۦۘ"

    :goto_11e
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_26e

    goto :goto_11e

    :sswitch_127
    const-string v0, "ۤۚۨۘ۫ۛۚۗۚۥۘۜۥ۬۟ۚۛۥۥۦۘۤ۫ۜ۠ۡۚ۫ۡۘۧۢۨ"

    goto :goto_11e

    :sswitch_12a
    const-string v0, "ۜۛۛ۫ۧۜۦۘۖۧ۬ۙۘۙۥۘۦ۬ۚۡۙۡ۫ۚۦۘۖ۫ۦۖۜۨۢۛۨ۫ۡ"

    goto :goto_110

    :cond_12d
    const-string v0, "ۖۜۢۨۡۥۘۜۨۘۗۛۙۧ۟ۧۛ۫ۨ۫ۚۢۧۛۙۗۘۡ۟ۜۤ۟ۨۜۧۧۥۘۜۥۥۙۚ۠۬ۘ۠ۢۨۜ"

    goto :goto_11e

    :sswitch_130
    sget-boolean v0, Lpubgm/loader/activity/SplashActivity;->mahyong:Z

    if-nez v0, :cond_12d

    const-string v0, "ۚۧۦۘ۫۠ۡۘۖۗۘۤۡۡۘۙۛ۠ۚۨۖۘۙۢۨۡۥۙ۠ۤۧ۫۠ۢۛ۬ۗۛۜۖۨۗۥۘۦۦۢ"

    goto :goto_11e

    :sswitch_137
    const-string v0, "۟ۗ۫ۘۚۨۘۥ۠۬ۨ۫ۥۘۦ۫ۘۘ۫ۖۙۖۨۗۗۖۧۚۘۘ۫ۖۧۤۧۧ۟ۥۧ۠ۡۡۘ۫ۙۦۘ"

    goto :goto_110

    :sswitch_13a
    const-string v0, "۟ۚۥۖۢۖۘۖۢۧۥۢۡۧۦۦۘ۟ۗ۟ۛۦۘۘ۟ۜ۟ۨۨۘ۫ۡۨۖۙۙۜ۬ۡ۬ۦۛ۬۬ۖۙۨۦۘ۠ۡۦ"

    goto :goto_110

    :sswitch_13d
    const-string v0, "۫ۤ۬۠۟۠ۤۛۦۙ۫ۘۛۙۖۘ۟ۜۦۘۘۨۜۘۥۜۜۘۖۨۡۥۛۦۙۜۚۛۜۦۘۗۙۙۦ۠۠۬ۢ۠ۘ۠ۦۗ۬ۘۘ۬ۛۡۘ"

    goto/16 :goto_4

    :sswitch_141
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->finish()V

    const-string v0, "۫ۢۦۤۖۥۘۤۨۚۧۧۜۗۜۖۘۖ۬ۛۘۨۘۗۗۘۘۦۜۘۘ۫۫ۘۗ۫ۥۘۚ۟ۖۘ۬۫۠۠ۥۢۤۘۥۜۜ۟"

    goto/16 :goto_4

    :sswitch_148
    invoke-virtual {p0, v5}, Lpubgm/loader/activity/MainActivity;->finishActivity(I)V

    const-string v0, "ۨۘۜۘۨۙۡۛۧۢ۬۟ۨۘۨۖۡۢۛۛۦۛۙۦۖ۬ۦۚۡۦۡۘۖۥۥۘ۫ۜۥۘ۬ۢۢۥ۠ۡۘ۬ۡۜۛ۠ۛ"

    goto/16 :goto_4

    :sswitch_14f
    sget-object v0, Lpubgm/loader/server/ApiServer;->AppChecker:Lpubgm/loader/server/ApiServer;

    const-string v0, "ۜ۠ۥ۬ۢۡۘۤ۠۠ۧۜۘ۫ۘ۟ۤۨۥۤۥۘۘۥۙۗ۫ۥۧۥۧۤۤۘۗۗۘ۠۫ۖۧۗ۟ۙ"

    goto/16 :goto_4

    :sswitch_155
    const v1, -0xc386dab

    const-string v0, "ۤۜ۫ۧۥۖۢ۫ۙۛۗۜۘۡۤۡۘۧ۠ۨۨۦ۬ۡۛۘۢۧۛۥۖۘۛۨۚۗ۟ۖۚۖۢۘ۬"

    :goto_15a
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_280

    goto :goto_15a

    :sswitch_163
    const-string v0, "ۜۙۤۜۦۢۥۜۜۘۛۢۜۛۜۘۙۡۖۘۡۘۧۛ۟ۨۚۘ۬۫ۧۡۧۥۨۘۚ۠ۦ"

    goto/16 :goto_4

    :sswitch_167
    const-string v0, "ۚۗۧۚۛۘۘ۬ۜۘۨ۠ۙۙۙۡۦۨۜۘۜۢۦۘۦ۫ۥۘۗۤ۬ۛۖۢ۠ۘۗ۫ۡۤۖۜۘۥۚۖۘ"

    goto :goto_15a

    :sswitch_16a
    const v2, -0x58c50877

    const-string v0, "ۚ۟ۘۡۥۢۧ۠ۢ۫ۘۦ۬۟ۧ۬ۘۖۙۛۧۖۧۜ۟ۛۦۛۙۥۛۧۥۚۙۖۘۜۖۜۘۛۦ۫ۥ۫ۙۗۛۜۘۡۥ۟ۨۘۦ"

    :goto_16f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_292

    goto :goto_16f

    :sswitch_178
    const-string v0, "ۥۚۘۘۡۧۜۡۦۦۡۨۚۛۤ۬ۧۜۘ۟ۨ۬ۚۚۗۙۧ۬ۥۧ"

    goto :goto_16f

    :cond_17b
    const-string v0, "ۖۢ۬ۧۥۘۜۖۜۗۜۘۙۜ۫۬ۢۜ۟ۤۘۘۚۚۖۖۙۤۛۜۖۛۧۖۘۗۧۦۘۖۗۥۖۗ۫۠ۚ۫ۢۦۚۗۦۦ۠ۤۘۘ"

    goto :goto_16f

    :sswitch_17e
    invoke-static {p0}, Lpubgm/loader/server/ApiServer;->verifyAppLabel(Landroid/app/Activity;)Z

    move-result v0

    if-nez v0, :cond_17b

    const-string v0, "۫ۢ۬ۤۘ۟ۛۡۘۘۜ۫۬ۧۨۘ۬ۛۡۥۨۚۜ۟ۜۛۜ۬ۖۦۘۦۙ۬ۚۨۥۘۗۖۜۘ۫۠ۧ"

    goto :goto_16f

    :sswitch_187
    const-string v0, "ۧۧۘۨۤۦۡۚ۬۬۠ۖۘۚۛۥ۟ۚ۠۬ۢ۬ۤۢۡۘۘۜ۠ۚۨۘۘ"

    goto :goto_15a

    :sswitch_18a
    const-string v0, "ۛۨۦۘۥۜ۠ۛۦۙۙۛۙۚۡۘ۟ۦۖ۠ۡۦۡۧ۬ۜ۠ۛۘ۠۫ۚۥۜۘ۟ۡ۬ۢۚ۟ۧۦۘۖۙۦۙۥ"

    goto :goto_15a

    :sswitch_18d
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->finish()V

    const-string v0, "ۨ۫ۘ۠ۜ۬ۗۢ۠ۗۛۘۘۢ۠ۜۘۛ۫ۨۛۢۜۘۛۛۛۛۧۥۘۧۤۦ"

    goto/16 :goto_4

    :sswitch_194
    sput-object p0, Lpubgm/loader/activity/MainActivity;->instance:Lpubgm/loader/activity/MainActivity;

    const-string v0, "ۗۗۥۘۨۚۚۛۢۗۜۗۚۢۢۜۘۡۘ۟۬۬ۛۙۖۛۡۥۢۘۙۤۢۦۜۘۧۙۛۗۜۘۢۙ۟ۜ۬۫ۥۡۨۘ۬ۢ۠ۙۙ۬"

    goto/16 :goto_4

    :sswitch_19a
    iput-boolean v5, p0, Lpubgm/loader/activity/MainActivity;->isLogin:Z

    const-string v0, "ۖۚۙۨۨۖۥۛۙۤۖۘۘۛ۟ۜۙۖۡۧۘۚۢۜۙۘۜۢۨۤۦۦۘ۟ۤۙۧۜۥۥۖۤ۟۟ۚۖۗۦۤ۠ۨۦۖۛ"

    goto/16 :goto_4

    :sswitch_1a0
    const-string v0, "ۦۡۡۘۤۚ۠ۤۦۘۥۙ۬ۡۤۨۧۘۙۖ۫۬ۥ۫۟ۛۚۗۙۘۘۜ۬ۜۡۡۘۖۖۨۜۘۡۤۚۡۘۙۗ۬"

    goto/16 :goto_4

    :sswitch_1a4
    const-string v0, "ۨۘۜۘۨۙۡۛۧۢ۬۟ۨۘۨۖۡۢۛۛۦۛۙۦۖ۬ۦۚۡۦۡۘۖۥۥۘ۫ۜۥۘ۬ۢۢۥ۠ۡۘ۬ۡۜۛ۠ۛ"

    goto/16 :goto_4

    :sswitch_1a8
    const-string v0, "ۨ۫ۘ۠ۜ۬ۗۢ۠ۗۛۘۘۢ۠ۜۘۛ۫ۨۛۢۜۘۛۛۛۛۧۥۘۧۤۦ"

    goto/16 :goto_4

    :sswitch_1ac
    return-void

    nop

    :sswitch_data_1ae
    .sparse-switch
        -0x7c2633cd -> :sswitch_148
        -0x673ef0ca -> :sswitch_1e
        -0x631d0859 -> :sswitch_18
        -0x5c8c6b82 -> :sswitch_19a
        -0x521c8085 -> :sswitch_10b
        -0x39816603 -> :sswitch_44
        -0x27366834 -> :sswitch_b6
        -0x249a6918 -> :sswitch_1ac
        -0x22ffae02 -> :sswitch_14f
        -0x21f135d7 -> :sswitch_155
        -0x1d895f83 -> :sswitch_ce
        -0x16d66188 -> :sswitch_f4
        -0x2e5999b -> :sswitch_1b
        0x576817 -> :sswitch_194
        0x13939a39 -> :sswitch_38
        0x1ec782ed -> :sswitch_24
        0x26b3b170 -> :sswitch_ed
        0x2e9d5c72 -> :sswitch_18d
        0x2f3c1cd4 -> :sswitch_52
        0x49c80472 -> :sswitch_fb
        0x58a3e2b3 -> :sswitch_2d
        0x67cc447c -> :sswitch_7e
        0x7158263a -> :sswitch_3e
        0x73a6e1d1 -> :sswitch_141
        0x7ae02279 -> :sswitch_e6
    .end sparse-switch

    :sswitch_data_214
    .sparse-switch
        -0x56b88ed5 -> :sswitch_52
        -0x10577436 -> :sswitch_78
        0x18640229 -> :sswitch_58
        0x5b9865ea -> :sswitch_7b
    .end sparse-switch

    :sswitch_data_226
    .sparse-switch
        -0x41bb72c6 -> :sswitch_66
        -0x193f319b -> :sswitch_6c
        0x13a858f6 -> :sswitch_55
        0x78eba55e -> :sswitch_75
    .end sparse-switch

    :sswitch_data_238
    .sparse-switch
        -0x769be2cd -> :sswitch_8c
        -0x57b3f109 -> :sswitch_b2
        -0x1d5b7010 -> :sswitch_1a0
        -0x25e83cb -> :sswitch_92
    .end sparse-switch

    :sswitch_data_24a
    .sparse-switch
        -0x2ca1bb4f -> :sswitch_af
        -0x5db24a4 -> :sswitch_8f
        -0x340abd6 -> :sswitch_a0
        0x6dee2369 -> :sswitch_a6
    .end sparse-switch

    :sswitch_data_25c
    .sparse-switch
        -0x3c41519a -> :sswitch_13a
        -0x127e550c -> :sswitch_119
        0x3da616f1 -> :sswitch_1a4
        0x6b2bc7bf -> :sswitch_13d
    .end sparse-switch

    :sswitch_data_26e
    .sparse-switch
        -0x20a3296a -> :sswitch_137
        0x1949eb6d -> :sswitch_127
        0x25d0e734 -> :sswitch_130
        0x6d5441b6 -> :sswitch_12a
    .end sparse-switch

    :sswitch_data_280
    .sparse-switch
        -0x7951a4ce -> :sswitch_1a8
        -0x64f688d -> :sswitch_16a
        0x2f7c9202 -> :sswitch_18a
        0x4155b66d -> :sswitch_163
    .end sparse-switch

    :sswitch_data_292
    .sparse-switch
        -0x1565bc90 -> :sswitch_187
        -0x1142f33 -> :sswitch_167
        0x31bf8783 -> :sswitch_17e
        0x4c243991 -> :sswitch_178
    .end sparse-switch
.end method

.method public onDestroy()V
    .registers 5

    const-string v0, "ۧۜ۟ۘۗ۠۬ۛۥۘۜۛۙ۠۠ۙۖۖ۟ۘۥۘۘۙ۬ۘۤۜۦۗ۬ۗۦۖۦۘ۠ۧۖۘ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xa4

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x2b3

    const/16 v2, 0x1ee

    const v3, 0x1cf44f61

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_76

    goto :goto_2

    :sswitch_16
    const-string v0, "ۘۧۜۘۛۙۚۧۧۨۘۨۛۜۤ۬۫۬ۦۘۛ۫۟ۘۚ۫ۗۢۖ۬ۘۜۘ۬ۢۘۘۨۤ"

    goto :goto_2

    :sswitch_19
    invoke-super {p0}, Lpubgm/loader/utils/ActivityCompat;->onDestroy()V

    const-string v0, "ۜۛۚ۠ۖۙۘۛ۫ۡ۫۟ۦ۟ۖۢۙۧۘۡۗ۬ۦۥۡۙۨۧ۠۫ۡ۟ۙۦۤۨۙۢۘۘ۟۬ۧ"

    goto :goto_2

    :sswitch_1f
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/FloatingService;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "۬ۧۦۚۖۚۨۖۡۥۥۦۘۧۦ۟ۦۧ۟۟ۚ۫۬۟ۗۚۨۦۨۧۨۚۤۜ۠ۘۛۨۙۢ۠۫۠"

    goto :goto_2

    :sswitch_30
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/Overlay;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "ۥۖۘۘۘۛۖۘۢۡۗۙۙ۬ۥۜۨۘۖ۟ۖۙۥۧۘۨ۟ۛۢۤۚۜۨۡۡۢۖۛۛۘۘ"

    goto :goto_2

    :sswitch_41
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/ToggleBullet;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "ۡۤۘۘۨۚۖۘ۫ۛ۟ۤۖ۟ۡ۠ۥۦۖۡۘۤۛۧ۫ۚۘۘۥۜۧۘۘۙۛۧۨۥۘۤۨۛۦۘۤۧۤۜۘۖۡۙ۫۬ۡۡۙۙۛۜۘ"

    goto :goto_2

    :sswitch_52
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/ToggleAim;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "ۘۚۡۦۜۖۘۙۙۜۘۦۘۦۡۦۡۜۥۖۘ۫ۨۢۥۙۢۘۛ۬ۡۚۥۜۡۧۘۧۢۡ۟ۗۗۖۢۦ"

    goto :goto_2

    :sswitch_63
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, Lpubgm/loader/activity/MainActivity;->get()Lpubgm/loader/activity/MainActivity;

    move-result-object v1

    const-class v2, Lpubgm/loader/floating/ToggleSimulation;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lpubgm/loader/activity/MainActivity;->stopService(Landroid/content/Intent;)Z

    const-string v0, "۬ۨۦۗۗۥۘ۠ۘۥۦ۠ۦۜۢ۬ۧۡۦۘۚۢ۟ۘۧۘۧۤۨۘۥۨۤ۫۟۠ۢۖ۟"

    goto :goto_2

    :sswitch_74
    return-void

    nop

    :sswitch_data_76
    .sparse-switch
        -0x738896dd -> :sswitch_1f
        -0x4eb5598b -> :sswitch_41
        -0x495337cd -> :sswitch_74
        -0x34fd74bf -> :sswitch_63
        -0x2603075d -> :sswitch_52
        0x23bc40f2 -> :sswitch_30
        0x41f65bc8 -> :sswitch_16
        0x77f6ef50 -> :sswitch_19
    .end sparse-switch
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .registers 8

    const-string v0, "ۦ۟۬ۧۛۘ۠ۨۘۥۨۥۘۜۨ۠ۙۤۧ۬ۦۛۗۛۡۘۨۙۖۚ۫ۚۥۜۢۤ۠ۙۛۡۗ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x18d

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x1

    const/16 v2, 0x308

    const v3, -0x57bf48cd

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_d8

    goto :goto_2

    :sswitch_16
    const-string v0, "ۜۡۚۤۤۘۡ۬ۜۤۙ۬ۨ۫ۙۡۚۡۦۗۡۘۢۡۘۧۙۨۡۧۥۡۘۖۚۡ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۖۦۜۘۤۗۨۦ۫ۡ۠ۤۗۛۡۡۘۜۥۨ۟۬ۜۜۨ۠ۧۥۦ۠ۧۨۚۤۡۘۦۖۥۘۚۜۜۦۨۚ"

    goto :goto_2

    :sswitch_1c
    const-string v0, "ۘۤۜۘ۫ۚۤۨ۫۬ۜۜۜۘ۫ۚۗۚۙۢۘۜۚۛۧۨۘۛۙ۬ۡۘۢۘۙ۟ۡ۟ۧۢ۠۬ۢۢ"

    goto :goto_2

    :sswitch_1f
    const-string v0, "ۘۦۨۘۥۛۚۜۨۨۨۚۜۘۖۜۧۘۛۛۦۘۤۧۧۤۤۜۨۢ۠ۡۘۘۦۧۗۧۘۨۛۤۤۥۧۢ۟ۚۖۘۙ۬ۦۘۡۛۦۗۚ۟"

    goto :goto_2

    :sswitch_22
    invoke-super {p0, p1, p2, p3}, Lpubgm/loader/utils/ActivityCompat;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const-string v0, "۠۠ۦۘۛۨۜۜ۬ۜۘۚۤۖۘۚۘۖۥ۬ۛۤۥ۬۠ۤۖۘۤۜۧۘ۠ۛۛ"

    goto :goto_2

    :sswitch_28
    const v1, -0x65108ad6

    const-string v0, "۟ۛۨۘۦۘۧ۟ۖۦۘۙۧۧۖۡۘۛ۬ۢ۟ۡۡۘ۬ۙ۬۠ۥ۠۠۬ۥ۬۫ۨ۬ۤۨۘ۟ۦۖۙۢۨۘۡۧۘۤۘۤ"

    :goto_2d
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_102

    goto :goto_2d

    :sswitch_36
    const-string v0, "ۢ۟۬ۙ۠۬ۧۚ۬ۘۧ۠ۖۧۙۢۥۡۜۗۨۘۡۘۢۚۥۥ۟ۛۘ۠ۦۜۘ۫۫ۘۙۗۘۘۖۢۚۨۧۜۡۗۘۤۥۚۖۚۥ"

    goto :goto_2

    :sswitch_39
    const-string v0, "ۧۢ۠ۜ۬ۡ۠ۘۛۜۛۗۛۗۖۘۗ۫ۜۨۗۦۘ۠ۢۖۡۙۥۘۘ۫ۡ۟ۦۨۘۗۘۜ"

    goto :goto_2d

    :sswitch_3c
    const v2, -0x54c50c05

    const-string v0, "ۢۙ۫ۘۚۤ۠ۥۗۥ۟ۦۘۨ۠۬ۧۡۡۘ۟ۛۜۙۙۨۖۤ۠ۦۚۚۤۛۡۘۛۗۘ"

    :goto_41
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_114

    goto :goto_41

    :sswitch_4a
    const-string v0, "ۛۗۜۛۧۤۗۜۘۘۗ۟۫۫ۨۥۤۢۙۡۜۘۜۗۖ۟ۦ۫ۗۧۥ"

    goto :goto_2d

    :cond_4d
    const-string v0, "ۤۨۥۘ۟ۤۦۘۤۨۨۘۜۘۜۘۢۢۤ۬ۙۜۘۤۚۚۧۚۥۘۢۧ۬ۡۡۘۨ۬ۨۘۘۖ"

    goto :goto_41

    :sswitch_50
    const/4 v0, 0x1

    if-ne p1, v0, :cond_4d

    const-string v0, "ۤ۟ۤۜۧۗ۫ۧۗۚۡۚۗۥۜۘۙۤۜۘ۠۠۟ۥۧۘ۠ۨۤۦۤۘ۬ۖۘ۠ۥۘۘۤۚۢۖۡۨۘۢۢۙۚۢۛ"

    goto :goto_41

    :sswitch_56
    const-string v0, "ۜۥۖۚۤۚۢۚۡۘ۠۬ۥ۬ۧ۬ۢۗ۠ۦۖۖۘۙۗۛۤ۫۫۬۟ۨۘۘ۠۬ۗۗۗۨۚ۟ۖۢۚ"

    goto :goto_41

    :sswitch_59
    const-string v0, "۬ۤۡۜۡۨۘۙۧۡۢۨۙۘۜۗ۬ۧۢۧۘۘ۟ۡۙ۫ۦۘۖۙۘۘۤۚۘۘ۠ۗۧۥ۫ۤۛۘ۟ۨۥۘۘۢۘۘ"

    goto :goto_2d

    :sswitch_5c
    const v1, -0x111f9488

    const-string v0, "۫ۛۧۨ۬ۚۦۖۜۘۡۧۛۙۦۧۖۤۘۛۥۘۛۤۥۘ۫ۡۜۢۖۛۧ۟۬ۦۥۨۖۘۜۖۜۘۖۗۦۘۚۥۤ۬۫ۙۖۧۘ"

    :goto_61
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_126

    goto :goto_61

    :sswitch_6a
    const-string v0, "ۖۨۧۚۖۢۘۚ۠۫ۜ۫ۖۨۢۘۡۗ۠ۡۥۗۥۘۘۛۥۧۛۧۥۘۙ۫ۗۤۤۘۘ"

    goto :goto_2

    :sswitch_6d
    const-string v0, "۠ۤۨۖۘۖۘۨۙۙۤۤۘ۬ۖۨ۠۟ۨۘ۫۟ۦ۫۬ۡۘ۟۬ۗۢۨۧۤۘۗۖۗۜ۟۬ۦۘ۬۟ۢ"

    goto :goto_61

    :sswitch_70
    const v2, 0x63b43043

    const-string v0, "ۧۤ۠ۖ۫ۙ۬۠ۜ۫ۛۦۘۡۙۦۘۨۖۥۘ۫ۦۘۨ۫ۡۘۚ۬۟ۖۧۡۗۥۤۥۛۛۜۡۘۛۖ۬"

    :goto_75
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_138

    goto :goto_75

    :sswitch_7e
    const-string v0, "ۜۨۤۖۗ۫ۦۛۖۘۗۗۢۜۤۡۘۛ۬ۥۡۥۤ۟ۦۘ۫۬۬ۜۡ"

    goto :goto_61

    :cond_81
    const-string v0, "ۢۨۢۡۧۘۘۤۧۡۘۥۥۨۢ۟ۥ۫ۥۘۘۨۥۦۘۜۘۜ۫ۤۘۗۧۖۘۥۘۚۖۛۗۥۥۘۛۘۘ۠ۗ۫ۚ۬ۗۚۡۨۘۦۘۜ"

    goto :goto_75

    :sswitch_84
    array-length v0, p3

    if-lez v0, :cond_81

    const-string v0, "ۥ۫ۢۙ۬ۨۗۙۗۥۘ۠ۦۢۥۡۚ۟ۥۜۘۙۡۢۖ۠ۥۘۢۢۜ۫ۗۡۘۖۜ۫۫ۦۜۘۥ۠۬ۛ۬ۘ۫ۡۙ"

    goto :goto_75

    :sswitch_8a
    const-string v0, "ۘۘۜۘۢۤۖ۬۟ۗ۬۬ۜۨۖۘۘ۟ۗ۬ۥۨۤۚ۟ۦۘ۫ۘۗۤ۠ۢ۫ۧۛ۬ۜۗۗۡۘ"

    goto :goto_75

    :sswitch_8d
    const-string v0, "ۖۙۖۘ۬ۛۧۦۗۖۘ۬ۤۧۦۜۦ۬ۙۙۢ۟ۢۨۗۙۨۚۢۤۛ۟۫۠ۨ۬۬ۦۢۥۦۘ۟ۨۜ"

    goto :goto_61

    :sswitch_90
    const-string v0, "ۘۨۚۙۘۖۘۧۘ۠ۨ۬۫ۛۙۡۘ۫ۚۤ۟ۗۨۙۙۡ۬۟ۦ۫ۖ۫۠ۥۨۘۥۢۘۡ۟۟ۦ۫ۘۘۧ۫ۛۨ۠ۗۨۨۡ۠"

    goto/16 :goto_2

    :sswitch_94
    const v1, -0x768ae25

    const-string v0, "ۚۜۧۘۗۧۜۘۙۢۚۗۨۦۘۖ۬ۦۘۢۨۗۦۢۜ۠ۘۘ۬ۗ۬۫۟ۨ"

    :goto_99
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_14a

    goto :goto_99

    :sswitch_a2
    const v2, 0x4df561a2  # 5.14602048E8f

    const-string v0, "ۛۢ۠ۢ۬۬۬ۛۨۤ۬ۚ۬ۦۛۚۛۜۘۗۛۛۦۘۧۦۥۛۗۙۗ۫ۙۡۘۖۧۚۖۡۧۤ۬ۡۘ۬ۖ۬ۗۥۘۡۘۖۘ"

    :goto_a7
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_15c

    goto :goto_a7

    :sswitch_b0
    const/4 v0, 0x0

    aget v0, p3, v0

    if-eqz v0, :cond_bb

    const-string v0, "ۡ۠ۨۘۧ۠ۜۡۖۡ۫ۘ۠ۤۖۦۘۜۦۧ۬ۗۖۘ۠۬ۗۛۘۤ۟ۧۡۛۚ۠ۧ۬۟۠ۘ۫ۢۢۦۘۢ۠ۡۘۧ۬ۜ"

    goto :goto_a7

    :sswitch_b8
    const-string v0, "ۛ۟ۗۘۦۘۘۚۢۜۘۡۘۗۚ۫ۨۤۤ۫ۚۘۗۦۘۙۚۗۚۡۧۖ"

    goto :goto_99

    :cond_bb
    const-string v0, "ۗ۬۫ۤۘۜۛۚۘ۬ۢۙۗۚۥۘۢۛۘۗۡۦۤۙۙۡۛ۫ۛۛۗۤۙۦۘۛۥۛۧۛ۫۠ۜۡۘۖ۠ۨۘ۟ۛۖۙۚۥۧۤۨ"

    goto :goto_a7

    :sswitch_be
    const-string v0, "ۗۤ۟ۨ۠ۨۡۧۥۨۙۖۛۢ۠ۧ۟ۦۙۛۤۧۥۨۡۘۡۙۚۙۖۗۡۨ۟ۚۘۛ۠۫ۜۘۨۦۧ۬ۤۘۘۘۨ۟ۨۜۦۘ"

    goto :goto_a7

    :sswitch_c1
    const-string v0, "ۖ۬ۨۘۡۢۢ۫ۢۦ۠ۧۖۘۚۛۘۘۜۥۡۘ۫ۢۚ۫۫۫ۨۘۢۚۖۘ"

    goto :goto_99

    :sswitch_c4
    const-string v0, "ۛۗۦۘۘۨۨۤۧۡ۫۬ۤۧۙۢۙ۬ۤ۫ۛۖۧۘۡ۠۫ۤۚۘۜۘ۠ۚ۫۟ۢ"

    goto :goto_99

    :sswitch_c7
    const-string v0, "ۖۨۧۚۖۢۘۚ۠۫ۜ۫ۖۨۢۘۡۗ۠ۡۥۗۥۘۘۛۥۧۛۧۥۘۙ۫ۗۤۤۘۘ"

    goto/16 :goto_2

    :sswitch_cb
    invoke-virtual {p0}, Lpubgm/loader/activity/MainActivity;->finish()V

    const-string v0, "ۙۚۢۤۛۚۘۡ۠۫۬ۦۘ۬ۥ۬ۜۜۦۘۢۦۤ۟ۗۦۤۙۧۥ۟ۘۖۤۡۘۨۨۦۢۨۧۘ۬۠ۜۘ"

    goto/16 :goto_2

    :sswitch_d2
    const-string v0, "ۙۚۢۤۛۚۘۡ۠۫۬ۦۘ۬ۥ۬ۜۜۦۘۢۦۤ۟ۗۦۤۙۧۥ۟ۘۖۤۡۘۨۨۦۢۨۧۘ۬۠ۜۘ"

    goto/16 :goto_2

    :sswitch_d6
    return-void

    nop

    :sswitch_data_d8
    .sparse-switch
        -0x3fae4f30 -> :sswitch_1f
        -0x3cfd3851 -> :sswitch_22
        -0x2fea3519 -> :sswitch_cb
        -0x8ffeb4b -> :sswitch_1c
        -0x543d620 -> :sswitch_28
        -0x270d7f0 -> :sswitch_19
        0x100cfec6 -> :sswitch_d6
        0x39a30b2b -> :sswitch_16
        0x6dac3012 -> :sswitch_5c
        0x7f6cc195 -> :sswitch_94
    .end sparse-switch

    :sswitch_data_102
    .sparse-switch
        -0x7ecd59fc -> :sswitch_3c
        -0x2ca7c7d1 -> :sswitch_36
        0x50fc42e2 -> :sswitch_59
        0x6702a141 -> :sswitch_d2
    .end sparse-switch

    :sswitch_data_114
    .sparse-switch
        -0x4e00f2fa -> :sswitch_50
        -0x36a38bb6 -> :sswitch_4a
        -0x163e617f -> :sswitch_39
        0x1d1f55f4 -> :sswitch_56
    .end sparse-switch

    :sswitch_data_126
    .sparse-switch
        -0x7a51c6af -> :sswitch_90
        -0x55fb2fc5 -> :sswitch_8d
        -0x1758abd3 -> :sswitch_70
        0x1eb8e3b4 -> :sswitch_6a
    .end sparse-switch

    :sswitch_data_138
    .sparse-switch
        -0x291dbc75 -> :sswitch_7e
        0x34cc641d -> :sswitch_6d
        0x6de8f970 -> :sswitch_84
        0x6e603caf -> :sswitch_8a
    .end sparse-switch

    :sswitch_data_14a
    .sparse-switch
        -0x4d416a04 -> :sswitch_a2
        -0x1468e5f5 -> :sswitch_d2
        0x3f4d600 -> :sswitch_c7
        0x5d7cc0b -> :sswitch_c4
    .end sparse-switch

    :sswitch_data_15c
    .sparse-switch
        -0x31e6bed6 -> :sswitch_be
        -0x2c6f5e77 -> :sswitch_b0
        0x1d55756e -> :sswitch_b8
        0x7d6f94b2 -> :sswitch_c1
    .end sparse-switch
.end method

.method protected onResume()V
    .registers 8

    const/4 v6, 0x0

    const-string v0, "ۧۖۢۜۥۦۢ۬ۥۘ۫ۖۘۛۤۨۜۡۡۘ۟ۡۘۘۢۤ۫۟۫ۙۢۜۘۘ"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x6e

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x3f1

    const/16 v2, 0x61

    const v3, -0x6435d404

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_9e

    goto :goto_3

    :sswitch_17
    const-string v0, "ۡۙۡۚۦ۬ۢۚۜۘ۫ۢۘۘۛۚۖۘ۠۟ۛ۫ۛۛۗ۟ۖۘ۠ۙۖۖ۬ۦ۬ۚۘۘۤ۬ۜۘ"

    goto :goto_3

    :sswitch_1a
    invoke-super {p0}, Lpubgm/loader/utils/ActivityCompat;->onResume()V

    const-string v0, "ۧۛ۠ۖۜ۬۬ۜۥۘۨۡۥۖۤ۠ۘۥۘۚۗ۬ۦۤۥۢۛ۟ۡۦۥ"

    goto :goto_3

    :sswitch_20
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->CountTimerAccout()V

    const-string v0, "ۘۜۡۛ۬ۥ۟۟ۤۡۚۡۧۥۨ۬۬ۡۚۨۡۤۙ۠ۥۤۢ۠۬ۢۜۘۨۖۧۗۤۨۘۘۦۥۘۢ۟ۘۘۛۡۦ"

    goto :goto_3

    :sswitch_26
    const v1, -0xa7707e9

    const-string v0, "۫ۥۡ۟ۢۡۗۤۛ۟ۢۡۧۙۢۡۚۨۚ۬ۜۘۦۡۙ۠۟ۥۘۢۥۙۛۙۢۢ۫ۜۘ"

    :goto_2b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_b8

    goto :goto_2b

    :sswitch_34
    const-string v0, "۫۟ۤ۠ۖۨۙۥۘۙۥۜۘۧۦۖۘۖۙۥۘۥۛۡۘۚۛ۬ۜۤۥ۬ۗۘۦۡۘۨ۠ۖ"

    goto :goto_3

    :sswitch_37
    const-string v0, "ۗ۟ۡۘۛۗۡۦۡۡۙۤ۟ۤۧۨۘۡۥۡۨۡۗ۟۬۟۫ۦۨۘۡۚۗۘۛۖۘۙ۠ۛۜۜۖۘۦۛۘ"

    goto :goto_2b

    :sswitch_3a
    const v2, -0x16f7a127

    const-string v0, "ۡۤۚۚۛۨۦۛۜۘۡۖۦۙ۫ۧ۠ۛۨۤۤۤۚۗۘۘ۬ۥۦۘۜ۬ۤۤۚۦۤۡۧۘۘۘۜۧ"

    :goto_3f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_ca

    goto :goto_3f

    :sswitch_48
    const-string v0, "ۡۗۨۨۚۘۥ۟ۗۘۡۜۘۦۨۥۧۜۤ۟ۗ۠۫ۚ۟ۗۙۦۘۧۙۜۘۥۧ۠ۖ۟ۡ۫۬ۜ۫ۦۘۡۤۢۜۘۘۤ۫ۢۗ۫"

    goto :goto_3f

    :cond_4b
    const-string v0, "ۥۡۜۖۢۦۜ۠ۥۘۦۦۨۗۤۚ۟ۢۢ۠ۧۡۖۨۖۘۢۛۜۗ۟ۚ"

    goto :goto_3f

    :sswitch_4e
    const-wide v4, -0xd32ae683c3a53bdL  # -1.0009480264880299E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v6}, Lpubgm/loader/activity/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-wide v4, -0xd32ae563c3a53bdL  # -1.0009574033833261E245

    invoke-static {v4, v5}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_4b

    const-string v0, "۟ۡۖۜۦۙۙ۬۟ۛۙۢ۫۟ۡۧۗ۟۠ۡۦۤ۫ۖۘۚۜۨۥۛ۫"

    goto :goto_3f

    :sswitch_6d
    const-string v0, "۠۬ۦۘۡۢ۫ۤۥ۫۟ۙۘ۬ۥۜۡ۫ۗۜ۬ۗ۟ۦۜۨۤ"

    goto :goto_2b

    :sswitch_70
    const-string v0, "ۚۥۨۘۚۙۖۘۢۦۜۤ۟ۖۧۢۢ۠ۡ۫ۡۤۜۘۤۢۘۘۧۜۨۦ۫۟ۧ۟ۗۗۚۥۘۨۨۜۘۘۘۦۘۛۖۤۚۛۜۘۤۖۛۚۦۚ"

    goto :goto_2b

    :sswitch_73
    const-wide v0, -0xd32ae473c3a53bdL  # -1.0009652174627396E245

    invoke-static {v0, v1}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v6}, Lpubgm/loader/activity/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-wide v2, -0xd32ae4d3c3a53bdL  # -1.0009620918309742E245

    invoke-static {v2, v3}, Lio/michaelrocks/paranoid/Deobfuscator$app$Debug;->getString(J)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v6}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v0, "۠ۤۥۘۚۖۘۙۡۤۧۖ۠ۖ۟ۨۘۢۗۢۚۨۥۜۥۘۙۧۧۜ۠ۜ"

    goto/16 :goto_3

    :sswitch_98
    const-string v0, "۠ۤۥۘۚۖۘۙۡۤۧۖ۠ۖ۟ۨۘۢۗۢۚۨۥۜۥۘۙۧۧۜ۠ۜ"

    goto/16 :goto_3

    :sswitch_9c
    return-void

    nop

    :sswitch_data_9e
    .sparse-switch
        -0x533ffbad -> :sswitch_9c
        -0x33af6639 -> :sswitch_26
        -0x2cd79f7c -> :sswitch_73
        -0x63d853d -> :sswitch_1a
        0x62dab38 -> :sswitch_20
        0x2753caf7 -> :sswitch_17
    .end sparse-switch

    :sswitch_data_b8
    .sparse-switch
        -0x640fa027 -> :sswitch_34
        -0x567d77c8 -> :sswitch_3a
        -0x40d79bfd -> :sswitch_70
        0x7bab8bcc -> :sswitch_98
    .end sparse-switch

    :sswitch_data_ca
    .sparse-switch
        -0x785ea515 -> :sswitch_6d
        -0x3f7c2913 -> :sswitch_37
        0x592bd320 -> :sswitch_4e
        0x7efbf2f1 -> :sswitch_48
    .end sparse-switch
.end method

.method public onWindowFocusChanged(Z)V
    .registers 6

    const-string v0, "ۘ۠ۜۜۗۧۦۧ۬۫ۖۜۜ۫ۥۘۛۡۚۗۦۥۦۨۧۘۨۥۖۘۖۡۚۥۛۘۜۚۤۘ۫۬ۦ۠ۧ۫ۦۥۘۥ۠ۘۘ"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x121

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0xc2

    const/16 v2, 0x36e

    const v3, 0x5ad08b52

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_68

    goto :goto_2

    :sswitch_16
    const-string v0, "ۢ۫ۖۢۧۘۦۙۖۘۚۧۖۥۖۘ۬۠ۜۡ۟ۥۘۧۙۜ۠ۖۦۙۖۘۤ۬ۚ۫ۙۥۥۦۘۙۨۢۨۘۡۘۗۡۛ"

    goto :goto_2

    :sswitch_19
    const-string v0, "ۥۡۧۚۡۡۘ۫۟ۚۢ۟ۨۘۦ۟ۨۥۨۖۨۘۚۜۙۦۘۚۗۗۛۗۧۨ۠ۜۙۢۙۦۨۤۖۙۡۘۗۖۢۚۙۚۧۡۘ۠ۨۢ"

    goto :goto_2

    :sswitch_1c
    invoke-super {p0, p1}, Lpubgm/loader/utils/ActivityCompat;->onWindowFocusChanged(Z)V

    const-string v0, "ۢۛۦۡۧۧۦۗ۠ۛۡۦۛۤۙۖۘۚۥۖۚۜۙۤۦۨۘۚۥۡۘۜ۬ۡ۠ۢۥۢۘۤۘۥۢ۟ۨۘۙۖۘ"

    goto :goto_2

    :sswitch_22
    const v1, 0x62c18a5b

    const-string v0, "ۛۛۘۘۦۢۗ۫ۗۦۜۜۜۘۚۨۘۖۙۘ۫ۘۘۘۤۧۚۙ۠ۜ۠ۨۦۙۚۡۡۡۗ۫ۤۨۘۢۥۨۘ"

    :goto_27
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_8a

    goto :goto_27

    :sswitch_30
    const-string v0, "ۜۚۢۨۤ۬ۗۡ۠ۜۖۤ۬ۦۡۖۛۛۤۤۦۡۖ۫ۡۥۦۘۖ۟ۚۥۛۙ۬ۡۡ"

    goto :goto_27

    :sswitch_33
    const-string v0, "۬ۡۥۘۛۛۘۘۛۖ۫۟ۦۘۜۜۘۘۥۜۨۛۚۦۛۦۖۦۚۨۘۙ۟ۥۘۗۙۡۘ۬ۦۨۘ"

    goto :goto_27

    :sswitch_36
    const v2, 0x4b1526bc  # 9774780.0f

    const-string v0, "ۖۥۖۛۥ۫ۢ۠ۚ۠ۡ۬ۤۙۤۡۙۨۘۡۙۨۖۦۙۤ۬ۜۘۛ۬ۧ"

    :goto_3b
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_9c

    goto :goto_3b

    :sswitch_44
    const-string v0, "ۢ۠ۡۘۦۤۥۘۘۘۥۘۧۨۦۘۡۦ۫ۡۛۗۗۘۢۦۛۥۨۢۘۘ۫۟ۨۘۛۖۜۘۢۖۧۘ"

    goto :goto_27

    :cond_47
    const-string v0, "ۢ۫۠ۖۗۖۤۦۦۚۦۛۖۤۤۦۚۨ۟ۜ۟ۗۗۖۜۚۧۗۗ۬۫ۦ۠ۦۥ۬۠ۢۘۘۖۛ۠ۛۨۖۘۧۜۜ"

    goto :goto_3b

    :sswitch_4a
    if-eqz p1, :cond_47

    const-string v0, "ۘۜۨۡۜ۫۬ۨ۫ۘ۟ۤۧۗۖۦۥۜۘۢۥۧۘۜ۟ۥ۫ۗۘۤۨۡ"

    goto :goto_3b

    :sswitch_4f
    const-string v0, "ۗۚۗۦۢۥۥۜۘ۬ۚ۠۟ۗ۟۟ۥۨۡۖۢۚ۟ۡۘۛۖۢۘۚ۠ۜۦۦۘۧۙۥۘۜۙۗ"

    goto :goto_3b

    :sswitch_52
    const-string v0, "ۥۢۘۘۖۤۧۧۗۨۗۦ۠ۨۜ۫۠ۘ۫ۘۚۢ۟ۘۧۤۚۤۜۗۨۘۚۧۥۛۤۤ۫ۨۦۘۨۦۦ۟ۚۤۧ۫ۙۖۖۥۙۘ۬"

    goto :goto_2

    :sswitch_55
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->hideSystemUI()V

    const-string v0, "ۤۙۜۜۜۦۙ۠۬۫ۙۙ۟ۧ۫ۨ۫ۜۘۘۡۧۖۥۜۘ۫۬ۡۚۧۘۘۘۘۜ۫ۥۜۥۤۖ۫ۨۜۙۚۡۘ۟ۜۚ۬ۡۤ۫ۤۦۘ"

    goto :goto_2

    :sswitch_5b
    invoke-direct {p0}, Lpubgm/loader/activity/MainActivity;->showSystemUI()V

    const-string v0, "ۙۛۡۘۦۤۦ۠ۡۖۡۖ۫ۦۘۚ۫ۥ۫ۦۥۛۥۡۜ۠ۘۥۨۦ۫ۚۤ۠ۥۘ۫۟ۦۤۛۢۧۙۖۘۖۜۢ۟۫ۥۘۚۛۦ"

    goto :goto_2

    :sswitch_61
    const-string v0, "۠ۤۘۗۘۦ۬۫ۨۙ۟ۘۗۗۡۘۤۤۜۘۙۜ۬ۜۗۧۗۦ۟۠۟ۜۖ۫ۛۗۡۨۘ۠ۛۦۘ۫ۜ۬ۛ۫۬ۤۤۗۨۙۧۛۚۥ"

    goto :goto_2

    :sswitch_64
    const-string v0, "ۙۛۡۘۦۤۦ۠ۡۖۡۖ۫ۦۘۚ۫ۥ۫ۦۥۛۥۡۜ۠ۘۥۨۦ۫ۚۤ۠ۥۘ۫۟ۦۤۛۢۧۙۖۘۖۜۢ۟۫ۥۘۚۛۦ"

    goto :goto_2

    :sswitch_67
    return-void

    :sswitch_data_68
    .sparse-switch
        -0x47363c3d -> :sswitch_16
        -0x1a9a9bb1 -> :sswitch_55
        0x7064e57 -> :sswitch_1c
        0x1ae2e2cd -> :sswitch_22
        0x3908bd5b -> :sswitch_64
        0x56004b6b -> :sswitch_19
        0x654e4e09 -> :sswitch_5b
        0x6687f3bc -> :sswitch_67
    .end sparse-switch

    :sswitch_data_8a
    .sparse-switch
        -0x518bdd45 -> :sswitch_36
        -0x2e2e67e9 -> :sswitch_61
        0x6b8f12d7 -> :sswitch_30
        0x7f45d0fe -> :sswitch_52
    .end sparse-switch

    :sswitch_data_9c
    .sparse-switch
        -0x66eea569 -> :sswitch_4a
        -0x15f0eadc -> :sswitch_4f
        -0x903ddba -> :sswitch_44
        0x4a1f9eb9 -> :sswitch_33
    .end sparse-switch
.end method
